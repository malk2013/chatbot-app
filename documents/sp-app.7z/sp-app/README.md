# Admentum Skola App

## Development Enviroment
To set the "correct" backend for the development enviroment to speak to, a key in the browsers localStorage has to be set, else it will default to production backend (see `config.js` for details, specifically line 38).

Ex. in Chrome devtools
```
> localStorage.setItem('spBackendOverride', 'localhost')
```
## Testing
Due to using the *latest of the latest, cutting edge technology,* a couple of things had to be dug up from the depth of the internet traversed only by developers in absolute despair, here lay the answer to running Jest without it falling flat on it's face:
- https://github.com/ant-design/ant-design-pro/commit/f61090219f31cb8b3da66ae9890391c1c75fde2d#comments

For more "useful" tests, not just renderng a pure Component, things like document have to be mocked. Here's and idea: https://stackoverflow.com/questions/41098009/mocking-document-in-jest



*In the future* we should check when we can get rid of the extra packages.

## Current situation
~~Attempting to update~~ Updated to React 16;
- Downloaded react-codemod to automatically do the shift
    - https://github.com/reactjs/react-codemod
        - all script have been run (see under **Refactored/Codemod scripts** for specifics)
- jest has been installed and a placeholder test has been added
    - [] create snapshots
- **current** issue is `CSSTansitionsGroup` 

- Refactoring ideas:
    - Lift script tags out of index and insert with Webpack plugin.
    - CSS in it's own file to allow for tree shaking.
    - "Update" style workflow, JS in CSS?
        - Most popular library for styling components: https://github.com/styled-components/styled-components
        - Awesome styled components list:
        https://github.com/styled-components/awesome-styled-components
    - `axios` is the new `fetch`; worth refactoring?
        - https://github.com/axios/axios
    - Storybook, dev utility to easily keep track of and develop project Components
        - https://github.com/storybooks/storybook


## Refactored

### Packages
- Webpack 1 -> Webpack 2/3
- Single webpack file replaced former dev/prod file and grunt file
- `react-addons-css-transition-group` replaced by `react-transition-group@1.x`
    - V.1 is a drop in replacement, although V.2 has a better API interface. Potential future upgrade.
    - (v1)[https://github.com/reactjs/react-transition-group/tree/v1-stable]
    - (v2)
    [https://github.com/reactjs/react-transition-group]
    - [] The "drop in" replacement does not work currently
- `react-select` 
    - has been known to cause issues with findDOMNode
    - with troubles; attempt downgrading back to rc.5 before anything else
    - getDefaultProps problem is solved by `autoSize={false}`
- `react-tap-event-plugin` not properly compatible with React 16, merely has temporary solution in v3.
    - (Github issue)[https://github.com/zilverline/react-tap-event-plugin/issues/102]
    - potential replacement is `react-fastclick`, already exists?!
        - check what the two packages solve 
- `react-router` has major breaking changes as of v4,
    - `hashHistory` "deprecation" is solved with `history` package with similar API (although, it's a peer dependency of react-router so maybe not necessary to have in package.json?)
    - Routes are now simply react components, and so the app has been refactored to use the new Route component.
- removed `redux-devtools` in favour of simple browser check
    - see `index.js` line 76 for details.
- several packages merely updated, see `package.json` in commit ### for details.

### Codemod scripts
`jscodeshift` is used to auto-refactor syntax changes for React 16 with the `react-codemod` scripts.

These commands have been run:

```
> jscodeshift -t react-codemod/transforms/pure-component.js ./src --useArrows=true
> jscodeshift -t react-codemod/transforms/create-element-to-jsx.js ./src  
> jscodeshift -t react-codemod/transforms/error-boundaries.js ./src
> jscodeshift -t react-codemod/transforms/findDOMNode.js ./src
> jscodeshift -t react-codemod/transforms/manual-bind-to-arrow.js ./src
> jscodeshift -t react-codemod/transforms/pure-render-mixin.js ./src
> jscodeshift -t react-codemod/transforms/React-PropTypes-to-prop-types.js ./src
> jscodeshift -t react-codemod/transforms/sort-comp.js ./src
```

