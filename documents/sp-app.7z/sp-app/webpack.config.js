'use strict';

const path = require('path');
const webpack = require('webpack');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

let config = {
	entry: {
		app: './src/index.js',
	},

	module: {
		rules: [
			{
				test: /\.js$/,
				exclude: /(node_modules|particles.min.js)/,
				loader: 'babel-loader',
				options: {
					presets: [['@babel/preset-env', {
						'shippedProposals': true,
					}], '@babel/preset-react'],
				}
			}, {
				test: /\.(scss|css)$/,
				use:[
					'style-loader',
					'css-loader',
					'sass-loader',
				],
			}, {
				test: /\.(eot|svg|ttf|woff|woff2)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
				loader: 'file-loader',
				options: {
					name: 'assets/fonts/[name]/[name].[ext]'
				}
			}, {
				test: /\.(png|jpg)$/,
				loader: 'url-loader',
				options: {
					mimetype: 'image/png'
				}
			}
		]
	},

	resolve: {
		modules: [
			path.resolve(__dirname, 'src'),
			'node_modules'],
		alias: {
			__components: path.resolve('src/components'),
			__containers: path.resolve('src/containers'),
		}
	},
};

function build_config (env) {
	if (env.production) {
		config.output = {
			filename: 'bundle.js',
			publicPath: '',
			path: __dirname + '/../skolplattformen/skolplattformen/static/app/',
		};
		config.optimization = {
			minimizer: [
				new UglifyJsPlugin({
					sourceMap: true
				}),
			]
		};
		config.devtool = 'source-map';
	} else if(env.development) {
		config.output = {
			filename: 'bundle.js',
			publicPath: '/',
			path: path.resolve(__dirname, './dist'),
		};

		config.devtool = 'inline-source-map',

		config.devServer = {
			historyApiFallback: true,
			port: 8080,
			hot: true,
		},

		config.plugins = [
			new webpack.NamedModulesPlugin(),
			new webpack.HotModuleReplacementPlugin(),
		];
	}
	return config;
}

module.exports = env => build_config(env);
