/*jslint node: true */
'use strict';

var path = require('path');
var webpack = require('webpack');

module.exports = {
	entry: ['babel-polyfill', './src/index.js'],
	// entry: './src/index.js',
	// context: path.join(__dirname, ''),

	output: {
		// path: __dirname + '/build/',
		path: __dirname + '/../skolplattformen/skolplattformen/static/app/',
		filename: 'bundle.js'
	},

	/*
	entry: {
		javascript: './src/index.js',
		html: './index.html'
	},
	output: {
		path: path.join(__dirname, 'dist'),
		filename: 'bundle.js'
	},
	*/

	devServer: {
		historyApiFallback: true,
	},


	resolveLoader: {
		root: path.join(__dirname, 'node_modules')
	},

	module: {
		loaders: [
			{
				test: /\.js$/,
				exclude: /(node_modules|particles.min.js)/,
				loader: 'babel-loader',
				query: {
					presets:['es2015', 'react']
					/*presets: [
						require.resolve('babel-preset-react'),
						require.resolve('babel-preset-es2015')
					]*/
				}
			}, {
				test: /\.scss$/,
				loaders: ['style', 'css', 'sass']
			}, {
			//	test: /\.(eot|svg|ttf|woff|woff2)$/,
			//	loader: 'file?name=/public_html/fonts/[name].[ext]'

			// 	test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
			// 	loader: 'url?limit=10000&minetype=application/font-woff'
			// }, {
				test: /\.(eot|svg|ttf|woff|woff2)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
				loader: 'file?name=assets/fonts/[name]/[name].[ext]'


			}, {
				test: /\.(png|jpg)$i/,
				loader: 'url-loader'
			}
		]
	},

	resolve: {
		alias: {
			'react': path.join(__dirname, 'node_modules/react'),
			'react/addons': path.join(__dirname, 'node_modules/react/addons')
		}
	},

	cache: true

	// Plugins
	/*plugins: [
		new webpack.ProvidePlugin({
			$: "jquery",
			jQuery: "jquery"
		})
	]*/
};
