/*jslint node: true */
'use strict';

var path = require('path');
var webpack = require('webpack');

module.exports = {
	entry: ['babel-polyfill', './src/index.js'],

	output: {
		path: __dirname + '/../skolplattformen/skolplattformen/static/app/',
		filename: 'bundle.js'
	},

	devtool: 'cheap-module-source-map',

	resolveLoader: {
		root: path.join(__dirname, 'node_modules')
	},

	module: {
		loaders: [
			{
				test: /\.js$/,
				exclude: /(node_modules|particles.min.js)/,
				loader: 'babel-loader',
				query: {
					presets:['es2015', 'react']
				}
			}, {
				test: /\.scss$/,
				loaders: ['style', 'css', 'sass']
			}, {
				test: /\.(eot|svg|ttf|woff|woff2)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
				loader: 'file?name=assets/fonts/[name]/[name].[ext]'
			}, {
				test: /\.png$/,
				loader: 'url-loader?mimetype=image/png'
			}
		]
	},

	resolve: {
		alias: {
			'react': path.join(__dirname, 'node_modules/react'),
			'react/addons': path.join(__dirname, 'node_modules/react/addons')
		}
	},

	cache: true,

	// Plugins
	plugins: [
		new webpack.DefinePlugin({
			'process.env':{
				'NODE_ENV': JSON.stringify('production')
			}
		}),
		// new webpack.optimize.CommonsChunkPlugin('common.js'),
		new webpack.optimize.DedupePlugin(),
		new webpack.optimize.UglifyJsPlugin(),
		new webpack.optimize.OccurrenceOrderPlugin(),
		new webpack.optimize.AggressiveMergingPlugin()
	]
};
