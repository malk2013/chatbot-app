import axios from 'axios';

import Config from '../config';
import { serverError, refreshTokenTry } from '../actions/AuthActions';
import { store } from '../store';
// Set the base url for the API
axios.defaults.baseURL = Config.getBackendUrl();
// Set a default auth on headers
axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('sp_access_token')}`;


function _injectAUID (url) {
	// Append account user ID to querystring
	const auid = localStorage.getItem('auid') || false;
	if (auid) {
		url = url + (url.includes('?') ? '&' : '?') + 'auid=' + auid;
	}
	return url;
}

export const post = (url, options, data) => {
	const config = {
		method: 'post',
		url: _injectAUID(url),
		data,
	};
	return fetch(config, { ...options, config: true});
};


export const remove = (url, options, data) => {
	const config = {
		method: 'delete',
		url: _injectAUID(url),
		data,
	};
	return fetch(config, { ...options, config: true});
};

export const fetch = (config, { request, success, error, successCallback, ...options }) => (dispatch) => {
	let injectedURL = config;
	// Check if config is a url or a config (for now the difference means a straight up GET vs other methods)
	if (!options.config) {
		// If it's a url the AUID injection hasn't been done yet
		injectedURL = _injectAUID(config);
		// Dispatch the Request action
		dispatch(request());
	} else {
		// If the config has data, dispatch the request action with data
		if (request) {
			dispatch(request(config.data));
		}
	}

	return get_data(injectedURL)
		// Dispatch the success action
		.then(response => success && dispatch(success(response.data)))
		// Call the successCallback if available
		.then(data => successCallback && successCallback(data, dispatch))
		// Dispatch our error action if something has occured,
		// for now also log this to console
		.catch(err => {
			console.log('Error :', err);
			// NOTE: this could be smoother by dispatching from an interceptor
			if (!err) {
				dispatch(error('Ogiltig access'));
			}
			else if (err.response && err.response.status === 500) {
				dispatch(serverError());
			}
			dispatch(error(err));
		});
};

// Not super-necessary, but one place in codebase calls API directly so for now this will remain
// so as to not use axios outside of this file.
export const get_data = (config) => axios(config);

export const get_data_with_auid = (url) => get_data(_injectAUID(url));

/*
Helper function to create the grant type depending on if we're logging
in, @creds, or refreshing a token
*/
function _refresh_grant (creds=false) {
	const client_id = Config.getClientId();
	const client_secret = Config.getClientSecret();
	const refresh_token = localStorage.getItem('sp_refresh_token');

	return creds
		? `grant_type=password&client_id=${client_id}&client_secret=${client_secret}&username=${encodeURIComponent(creds.username)}&password=${encodeURIComponent(creds.password)}&scope=openid`
		: `grant_type=refresh_token&client_id=${client_id}&client_secret=${client_secret}&refresh_token=${refresh_token}&scope=openid`;
}

/*
Fetches access and refresh token from server and sets in the localStorage,
if provided with @creds we're trying to login.
*/
export function refreshToken (creds=false) {
	// axios.defaults.baseURL = 
	let config = {
		method: 'POST',
		baseURL: Config.getAuthUrl(),
		data: _refresh_grant(creds), //_refresh_grant(creds)
		headers: {'X-Requested-With': 'XMLHttpRequest'}
	};

	return axios(config)
		.then(response => {
			localStorage.setItem('sp_access_token', response.data.access_token);
			localStorage.setItem('sp_refresh_token', response.data.refresh_token);
			axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('sp_access_token')}`;
			return Promise.resolve(response.data);
		})
		.catch(err => {
			console.log('Error: ', err);
			return Promise.reject(err.data);
		});
}

export function removeToken () {
	// axios.defaults.baseURL = 
	let config = {
		method: 'get',
		baseURL: Config.getLogoutUrl(),
		headers: {'X-Requested-With': 'XMLHttpRequest'}
	};

	return axios(config)
		.then(response => {
			return Promise.resolve(response.data);
		})
		.catch(err => {
			console.log('Error: ', err);
			return Promise.reject(err.data);
		});
}

/*
On receiving of response, check if status is 401 (needs refreshment or our credentials are wrong)
*/
axios.interceptors.response.use(null, (error) => {
	if (error.config && error.response && error.response.status === 401) {
		if(error.response.data.error == 'invalid_grant') {
			return Promise.reject(error.response);
		}
		const state = store.getState();
		if (state.auth.refreshTokenTries >= 5) {
			return Promise.reject(error);
		}
		store.dispatch(refreshTokenTry);
		return refreshToken()
			.then((data) => {
				// Dispatch the original request again with the Bearer set
				error.config.headers['Authorization'] = `Bearer ${data.access_token}`;
				return axios.request(error.config);
			})
			.catch(err => {
				localStorage.removeItem('sp_access_token');
				localStorage.removeItem('sp_refresh_token');
				console.log('Error: ', err);
				return Promise.reject(err);
			});
	}

	return Promise.reject(error);
});

