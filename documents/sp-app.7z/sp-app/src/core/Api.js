import Config from '../config';
import fetch from 'isomorphic-fetch';


function _fetch (url, options, config, passedDispatch=false, refreshIfNeeded=true) {
	return dispatch => {
		dispatch = dispatch || passedDispatch;

		// We dispatch requestLogin to kickoff the call to the API
		if (options.request && refreshIfNeeded) {
			dispatch(options.request());
		}

		return fetch(Config.getBackendUrl() + url, config)
			.then(response =>
				response.json().then(data => ({ data, response }))
			).then(({ data, response }) =>  {
				if (!response.ok) {

					if (response.status === 401 && refreshIfNeeded) {
						// Refresh token
						Api.refreshToken()
							.then(() => {
								_fetch(url, options, config, dispatch, false)();
							});

					} else if (response.status === 401) {
						// No longer needed as Login is auto redirected to if unauthenticated
						// hashHistory.replace('/login');

					} else {
						// If there was a problem, we want to dispatch the error condition
						if (options.error) {
							dispatch(options.error(data));
						}
						return Promise.reject(data);
					}
				} else {
					if (options.success) {
						dispatch(options.success(data));
					}
					if (options.successCallback) {
						options.successCallback(data);
					}
				}
			}).catch(err => console.log('Error: ', err));
	};
}

function _injectAUID (url) {
	// Append account user ID to querystring
	const auid = localStorage.getItem('auid') || false;
	if (auid) {
		url = url + (url.includes('?') ? '&' : '?') + 'auid=' + auid;
	}
	return url;
}

const config = (method, body=undefined) => ({
	method,
	body,
	headers: {
		'Authorization': 'Bearer '+ localStorage.getItem('sp_access_token'),
		'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
	}
});

export default class Api {

	static get (url) {
		return fetch(Config.getBackendUrl() + _injectAUID(url), config('GET'))
			.then((response) => {
				return response.json();
			});
	}

	static post (url, options, formData) {
		return _fetch(_injectAUID(url), options, config('POST', formData));
	}


	static fetch (url, options, passedDispatch=false, refreshIfNeeded=true) {
		return dispatch => {
			dispatch = dispatch || passedDispatch;

			// We dispatch requestLogin to kickoff the call to the API.
			// Don't do this if the token as refreshed
			if (options.request && refreshIfNeeded) {
				dispatch(options.request());
			}

			return fetch(Config.getBackendUrl() + _injectAUID(url), config('GET'))
				.then(response =>
					response.json().then(data => ({ data, response }))
				).then(({ data, response }) =>  {
					if (!response.ok) {

						if (response.status === 401 && refreshIfNeeded) {
							// Refresh token
							Api.refreshToken()
								.then(() => {
									Api.fetch(url, options, dispatch, false)();
								});

						} else if (response.status === 401) {
							// Something is wrong with the token..
							localStorage.removeItem('sp_access_token');
							localStorage.removeItem('sp_refresh_token');
							// No longer needed as Login is auto redirected to if unauthenticated
							// hashHistory.replace('/login');
							if (options.error) {
								dispatch(options.error('Ogiltig access'));
							}

						} else {
							// If there was a problem, we want to dispatch the error condition
							if (options.error) {
								dispatch(options.error());
							}
							return Promise.reject(data);
						}
					} else {
						if (options.success) {
							dispatch(options.success(data));
						}
						if (options.successCallback) {
							options.successCallback(data, dispatch);
						}
					}
				}).catch(err => {
					console.log('Fail', err);
					if (options.error) {
						dispatch(options.error('Sidan kunde inte laddas, kontrollera att du har tillgång till internet'));
					}
				});
		};
	}

	static refreshToken () {
		const client_id = Config.getClientId();
		const client_secret = Config.getClientSecret();
		const refresh_token = localStorage.getItem('sp_refresh_token');

		let config = {
			method: 'POST',
			headers: { 'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8' },
			body: `grant_type=refresh_token&client_id=${client_id}&client_secret=${client_secret}&refresh_token=${refresh_token}`
		};

		return fetch(Config.getBackendUrl() + 'o/token/', config)
			.then(response =>
				response.json().then(data => ({ data, response }))
			).then(({ data, response }) =>  {

				if (response.ok) {
					localStorage.setItem('sp_access_token', data.access_token);
					localStorage.setItem('sp_refresh_token', data.refresh_token);
				} else {
					return Promise.reject(data);
				}

				/*
				if (!response.ok) {
					// If there was a problem, we want to
					// dispatch the error condition
					dispatch(loginError(data.message));
					return Promise.reject(data);
				} else {
					console.log('LOGIN SUCCESS');
					// If login was successful, set the token in local storage
					localStorage.setItem('sp_access_token', data.access_token);
					localStorage.setItem('sp_refresh_token', data.refresh_token);

					// Dispatch the success action
					dispatch(receiveLogin(data));

					dispatch(fetchUser());
					// console.log(hashHistory);
					// hashHistory.replace('/');
				}*/

			}).catch(err => console.log('Error: ', err));
	}

}
