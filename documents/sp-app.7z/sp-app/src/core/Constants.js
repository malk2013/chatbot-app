export const USER_ROLES = {
	STUDENT: 1,
	TEACHER: 2,
	PARENT: 3,
	PRINCIPAL: 4
};

export const UI = {
	ANIMATION_DURATION: 350
};
