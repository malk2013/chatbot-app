let isAndroid = navigator.userAgent.indexOf('Android') > 0;
let isIOS = /iP(ad|hone|od)/.test(navigator.userAgent);
let isIPhone = /iPhone/.test(navigator.userAgent);

export default class Environment {

	static isNativeApp () {
		return typeof cordova !== 'undefined';
	}

	static isTabletSized () {
		return window.innerWidth >= 600 && window.innerHeight >= 600;
	}

	static isLandscape () {
		return window.innerWidth > window.innerHeight;
	}

	static isIOS () {
		return isIOS;
	}

	static isAndroid () {
		return isAndroid;
	}

	static isIPhone () {
		return isIPhone;
	}

	static getNativeAssetsPath () {
		return window.bundledAssetsPath || '';
	}

}
