import DateFormat from 'dateformat';
import Environment from './Environment';
import Config from '../config';

import { gettext, LOC_KEYS } from '../core/Texts';

export default class Utils {

	static addZero (nr) {
		return nr < 10 ? '0' + nr : nr;
	}

	static addS (txt) {
		if(Config.getLanguage() == 'en') {
			return txt.substr(-1) === '\'s' ? txt : txt + '\'s';
		}
		return txt.substr(-1) === 's' ? txt : txt + 's';
	}

	static getMonthNames () {
		return gettext(LOC_KEYS.MONTHS);
	}

	static getShortMonthNames () {
		return gettext(LOC_KEYS.MONTHS_SHORT);
	}

	static getDayNames () {
		return gettext(LOC_KEYS.DAYS);
	}

	static getShortDayNames () {
		return gettext(LOC_KEYS.DAYS_SHORT);
	}

	static getWeek () {
		return DateFormat(new Date(), 'W');
	}

	static getYear () {
		return DateFormat(new Date(), 'yyyy');
	}

	static getCurrentWeekday () {
		// Returns ISO 8601 numeric representation of the day of the week.
		// 1-7, where 1 = Monday and 7 = Sunday
		return parseInt(DateFormat(new Date(), 'N'));
	}

	static getClosestSchoolWeekday () {
		// Returns ISO 8601 numeric representation of the closest school day of the week.
		// 1-7, where 1 = Monday and 7 = Sunday
		const weekday = Utils.getCurrentWeekday();
		return (weekday > 5) ? 5 : weekday;
	}

	static get_time_from_minutes (minutes) {
		var hours = Math.floor(minutes / 60);
		minutes -= hours * 60;
		return Utils.addZero(hours) + ':'+ Utils.addZero(minutes);
	}

	static format_minutes_to_string (minutes) {
		var hours = Math.floor(minutes / 60);
		minutes -= hours * 60;
		var output = (hours) ? output = hours + 'h ' : '';
		if (minutes) output += minutes + 'min';
		return output || '0 min';
	}

	static format_date_standard (date) {
		return Utils.format_date('%y-%m-%d', date);
	}

	static format_date (format_string, date) {
		var date_markers = {
			d: ['getDate', function (v) { return Utils.addZero(v); }],
			a: ['getDate', function (v) {
				var l = v.toString().substr(-1);
				return (l === '1' || l === '2') ? v + ':a' : v + ':e';
			}],
			j: ['getDate'],
			m: ['getMonth', function (v) { return Utils.addZero(v+1); }],
			F: ['getMonth', function (v) { return Utils.getMonthNames()[v]; }],
			n: ['getMonth', function (v) { return Utils.getShortMonthNames()[v]; }],
			l: ['getDay', function (v) { return Utils.getDayNames()[v]; }],
			w: ['getDay', function (v) { return Utils.getShortDayNames()[v]; }],
			y: ['getFullYear'],
			H: ['getHours', function (v) { return Utils.addZero(v); }],
			M: ['getMinutes', function (v) { return Utils.addZero(v); }],
			S: ['getSeconds', function (v) { return Utils.addZero(v); }],
			i: ['toISOString ']
		};

		return format_string.replace(/%(.)/g, function (m, p) {
			var rv = date[(date_markers[p])[0]]();
			if ( date_markers[p][1] != null ) rv = date_markers[p][1](rv);
			return rv;
		});
	}

	static format_date_with_weekday_name (date) {
		var now = new Date();
		var last = new Date(date);
		var diff_days = (now - last) / (60 * 60 * 24 * 1000);
		if (diff_days > 7) {
			return Utils.format_date('%H:%M, %a %n', last);
		} else {
			return Utils.format_date('%H:%M, %l', last);
		}
	}


	static getImagePath (url) {
		// var imageBasePath = Environment.getCDNBase();
		let imageBasePath = '';

		if (Environment.isNativeApp()) {
			//var bundleAssets = window.bundledAssets || {};
			//if (!_.isEmpty(bundleAssets) && bundleAssets[url]) {
			imageBasePath = Environment.getNativeAssetsPath() + 'img/';
			//}
		} else {
			if (window.STATIC_ASSETS_MAP) {
				return window.STATIC_ASSETS_MAP[url];
			} else {
				imageBasePath = '/src/assets/img/';
			}
		}

		return imageBasePath + url;
	}

	static hasMinutesPassed (timestamp, minutes) {
		const now = (new Date()).getTime();
		return (now - timestamp) > minutes * 60 * 1000;
	}

	static formatInput (obj, timeFormat='HH:mm') {
		let formatted = {};
		Object.keys(obj).map(key => {
			if(key == 'date') {
				formatted[key] = obj[key] && obj[key]
					.toISOString().slice(0,10);
			}
			if(key.includes('time')) {
				formatted[key] = obj[key] && obj[key]
					.format(timeFormat);
			}
		});
		return { ...obj, ...formatted };
	}

	static serialize (obj) {
		let str = [];
		for (var p in obj) {
			if (obj.hasOwnProperty(p)) {
				str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
			}
		}
		return str.join('&');
	}


	static getDeepAttribute (obj, attribute, defaultValue) {
		if (obj) {
			try {
				let parts = attribute.split('.');
				for (var i=0, len=parts.length; i<len; i++) {
					obj = obj[parts[i]];
				}
				return obj;
			}
			catch (e) {
				return defaultValue;
			}
		}

		return defaultValue;
	}

}
