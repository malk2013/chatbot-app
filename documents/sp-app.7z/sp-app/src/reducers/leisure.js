import {
	FETCH_LEISURE_INFO_REQUEST, FETCH_LEISURE_INFO_SUCCESS, FETCH_LEISURE_INFO_FAILURE,
	RESET_LEISURE_INFO,
	SAVE_LEISURE_SCHEDULE_REQUEST, SAVE_LEISURE_SCHEDULE_SUCCESS, SAVE_LEISURE_SCHEDULE_FAILURE,
	DELETE_LEISURE_SCHEDULE_REQUEST, DELETE_LEISURE_SCHEDULE_SUCCESS, DELETE_LEISURE_SCHEDULE_FAILURE,
	SAVE_DEFAULT_WEEK_REQUEST, SAVE_DEFAULT_WEEK_SUCCESS, SAVE_DEFAULT_WEEK_FAILURE,
	SET_LEISURE_WEEK, SHOW_PREV_LEISURE_DAY, SHOW_NEXT_LEISURE_DAY, SHOW_LEISURE_DAY_IN_WEEK,
	SHOW_PREV_LEISURE_WEEK, SHOW_NEXT_LEISURE_WEEK,
	FETCH_LEISURE_WEEK_REQUEST, FETCH_LEISURE_WEEK_SUCCESS, FETCH_LEISURE_WEEK_FAILURE,
	UPDATE_WEEKDAY_REQUEST, UPDATE_WEEKDAY_SUCCESS, UPDATE_WEEKDAY_FAILURE,
} from '../actions/LeisureActions';

import {
	SET_ACTIVE_LEISURE_GROUP,
	FETCH_TEACHER_LEISURE_INFO_REQUEST, FETCH_TEACHER_LEISURE_INFO_SUCCESS, FETCH_TEACHER_LEISURE_INFO_FAILURE,
	UPDATE_USER_LEISURE_REQUEST, UPDATE_USER_LEISURE_SUCCESS, UPDATE_USER_LEISURE_FAILURE
} from '../actions/TeacherLeisureActions';

const initialState = {
	isFetching: false,
	leisureInfo: false,
	currentLeisureWeek: false,
	fetchLeisureWeekError: false,
	currentWeekday: false,
	currentWeek: false,
	currentYear: false,
	isSavingLeisure: false,
	defaultWeekError: false,
	leisureError: false,

	activeLeisureGroupId: false,
	// activeLeisureGroupInfo: false
};

export default function leisure (state = initialState, action = {}) {

	switch (action.type) {


	// ****************************** Fetch leisure info ******************************
	case FETCH_LEISURE_INFO_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			leisureError: false
		});

	case FETCH_LEISURE_INFO_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			leisureInfo: Object.assign({}, action.leisureInfo)
		});

	case FETCH_LEISURE_INFO_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			leisureError: action.message
		});

	case RESET_LEISURE_INFO:
		return Object.assign({}, state, {
			isFetching: false,
			leisureInfo: false,
			currentLeisureWeek: false
		});



	// ****************************** Save Leisure Schedule ******************************
	case SAVE_LEISURE_SCHEDULE_REQUEST:
		return Object.assign({}, state, {
			isSavingLeisure: true,
			leisureError: false
		});

	case SAVE_LEISURE_SCHEDULE_SUCCESS:
		return Object.assign({}, state, {
			isSavingLeisure: false,
			leisureInfo: Object.assign({}, action.leisureInfo),
			currentLeisureWeek: false
		});

	case SAVE_LEISURE_SCHEDULE_FAILURE:
		return Object.assign({}, state, {
			isSavingLeisure: false,
			leisureError: action.message
		});



	// ****************************** Save Default Week ******************************
	case SAVE_DEFAULT_WEEK_REQUEST:
		return Object.assign({}, state, {
			isSavingLeisure: true,
			defaultWeekError: false
		});

	case SAVE_DEFAULT_WEEK_SUCCESS:
		return Object.assign({}, state, {
			isSavingLeisure: false,
			leisureInfo: Object.assign({}, action.leisureInfo),
			currentLeisureWeek: false
		});

	case SAVE_DEFAULT_WEEK_FAILURE:
		return Object.assign({}, state, {
			isSavingLeisure: false,
			defaultWeekError: action.errors
		});



	// ****************************** Delete Leisure Schedule ******************************
	case DELETE_LEISURE_SCHEDULE_REQUEST:
		return Object.assign({}, state, {
			isSavingLeisure: true,
			leisureError: false
		});

	case DELETE_LEISURE_SCHEDULE_SUCCESS:
		return Object.assign({}, state, {
			// isSavingLeisure: false,
			// leisureInfo: false,
			// currentLeisureWeek: false

			isFetching: false,
			leisureInfo: false,
			currentLeisureWeek: false,
			fetchLeisureWeekError: false,
			currentWeekday: false,
			currentWeek: false,
			currentYear: false,
			isSavingLeisure: false,
			defaultWeekError: false,
			leisureError: false,
			activeLeisureGroupId: false
		});

	case DELETE_LEISURE_SCHEDULE_FAILURE:
		return Object.assign({}, state, {
			isSavingLeisure: false,
			leisureError: action.message
		});



	// ****************************** Week naviation ******************************
	case SET_LEISURE_WEEK:
		return Object.assign({}, state, {
			currentWeek: action.week,
			currentYear: action.year,
			currentWeekday: action.weekday
		});

	case FETCH_LEISURE_WEEK_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			fetchLeisureWeekError: false
		});

	case FETCH_LEISURE_WEEK_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			currentLeisureWeek: Object.assign({}, action.leisureWeek),
			currentWeek: action.leisureWeek.week,
			currentYear: action.leisureWeek.year
		});

	case FETCH_LEISURE_WEEK_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			fetchLeisureWeekError: action.message
		});

	case SHOW_PREV_LEISURE_DAY:
		var prevWeek = state.currentWeek;
		var prevYear = state.currentYear;
		var prevDay = state.currentWeekday - 1;
		if (prevDay < 0) {
			prevDay = 4;
			prevWeek--;
			if (prevWeek < 0) {
				prevWeek = 52;
				prevYear--;
			}
		}

		return Object.assign({}, state, {
			currentWeekday: prevDay,
			currentWeek: prevWeek,
			currentYear: prevYear
		});

	case SHOW_NEXT_LEISURE_DAY:
		var nextWeek = state.currentWeek;
		var nextYear = state.currentYear;
		var nextDay = state.currentWeekday + 1;
		if (nextDay > 4) {
			nextDay = 0;
			nextWeek++;
			if (nextWeek > 52) {
				nextWeek = 1;
				nextYear++;
			}
		}

		return Object.assign({}, state, {
			currentWeekday: nextDay,
			currentWeek: nextWeek,
			currentYear: nextYear
		});

	case SHOW_LEISURE_DAY_IN_WEEK:
		return Object.assign({}, state, {
			currentWeekday: action.day
		});

	case SHOW_PREV_LEISURE_WEEK:
		var pw = state.currentWeek - 1;
		var py = state.currentYear;
		if (pw < 1) {
			pw = 52;
			py--;
		}
		return Object.assign({}, state, {
			currentWeek: pw,
			currentYear: py
		});

	case SHOW_NEXT_LEISURE_WEEK:
		var nw = state.currentWeek + 1;
		var ny = state.currentYear;
		if (nw > 52) {
			nw = 1;
			ny++;
		}
		return Object.assign({}, state, {
			currentWeek: nw,
			currentYear: ny
		});


	// ****************************** Week ******************************
	case UPDATE_WEEKDAY_REQUEST:
		return Object.assign({}, state, {
			isSavingLeisure: true,
			leisureError: false
		});

	case UPDATE_WEEKDAY_SUCCESS:
		return Object.assign({}, state, {
			isSavingLeisure: false,
			currentLeisureWeek: Object.assign({}, action.leisureWeek),
			currentWeek: action.leisureWeek.week,
			currentYear: action.leisureWeek.year
		});

	case UPDATE_WEEKDAY_FAILURE:
		return Object.assign({}, state, {
			isSavingLeisure: false,
			leisureError: action.message
		});






	// ****************************** TEACHERS ******************************
	case SET_ACTIVE_LEISURE_GROUP:
		return Object.assign({}, state, {
			activeLeisureGroupId: action.activeLeisureGroupId,
			leisureInfo: false
		});


	case FETCH_TEACHER_LEISURE_INFO_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			leisureError: false,
			leisureInfo: false
		});

	case FETCH_TEACHER_LEISURE_INFO_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			leisureInfo: Object.assign({}, action.leisureInfo)
		});

	case FETCH_TEACHER_LEISURE_INFO_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			leisureError: action.message
		});

	/*
	case RESET_TEACHER_LEISURE_INFO:
		return Object.assign({}, state, {
			isFetching: false,
			leisureInfo: false
		});
	*/


	// ****************************** Register ******************************
	case UPDATE_USER_LEISURE_REQUEST:
		return Object.assign({}, state);

	case UPDATE_USER_LEISURE_SUCCESS:
		var leisureInfo = Object.assign({}, state.leisureInfo);
		var currUserDict = leisureInfo.leisure_day.user_dicts.find(ud => ud.user.id == action.userId);
		if (currUserDict) {
			currUserDict.schedule = action.weekday;
		}
		leisureInfo.timestamp = Date.now();

		return Object.assign({}, state, {
			leisureInfo: Object.assign({}, leisureInfo)
		});

	case UPDATE_USER_LEISURE_FAILURE:
		return Object.assign({}, state);


	}


	return state;
}
