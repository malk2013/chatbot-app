import {
	FETCH_SCHEDULE_REQUEST, FETCH_SCHEDULE_SUCCESS, FETCH_SCHEDULE_FAILURE,
	FETCH_LESSON_REQUEST, FETCH_LESSON_SUCCESS, FETCH_LESSON_FAILURE,
	SET_WEEKDAY, SHOW_PREV_DAY, SHOW_NEXT_DAY, SHOW_PREV_WEEK, SHOW_NEXT_WEEK,
	RESET_SCHEDULE
} from '../actions/ScheduleActions';

const initialState = {
	isFetching: false,
	weekSchedules: {},
	currentWeek: false,
	// currentYear: false,
	currentWeekday: false,
	lesson: false,
	isFetchingLesson: false,
	scheduleErrorMessage: false,
	lessonErrorMessage: false
};

export default function schedule (state = initialState, action = {}) {

	switch (action.type) {

	case FETCH_SCHEDULE_REQUEST:
		return Object.assign({}, state, {
			isFetching: true
		});

	case FETCH_SCHEDULE_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			weekSchedules: Object.assign({}, state.weekSchedules, {
				[action.schedule.week_number]: action.schedule
			}),
			currentWeek: action.schedule.week_number
		});

	case FETCH_SCHEDULE_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			scheduleErrorMessage: action.message
		});


	case FETCH_LESSON_REQUEST:
		return Object.assign({}, state, {
			lesson: false,
			isFetchingLesson: true
		});

	case FETCH_LESSON_SUCCESS:
		return Object.assign({}, state, {
			isFetchingLesson: false,
			lesson: action.lesson
		});

	case FETCH_LESSON_FAILURE:
		return Object.assign({}, state, {
			isFetchingLesson: false,
			lessonErrorMessage: action.message
		});



	case SET_WEEKDAY:
		return Object.assign({}, state, {
			currentWeekday: action.weekday
		});

	case SHOW_PREV_DAY:
		var prevWeek = state.currentWeek;
		var prevDay = state.currentWeekday - 1;
		if (prevDay == 0) {
			prevDay = 5;
			prevWeek--;
			if (prevWeek < 0) {
				prevWeek = 52;
			}
		}

		return Object.assign({}, state, {
			currentWeekday: prevDay,
			currentWeek: prevWeek
		});

	case SHOW_NEXT_DAY:
		var nextWeek = state.currentWeek;
		var nextDay = state.currentWeekday + 1;
		if (nextDay > 5) {
			nextDay = 1;
			nextWeek++;
			if (nextWeek > 52) {
				nextWeek = 1;
			}
		}

		return Object.assign({}, state, {
			currentWeekday: nextDay,
			currentWeek: nextWeek
		});

	case SHOW_PREV_WEEK:
		var goPrevWeek = state.currentWeek - 1;
		if (goPrevWeek < 1) {
			goPrevWeek = 52;
		}

		return Object.assign({}, state, {
			currentWeekday: 5,
			currentWeek: goPrevWeek
		});

	case SHOW_NEXT_WEEK:
		var goNextWeek = state.currentWeek + 1;
		if (goNextWeek > 52) {
			goNextWeek = 1;
		}

		return Object.assign({}, state, {
			currentWeekday: 1,
			currentWeek: goNextWeek
		});

	case RESET_SCHEDULE:
		return Object.assign({}, state, {
			isFetching: false,
			weekSchedules: {}
		});

	}

	return state;
}
