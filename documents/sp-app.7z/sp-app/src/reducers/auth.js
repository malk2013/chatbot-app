import User from '../models/User';
import {
	LOGIN_REQUEST, LOGIN_SUCCESS, LOGIN_FAILURE, LOGOUT_SUCCESS,
	ACCOUNT_REQUEST, ACCOUNT_SUCCESS, ACCOUNT_ERROR,
	USER_REQUEST, USER_SUCCESS, USER_ERROR,
	SET_ACTIVE_CHILD, REFRESH_TOKEN
} from '../actions/AuthActions';


const initialState = {
	isFetching: false,
	hasTokens: !!localStorage.getItem('sp_access_token'),
	account: {},
	activeUserId: false,
	user: {},
	userData: {},
	loginErrorMessage: '',
	userErrorMessage: '',
	accountErrorMessage: '',
	refreshTokenTries: 0,
};


export default function auth (state = initialState, action) {

	switch (action.type) {
	case REFRESH_TOKEN: 
		return {
			...state,
			refreshTokenTries: state.refreshTokenTries + 1,
		};
	case LOGIN_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			hasTokens: false,
			user: {},
			loginErrorMessage: ''
		});

	case LOGIN_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			refreshTokenTries: 0,
			hasTokens: true,
		});

	case LOGIN_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			hasTokens: false,
			loginErrorMessage: action.message
		});

	case LOGOUT_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			hasTokens: false,
			user: {},
			userData: {}
		});


	case ACCOUNT_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			accountErrorMessage: ''
		});

	case ACCOUNT_SUCCESS:
		var defaultUserData = action.user;
		if (defaultUserData.children && defaultUserData.children.length) {
			defaultUserData.activeChild = defaultUserData.children[0];
		}

		var defaultUserObj = new User(defaultUserData);
		defaultUserObj.setBodyBgr();

		return Object.assign({}, state, {
			account: action.account,
			isFetching: false,
			user: defaultUserObj,
			userData: defaultUserData,
		});

	case ACCOUNT_ERROR:
		return Object.assign({}, state, {
			account: {},
			isFetching: false,
			accountErrorMessage: action.message
		});


	case USER_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			userErrorMessage: ''
		});

	case USER_SUCCESS:
		var newUserData = action.user;
		if (newUserData.children && newUserData.children.length) {
			newUserData.activeChild = newUserData.children[0];
		}

		var userObj = new User(newUserData);
		userObj.setBodyBgr();

		return Object.assign({}, state, {
			user: userObj,
			userData: newUserData,
			isFetching: false,
		});

	case USER_ERROR:
		return Object.assign({}, state, {
			user: {},
			userData: {},
			isFetching: false,
			userErrorMessage: action.message
		});

	case SET_ACTIVE_CHILD:
		var userData = Object.assign({}, state.userData, {
			activeChild: state.userData.children.find(child => child.id == action.childId)
		});

		return Object.assign({}, state, {
			user: new User(userData),
			userData: userData
		});

	default:
		return state;

	}
}
