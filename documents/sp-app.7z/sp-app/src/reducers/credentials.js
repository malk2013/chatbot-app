import CredentialsActionTypes from '../actions/CredentialsActions';

const initialState = {
	authenticated: false,
	checkingToken: false,
	loggingIn: false,
	hint: false
};

export default function credentials (state = initialState, action) {
	const { type, hint } = action;

	switch (type) {

	case CredentialsActionTypes.CLEAR_CREDENTIALS:
		return initialState;

	case CredentialsActionTypes.CHECK_CREDENTIALS:
		return {
			...initialState,
			checkingToken: true
		};

	case CredentialsActionTypes.CHECK_CREDENTIALS_SUCCESS:
		return {
			...initialState,
			checkingToken: false,
			authenticated: true
		};

	case CredentialsActionTypes.CHECK_CREDENTIALS_FAILURE:
		return {
			...initialState,
			checkingToken: false
		};

	case CredentialsActionTypes.ADD_CREDENTIALS:
		return {
			...initialState,
			loggingIn: true
		};

	case CredentialsActionTypes.ADD_CREDENTIALS_SUCCESS:
		return {
			...initialState,
			authenticated: true,
			loggingIn: false
		};

	case CredentialsActionTypes.ADD_CREDENTIALS_FAILURE:
		return {
			...initialState,
			hint
		};

	default:
		return state;

	}
}
