import Modal from '../models/Modal';

import {
	SHOW_MODAL, CLOSE_MODAL
} from '../actions/ModalActions';

const initialState = {
	dialogs: []
};

export default function modalReducer (state = initialState, action = {}) {

	switch (action.type) {

	case SHOW_MODAL:
		var options = action.options;
		var modal = new Modal(options);

		return Object.assign({}, state, {
			dialogs: [modal]
		});


	case CLOSE_MODAL:
		return Object.assign({}, state, {
			dialogs: state.dialogs.slice(1)
		});

	}

	return state;
}
