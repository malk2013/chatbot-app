import {
	FETCH_SICKNESS_STATUS_REQUEST, FETCH_SICKNESS_STATUS_SUCCESS, FETCH_SICKNESS_STATUS_FAILURE,
	FETCH_SICKNESS_REPORT_REQUEST, FETCH_SICKNESS_REPORT_SUCCESS, FETCH_SICKNESS_REPORT_FAILURE,
	RESET_SICKNESS_ERRORS, RESET_SICKNESS_STATUS
} from '../actions/PresenceActions';

const initialState = {
	isFetching: false,
	isFetched: false,
	sicknessStatus: false,
	sicknessError: false
};

export default function presence (state = initialState, action = {}) {

	switch (action.type) {

	case FETCH_SICKNESS_STATUS_REQUEST:
		return { ...state,
			sicknessError: false,
			isFetching: true,
			isFetched: false,
			sicknessStatus: false
		};

	case FETCH_SICKNESS_STATUS_SUCCESS:
		return { ...state,
			isFetching: false,
			isFetched: true,
			sicknessStatus: action.status
		};

	case FETCH_SICKNESS_STATUS_FAILURE:
		return { ...state,
			isFetching: false,
			isFetched: true,
			sicknessStatus: false,
			sicknessError: action.message || 'Ett oväntat fel inträffade'
		};

	case FETCH_SICKNESS_REPORT_REQUEST:
		return { ...state,
			isFetching: true,
			isFetched: false
		};

	case FETCH_SICKNESS_REPORT_SUCCESS:
		return { ...state,
			isFetching: false,
			isFetched: true,
			sicknessStatus: action.status
		};

	case FETCH_SICKNESS_REPORT_FAILURE:
		return { ...state,
			isFetching: false,
			isFetched: true,
			sicknessError: action.message
		};

	case RESET_SICKNESS_ERRORS:
		return { ...state, 
			sicknessError: false
		};
	case RESET_SICKNESS_STATUS:
		return { ...state,
			isFetching: false,
			sicknessStatus: false,
			sicknessError: false,
		};
	}
	return state;
}

export const getPartialAbsences = (state) =>
	Array.isArray(state.presence.sicknessStatus.sickness)
		? state.presence.sicknessStatus.sickness
		: [];

export	const getSickness = (state) => 
	state.presence.sicknessStatus.hasOwnProperty('show_next_day') 
		? state.presence.sicknessStatus
		: false;
