import {
	FETCH_INFO_REQUEST, FETCH_INFO_SUCCESS, FETCH_INFO_FAILURE,
	RESET_SCHOOL_DAY_INFO
} from '../actions/HomeActions';

const initialState = {
	isFetching: false,
	schoolDayInfo: false,
	shoolDayErrorMessage: false
};

export default function schedule (state = initialState, action = {}) {

	switch (action.type) {

	case FETCH_INFO_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			shoolDayErrorMessage: false
		});

	case FETCH_INFO_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			schoolDayInfo: Object.assign({}, action.schoolDayInfo)
		});

	case FETCH_INFO_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			shoolDayErrorMessage: action.message
		});

	case RESET_SCHOOL_DAY_INFO:
		return Object.assign({}, state, {
			isFetching: false,
			schoolDayInfo: false
		});

	}

	return state;
}
