import {
	FETCH_ABSENCES_REQUEST, FETCH_ABSENCES_SUCCESS, FETCH_ABSENCES_FAILURE,
	FETCH_ABSENCE_REQUEST, FETCH_ABSENCE_SUCCESS, FETCH_ABSENCE_FAILURE,
	TOGGLE_SHOW_CONFIRMED,
	CONFIRM_ABSENCE_REQUEST, CONFIRM_ABSENCE_SUCCESS, CONFIRM_ABSENCE_FAILURE
} from '../actions/AbsenceActions';

const initialState = {
	absence: false,
	absences: false,
	showConfirmed: false,
	errorMessage: false,
	isFetching: false,
	isConfirming: false,
	pagination: {
		page: 1
	}
};

export default function absence (state = initialState, action = {}) {

	switch (action.type) {

	// Index
	case FETCH_ABSENCES_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			absences: action.page == 1 ? [] : state.absences
		});

	case FETCH_ABSENCES_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			absences: action.pagination.page == 1 ? action.absences : state.absences.concat(action.absences),
			pagination: action.pagination
		});

	case FETCH_ABSENCES_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			errorMessage: action.message
		});

	case TOGGLE_SHOW_CONFIRMED:
		return Object.assign({}, state, {
			showConfirmed: !state.showConfirmed,
			absences: false,
			pagination: { page: 1 }
		});


	// Show
	case FETCH_ABSENCE_REQUEST:
		return Object.assign({}, state, {
			absence: false,
			isFetching: true,
		});

	case FETCH_ABSENCE_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			absence: action.absence
		});

	case FETCH_ABSENCE_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			errorMessage: action.message
		});


	// Confirm
	case CONFIRM_ABSENCE_REQUEST:
		return Object.assign({}, state, {
			isConfirming: true
		});

	case CONFIRM_ABSENCE_SUCCESS:
		return Object.assign({}, state, {
			isConfirming: false,
			absence: action.absence,
			absences: state.absences.filter(a => a.id !== action.absence.id)
		});

	case CONFIRM_ABSENCE_FAILURE:
		return Object.assign({}, state, {
			isConfirming: false,
			errorMessage: action.message
		});

	}

	return state;
}
