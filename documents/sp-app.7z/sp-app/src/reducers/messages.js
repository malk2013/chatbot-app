import {
	FETCH_UNREAD_MESSAGES_COUNT_REQUEST, FETCH_UNREAD_MESSAGES_COUNT_SUCCESS, FETCH_UNREAD_MESSAGES_COUNT_FAILURE,
	FETCH_CONVERSATIONS_REQUEST, FETCH_CONVERSATIONS_SUCCESS, FETCH_CONVERSATIONS_FAILURE, SET_LAST_MESSAGE_BODY, RESET_CONVERSATIONS,
	FETCH_CONVERSATION_REQUEST, FETCH_CONVERSATION_SUCCESS, FETCH_CONVERSATION_FAILURE,
	CREATE_CONVERSATION_REQUEST, CREATE_CONVERSATION_SUCCESS, CREATE_CONVERSATION_FAILURE,
	POST_MESSAGE_REQUEST, POST_MESSAGE_SUCCESS, POST_MESSAGE_FAILURE,
	TOGGLE_MESSAGE_FORM, TOGGLE_RECIPIENTS, SET_MESSAGE_RECIPIENT
} from '../actions/MessagesActions';

const initialState = {
	isUnreadMessagesFetching: false,
	unconfirmedAbsenceCountMap: {},
	unreadMessagesCount: 0,
	unreadMessagesTimestamp: false,

	isFetching: false,
	isFetched: false,
	page: 1,
	conversations: false,
	conversationsTimestamp: 0,
	conversationsErrorMessage: false,

	isConversationFetching: false,
	isConversationFetched: false,
	conversation: {},
	isPostMessageFetching: false,
	conversationErrorMessage: false,

	newMessageRecipients: '',
	isCreateFetching: false,
	isCreateFetched: false,
	messageError: false,

	createConversationErrorMessage: false
};

export default function messages (state = initialState, action = {}) {

	switch (action.type) {

	// Fetch unread messages count
	case FETCH_UNREAD_MESSAGES_COUNT_REQUEST:
		return Object.assign({}, state, {
			isUnreadMessagesFetching: true,
			unreadMessagesTimestamp: false
		});

	case FETCH_UNREAD_MESSAGES_COUNT_SUCCESS:
		return Object.assign({}, state, {
			isUnreadMessagesFetching: false,
			unconfirmedAbsenceCountMap: action.absenceCountMap,
			unreadMessagesCount: action.count,
			unreadMessagesTimestamp: (new Date).getTime()
		});

	case FETCH_UNREAD_MESSAGES_COUNT_FAILURE:
		// Don't handle failures..
		return Object.assign({}, state, {
			isUnreadMessagesFetching: false,
			unreadMessagesCount: 0,
			unreadMessagesTimestamp: (new Date).getTime()
		});


	// Fetch conversations
	case FETCH_CONVERSATIONS_REQUEST:
		return Object.assign({}, state, {
			isFetching: true,
			isFetched: false,
			conversations: false,
			conversationsErrorMessage: false
		});

	case FETCH_CONVERSATIONS_SUCCESS:
		return Object.assign({}, state, {
			isFetching: false,
			isFetched: true,
			conversations: action.conversations,
			conversationsTimestamp: (new Date).getTime(),
			page: action.page
		});

	case FETCH_CONVERSATIONS_FAILURE:
		return Object.assign({}, state, {
			isFetching: false,
			isFetched: true,
			conversations: false,
			conversationsErrorMessage: action.message
		});

	case SET_LAST_MESSAGE_BODY:
		// Check if the updated conversation exists
		var currStateConversation = state.conversations.find(conversation => conversation.id === action.conversationId);
		if (!currStateConversation) {
			// If not it's a newly created one.. Clear the conversations to update the view
			return Object.assign({}, state, {
				conversations: false
			});
		}

		// Remove single conversation entry
		var conversation = Object.keys(state.conversation).reduce((result, key) => {
			if (key != action.conversationId) {
				result[key] = state.conversation[key];
			}
			return result;
		}, {});

		return Object.assign({}, state, {
			conversations: state.conversations.map(conversation => {
				if (conversation.id === action.conversationId) {
					return Object.assign({}, conversation, {
						last_message_body: action.lastMessageBody,
						is_read: false
					});
				} else {
					return conversation;
				}
			}),
			conversation
		});

	case RESET_CONVERSATIONS:
		// This mutates the original state..
		return Object.assign({}, state, {
			conversations: false,
			conversation: {}
		});


	// Fetch single conversation
	case FETCH_CONVERSATION_REQUEST:
		return Object.assign({}, state, {
			isConversationFetching: true,
			isConversationFetched: false,
			conversationErrorMessage: false
		});

	case FETCH_CONVERSATION_SUCCESS:
		var newState = Object.assign({}, state, {
			isConversationFetching: false,
			isConversationFetched: true,
			// conversation: action.conversation
			conversation:  Object.assign({}, state.conversation, {
				[action.conversation.id]: action.conversation
			})
		});

		// Update the entry in the conversations arrays as well
		// if the is_read value has changed
		if (state.conversations) {
			var currStateConversation2 = state.conversations.find(conversation => conversation.id === action.conversation.id);
			if (!currStateConversation2.is_read) {
				let newConversations = state.conversations.map(conversation => {
					if (conversation.id === action.conversation.id) {
						return Object.assign({}, conversation, {
							is_read: true
						});
					} else {
						return conversation;
					}
				});
				newState.conversations = newConversations;
			}
		}

		return newState;

	case FETCH_CONVERSATION_FAILURE:
		return Object.assign({}, state, {
			isConversationFetching: false,
			isConversationFetched: true,
			conversation: false,
			conversationErrorMessage: action.message
		});


	// Post message
	case POST_MESSAGE_REQUEST:
		return Object.assign({}, state, {
			isPostMessageFetching: true,
			messageError: false
		});

	case POST_MESSAGE_SUCCESS:
		return Object.assign({}, state, {
			isPostMessageFetching: false,
			conversation: Object.assign({}, state.conversation, {
				[action.conversation.id]: action.conversation
			})
		});

	case POST_MESSAGE_FAILURE:
		return Object.assign({}, state, {
			isPostMessageFetching: false,
			messageError: action.message
		});


	// Create conversation
	case CREATE_CONVERSATION_REQUEST:
		return Object.assign({}, state, {
			isCreateFetching: true,
			isCreateFetched: false,
			createConversationErrorMessage: false
		});

	case CREATE_CONVERSATION_SUCCESS:
		return Object.assign({}, state, {
			isCreateFetching: false,
			isCreateFetched: true,
			newMessageRecipients: '',

			// Reset conversation stuff to force reload
			isFetching: false,
			isFetched: false,
			page: 1,
			conversations: false
		});

	case CREATE_CONVERSATION_FAILURE:
		return Object.assign({}, state, {
			isCreateFetching: false,
			isCreateFetched: true,
			createConversationErrorMessage: action.message || 'Ett fel inträffade. Var god kontrollera uppgifterna!'
		});


	// Misc
	case TOGGLE_RECIPIENTS:
		var activeConversation = Object.assign({}, state.conversation[action.conversationId], {
			showRecipients: state.conversation[action.conversationId].showRecipients ? false : true
		});

		return Object.assign({}, state, {
			conversation: Object.assign({}, state.conversation, {
				[action.conversationId]: activeConversation
			})
		});

	case TOGGLE_MESSAGE_FORM:
		var formConversation = Object.assign({}, state.conversation[action.conversationId], {
			showMessageForm: state.conversation[action.conversationId].showMessageForm ? false : true
		});

		return Object.assign({}, state, {
			conversation: Object.assign({}, state.conversation, {
				[action.conversationId]: formConversation
			})
		});

	case SET_MESSAGE_RECIPIENT:
		return Object.assign({}, state, {
			newMessageRecipients: action.value
		});

	}

	return state;
}
