import {
	OPEN_MENU, CLOSE_MENU, SET_ORIENTATION
} from '../actions/UIActions';

const initialState = {
	menuOpen: false,
	orientation: window.screen ? window.screen.orientation : false
};

export default function ui (state = initialState, action = {}) {

	switch (action.type) {

	case OPEN_MENU:
		return Object.assign({}, state, {
			menuOpen: true
		});

	case CLOSE_MENU:
		return Object.assign({}, state, {
			menuOpen: false
		});

	case SET_ORIENTATION:
		return Object.assign({}, state, {
			orientation: action.orientation
		});

	}

	return state;
}
