import absence from './absence';
import auth from './auth';
import home from './home';
import leisure from './leisure';
import messages from './messages';
import modals from './modals';
import presence from './presence';
import schedule from './schedule';
import ui from './ui';

import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';

export default combineReducers({
	absence,
	auth,
	home,
	leisure,
	messages,
	modals,
	presence,
	schedule,
	ui,
	router: routerReducer,
});

// export default reducers;