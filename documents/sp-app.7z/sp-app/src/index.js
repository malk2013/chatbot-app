import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';

import initReactFastclick from 'react-fastclick';

import { history, store } from 'store';
import { ConnectedRouter } from 'react-router-redux';

import Analytics from './analytics';
import MobileRoot from './containers/MobileRoot';
import App from './containers/App';

import './scss/app.scss';

import './notifications';

initReactFastclick();


Analytics.startTracker();

render(
	<Provider store={store}>
		<App>
			<ConnectedRouter history={history}>
				<MobileRoot />
			</ConnectedRouter>
		</App>
	</Provider>,
	document.getElementById('react-root')
);
