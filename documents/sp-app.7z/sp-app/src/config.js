const _CONFIG = {

	build: 1118,
	defaultBackend: 'prod',

	backends: {
		localhost: {
			key: 'localhost',
			url: 'http://localhost:8000/',
			client_id: '606312',
			client_secret: 'a53f5cee353b3ef89d04dd9c624e8f590484157ec7c7090be2671b9b',
			auth_url: 'http://localhost:3002',
		},

		// TODO!!: fetch client_id and client_secret from env
		christian: {
			key: 'christian',
			// url: 'http://192.168.1.143:8000/',
			url: 'http://192.168.1.236:8000/',
			client_id: '606312',
			client_secret: 'a53f5cee353b3ef89d04dd9c624e8f590484157ec7c7090be2671b9b',
			auth_url: 'http://localhost:3002',
		},

		prod: {
			key: 'prod',
			url: 'https://skola.admentum.se/',
			client_id: '994706',
			client_secret: 'a180149d67308e8551aa2878c843c74fff14bb58a952d0b62e7c2ece',
			auth_url: 'https://auth.admentum.se',
		},

		demo: {
			key: 'demo',
			url: 'http://demo.admentum.se/',
			client_id: 'KkRTFQseTwFciv2bBEvm5Ie5hyQRaLJgvHWLPxyN',
			client_secret: 'dydGDwBVonarzjUzK3njVUAOl4CJ89ksZ8Yoz5USpI4oFJXmasfIv7fGlRFkgsVxFJgOngZnNsrCRPKeBkQXtl4XFz4wm3ouP7gLDRmSSVPahOtQPSDoIWa3mrBlDQnP',
		},

		develop: {
			key: 'develop',
			url: 'http://develop.admentum.se/',
			client_id: '407148',
			client_secret: '4fcb0536e0e7ae41e98705fdffe5e734b9faf19fb8ca135905e9950a',
			auth_url: 'https://auth.test.admentum.se',
		}
	}

};

const _CURRENT_BACKEND_KEY = localStorage.getItem('spBackendOverride') || _CONFIG.defaultBackend;
const _BACKEND = _CONFIG.backends[_CURRENT_BACKEND_KEY];

export default class Config {

	static getBuildNumber () {
		return _CONFIG.build;
	}

	static isProdEnv () {
		return _CURRENT_BACKEND_KEY === 'prod';
	}

	static getBackend () {
		return _BACKEND;
	}

	static getLanguage () {
		return localStorage.getItem('skolplatt_lang') || 'sv';
	}

	static getAssetUrl (path) {
		return Config.getBackendUrl() + 'static/app/assets/' + path;
	}

	static getBackendKey () {
		return _BACKEND.key;
	}

	static getBackendUrl () {
		return _BACKEND.url;
	}

	static getClientId () {
		return _BACKEND.client_id;
	}

	static getClientSecret () {
		return _BACKEND.client_secret;
	}

	static getSelectableEnvironments () {
		return [
			{ value: 'prod', label: 'Production' },
			{ value: 'demo', label: 'Demo' },
			{ value: 'develop', label: 'Develop' }
		];
	}

	static setBackend (backend) {
		if (backend !== _CURRENT_BACKEND_KEY) {
			if (backend === _CONFIG.defaultBackend) {
				localStorage.removeItem('spBackendOverride');
				localStorage.removeItem('bundlePathOverride'); // Used by cordova
			} else {
				localStorage.setItem('spBackendOverride', backend);

				// Set bundlePathOverride which is used in cordova.
				const bundlePath = _CONFIG.backends[backend].url + 'static/app/bundle.js';
				localStorage.setItem('bundlePathOverride', bundlePath);
			}
			window.location.reload();
		}
	}

	static setLanguage (lang) {
		const currentLang = this.getLanguage();
		localStorage.setItem('skolplatt_lang', lang);

		if (lang !== currentLang) {
			window.location.reload();
		}
	}

	static getAuthUrl () {
		return _BACKEND.auth_url + '/openid/token';
	}

	static getLogoutUrl () {
		return _BACKEND.auth_url + '/logout/';
	}
}

export const ExternalLinks = {
	forgotPassword: 'https://auth.admentum.se/user/password/reset/',
	openPlatform: 'https://skola.admentum.se',
};
