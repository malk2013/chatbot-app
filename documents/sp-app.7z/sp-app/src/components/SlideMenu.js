import PropTypes from 'prop-types';
import React from 'react';
import { Link } from 'react-router-dom';
import classnames from 'classnames';
import ExternalLink from './ExternalLink';
import { gettext, LOC_KEYS } from '../core/Texts';
import { ExternalLinks } from '../config';

const SlideMenu = props => {
	const {account, user} = props;

	return (
		<nav className={props.className}>
			<div className="menu-item border-bottom-main">
				<div>
					{ gettext(LOC_KEYS.LOGGED_IN_AS, { name: user.full_name }) }
				</div>

				{(user.isParentWithSingleChild()) && (
					<div>
						{ gettext(LOC_KEYS.SHOWING_INFO_FOR) } {user.activeChild.first_name}
					</div>
				)}

				<div className="lighter-main">
					{user.school.name}
				</div>

				<div className="center pts mts">
					<button onClick={props.logoutUser} className="btn btn-inverse">
						{ gettext(LOC_KEYS.LOG_OUT) }
					</button>
				</div>
			</div>

			{(account.users.length > 1) && (
				<div className="menu-item lighter-main border-bottom-main">
					<p>{ gettext(LOC_KEYS.SWITCH_ACCOUNTS) }</p>
					{account.users.map(accountUser => {
						return (
							<div
								key={accountUser.id}
								className={classnames({
									active: (accountUser.id === user.id)
								}, 'btn btn-select-user btn-user')}
								onClick={() => props.setActiveUser(accountUser.id)}
							>
								<span>{accountUser.role_display}</span>
								<span>{accountUser.school}</span>
							</div>
						);
					})}
				</div>
			)}

			{(user.isParentWithMultipleChildrens()) && (
				<div className="menu-item lighter-main border-bottom-main">
					<p>{ gettext(LOC_KEYS.SHOWING_INFO_FOR) }</p>
					{user.children.map(child => {
						return (
							<div
								key={child.id}
								className={classnames({
									active: (child.id === user.activeChild.id)
								}, 'btn btn-select-user btn-child')}
								onClick={() => props.setActiveChild(child.id)}
							>{child.first_name}</div>
						);
					})}
				</div>
			)}


			<div className="center pts">
				<Link to="/about" onClick={props.closeMenu} className="menu-link">{ gettext(LOC_KEYS.ABOUT_SKOLPLATT) }</Link>
				<ExternalLink
					className="menu-link"
					text={ gettext(LOC_KEYS.OPEN_SKOLPLATT_BROWSER )}
					url={ ExternalLinks.openPlatform }
					icon={true}
				/>
				<a className="close-link" onClick={props.closeMenu}>{ gettext(LOC_KEYS.CLOSE_MENU) }</a>
			</div>
		</nav>
	);

};

SlideMenu.propTypes = {
	user: PropTypes.object.isRequired
};

export default SlideMenu;