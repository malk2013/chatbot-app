import PropTypes from 'prop-types';
import React from 'react';
import Image from './Image';

const HomeButton = props => {

	return (
		<div className="home-button dark-main" onClick={props.onClick}>

			{props.icon && (
				<Image src={'icons/' + props.icon} />
			)}
			{props.urlIcon && (
				<Image
					src={props.urlIcon}
					isFullPath={true}
				/>
			)}

			<div className="lbl">{props.text}</div>

			{!!props.notification && (
				<i className="icon icon-unread">{props.notification}</i>
			)}
		</div>
	);

};

HomeButton.propTypes = {
	icon: PropTypes.string,
	urlIcon: PropTypes.string,
	text: PropTypes.string.isRequired,
	onClick: PropTypes.func.isRequired,
	notification: PropTypes.number,
};

export default HomeButton;