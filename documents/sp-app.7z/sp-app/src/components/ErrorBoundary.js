import React, { Component } from 'react';
import PropTypes from 'prop-types';

/**
 * An ErrorBoundary that can be added anywhere as a standalone component
 * `<ErrorBoundary />` with a provided error prop and render prop, or
 * with children to catch all Errors thrown by the children.
 * 
 * A standalone works well for labels while the component with childred
 * works best for handling thrown Errors.
 * 
 * @param {bool} showChild
 * @param {func} render 
 */
export default class ErrorBoundary extends Component {
	static propTypes = {
		/** Show the child element, useful for labels */
		showChild: PropTypes.bool,
		/** A render function to render instead of default */
		render: PropTypes.func,
	};

	initialState = {
		hasError: false,
	}

	state = this.initialState
  
	componentDidCatch (error, info) {
		this.setState({ hasError: true, error, info });
	}
  
	render () {
		const { children, showChild } = this.props;
		if (this.props.hasError || this.state.hasError) {
			if (showChild) {
				if(this.props.render)
					return([
						this.props.render(),
						children
					]);
				else [<h1>Something went wrong.</h1>, children];
			}
			return this.props.render 
				? this.props.render()
				: <h1>Something went wrong.</h1>;
		}
		return children || null;
	}
}