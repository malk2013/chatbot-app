import React, { Component } from 'react';
import moment from 'moment';
import PropTypes from 'prop-types';
import ErrorBoundary from '__components/ErrorBoundary';
import DayPicker from 'react-day-picker';
import TimeRange from '__components/TimeRange';

import { gettext, LOC_KEYS } from '../core/Texts';

class DateTimePicker extends Component {

	static propTypes = {
		error: PropTypes.oneOfType([PropTypes.bool, PropTypes.object]),
		resetErrors: PropTypes.func,
		items: PropTypes.array,
	}

	initialState = {
		selectedDay: undefined,
		start_time: undefined,
		end_time: undefined,
		showSelected: {},
	}

	state = this.initialState;

	componentDidUpdate (prevProps) {
		// If a new item is in included it should be selected
		if (prevProps.items.length !== this.props.items.length) {
			let newState = {
				selectedDay: undefined,
				start_time: undefined,
				end_time: undefined,
				showSelected: {}
			};

			if (this.props.items.length > prevProps.items.length) {
				let newItems = this.props.items.filter(item => !prevProps.items.some(prevItem => item.id === prevItem.id));
				if (newItems.length) {
					newState.showSelected = newItems[0];
					newState.selectedDay = new Date(newItems[0].date);
				}
			}

			this.setState(newState);
		}

		return false;
	}


	handleDayClick = (day, { selected, reported }) => {
		const date = day.toISOString().slice(0, 10);
		const item = this.props.items.find(sick => sick.date == date);

		if (this.props.error) {
			this.props.resetErrors();
		}

		this.setState(previousState => ({
			...previousState,
			showSelected: (selected && reported && previousState.showSelected == item)
				? {}
				: item,
			selectedDay: selected ? undefined : day
		}));
	};

	handleInputChange = (name, val) => {
		this.setState(previousState => ({
			...previousState,
			[name]: val
		}));
	}

	/**
	 * Function to reset the end time and start time depending on if
	 * the
	 * @param {bool} reset
	 */
	resetTime = ( reset ) => {
		this.setState(() => ({
			start_time: reset ? this.state.start_time : undefined,
			end_time: reset ? undefined : this.state.end_time
		}));
	}

	render () {
		const { error, items, TimeRangeLabel } = this.props;
		const { showSelected = {} } = this.state;

		const fromMonth = moment().toDate();
		const toMonth = moment().add(4, 'weeks').toDate();
		const pastSelected = !!(showSelected.id && (showSelected.moment_date < fromMonth)) || false;

		const modifiers = {
			reported: items && items.map(item => item.moment_date.toDate())
		};

		let components = [
			<ErrorBoundary key='error-date' hasError={!!error.date}
				render={() => (<i className='error'> { gettext(LOC_KEYS.DTP_PICK_DATE_LABEL) }</i>)} />,
			<DayPicker
				key='daypicker'
				onDayClick={this.handleDayClick}
				selectedDays={this.state.selectedDay}
				disabledDays={[{ daysOfWeek: [0, 6]}, {after: toMonth, before: fromMonth}]}
				months={gettext(LOC_KEYS.MONTHS)}
				weekdaysShort={gettext(LOC_KEYS.DAYS_SHORT)}
				fromMonth={fromMonth}
				toMonth={toMonth}
				modifiers={modifiers}
				showWeekNumbers
			/>,
			<TimeRangeLabel key='time-label' showSelected={showSelected} selectedDay={this.state.selectedDay} />
		];

		if (showSelected.id) {
			components = [
				...components,
				<div key="time-interval" className="mbs">
					{showSelected.start_time.format('HH:mm')} - {showSelected.end_time.format('HH:mm')}
				</div>
			];
		} else if (this.state.selectedDay) {
			components = [
				...components,
				<ErrorBoundary
					key='error-start-time'
					hasError={!!error.start_time}
					render={() => (
						<i className='error'> { error.start_time } </i>
					)}
				/>,
				<ErrorBoundary
					key='error-end-time'
					hasError={!error.start_time && !!error.end_time}
					render={() => (
						<i className='error'> { error.end_time } </i>
					)}
				/>,
				<TimeRange
					key='time-range'
					className="pas"
					start_time={showSelected.start_time || this.state.start_time}
					end_time={showSelected.end_time || this.state.end_time}
					label="Press a box to choose time"
					onChange={this.handleInputChange}
					resetEnd={this.resetTime}
					disabled={!!showSelected.id}
				/>,
			];
		}

		return [
			...components,
			this.props.children({ ...this.state, pastSelected })
		];
	}
}

export default DateTimePicker;