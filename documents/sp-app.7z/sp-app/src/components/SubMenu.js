import React from 'react';
import propTypes from 'prop-types';

const SubMenu = ({ items }) =>
	<div className='sub-menu'>
		<ul>
			{ items.map((item, index) => 
				<li key={index} onClick={item.onClick}> { item.text }</li>
			)}
		</ul>
	</div>;

SubMenu.propPypes = {
	items: propTypes.arrayOf(propTypes.string)
};

export default SubMenu;