import PropTypes from 'prop-types';
import React, { Component } from 'react';
import Select from 'react-select';


class SelectWeek extends Component {

	addWeeks (weeks, start, end, prekey) {
		for (let i=start; i<=end; i++) {
			weeks.push({
				label: prekey + i,
				value: i
			});
		}
	}

	render () {
		const {start, end} = this.props;
		const prekey = this.props.prekey || 'v.';
		let weeks = [];


		if (end > start) {
			this.addWeeks(weeks, start, end, prekey);
		} else {
			this.addWeeks(weeks, start, 52, prekey);
			this.addWeeks(weeks, 1, end, prekey);
		}

		return (
			<Select
				clearable={false}
				name={this.props.name || 'form-field-name'}
				value={this.props.value}
				options={weeks}
				onChange={(e) => this.props.onChange(e)}
			/>
		);
	}
}

SelectWeek.propTypes = {
	className: PropTypes.string,
	checked: PropTypes.bool,
	name: PropTypes.string,
	onChange: PropTypes.func.isRequired,
	prekey: PropTypes.string,
	value: PropTypes.number
};

export default SelectWeek;