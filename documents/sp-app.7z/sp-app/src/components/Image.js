import PropTypes from 'prop-types';
import React, { Component } from 'react';
import classnames from 'classnames';
import Utils from '../core/Utils';


let loadedImages = {};

class Image extends Component {

	constructor (props) {
		super(props);
		this.state = {
			loaded: typeof loadedImages[this.props.src] !== 'undefined',
			error: false
		};
	}

	onError () {
		this.setState({error: true});
	}

	onLoad () {
		loadedImages[this.props.src] = true;
		this.setState({loaded: true});
	}

	render () {
		const {loaded, error} = this.state;
		let imageSrc;
		let styles = Object.assign({
			width: this.props.width,
			height: this.props.height
		}, this.props.style);

		let containerClasses = classnames({
			clickable: !!this.props.onClick,
			disabled: this.props.disabled,
			'has-background': this.props.asBackgound
		}, 'image-container', this.props.className);

		// let classes = 'image';
		let classes = classnames({
			visible: loaded,
			error: error
		});

		// If component has prop fallback and the image wont load, an "image-not-loaded" icon will appear instead
		// and the image will take up no space (height 0)
		// let notLoadedContent = (error && !loaded && this.props.fallback) ? <Icon name="noimage" size="large"/> : null;

		// If we're not supplying a full path to a file we check if the file can be fetched from disk as it should be
		// bundled with the app. If not we fetch it from the CDN.
		if (!this.props.isFullPath) {
			imageSrc = Utils.getImagePath(this.props.src);
		} else {
			imageSrc = this.props.src;
			// imageSrc = '/src/assets/img/' + this.props.src;
		}

		let backgroundImage;
		if (this.props.asBackgound) {
			backgroundImage = (
				<div
					className={'background-image ' + classes}
					style={{backgroundImage: 'url(' + imageSrc + ')'}}
				/>
			);
		}

		return (
			<div className={containerClasses} style={styles} onClick={this.props.onClick}>
				<img className={classes} src={imageSrc} onLoad={this.onLoad.bind(this)} onError={this.onError}/>
				{backgroundImage}
			</div>
		);
	}
}


Image.propTypes = {
	src: PropTypes.string.isRequired,
	disabled: PropTypes.bool,
	asBackgound: PropTypes.bool,
	isFullPath: PropTypes.bool
};

export default Image;