import PropTypes from 'prop-types';
import React from 'react';
import Button from '../components/Button';
import { gettext, LOC_KEYS } from '../core/Texts';


const AbsenceRow = props => {
	const {absence} = props;

	return (
		<div className="main-box clearfix">
			<div className="pull-left">
				<h4>{absence.lesson.info.subject}</h4>
				<p>
					{ absence.lesson.date + ', kl ' + absence.lesson.info.time }
				</p>
			</div>
			<Button
				onClick={() => {props.history.push('/absence/' + absence.id);}}
				text={ gettext(LOC_KEYS.SHOW )}
				className="pull-right"
			/>
		</div>
	);

};

AbsenceRow.propTypes = {
	user: PropTypes.object.isRequired,
	absence: PropTypes.object.isRequired,
	history: PropTypes.shape({
		push: PropTypes.func.isRequired
	}).isRequired
};

export default AbsenceRow;