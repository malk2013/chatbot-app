import PropTypes from 'prop-types';
import React from 'react';
import Image from './Image';

const IconButton = props => {
	const imageStyle = props.imageStyle || {};

	return (
		<div
			className={'icon-button ' + props.className || ''}
			onClick={props.onClick}
		>
			<div className="inner" style={{ backgroundColor: props.backgroundColor || ''}}>
				{props.icon && (
					<Image src={'icons/' + props.icon} style={imageStyle} />
				)}
				{props.urlIcon && (
					<Image
						src={props.urlIcon}
						isFullPath={true}
						style={imageStyle}
					/>
				)}
			</div>

			{props.label && (
				<p className="label">{props.label}</p>
			)}
		</div>
	);

};

IconButton.propTypes = {
	backgroundColor: PropTypes.string,
	className: PropTypes.string,
	icon: PropTypes.string,
	label: PropTypes.string,
	urlIcon: PropTypes.string,
	onClick: PropTypes.func.isRequired
};

export default IconButton;