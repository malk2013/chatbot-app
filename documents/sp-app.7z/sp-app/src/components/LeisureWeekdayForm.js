import React, { Component } from 'react';
import moment from 'moment';
import Select from 'react-select';
import TimePicker from 'rc-time-picker';
import { gettext, LOC_KEYS } from '../core/Texts';

const ACTIVE_OPTIONS = [
	{ value: 1, label: gettext(LOC_KEYS.YES) },
	{ value: 0, label: gettext(LOC_KEYS.NO) }
];

const FORM_FIELDS_LABEL_MAP = {
	start: gettext(LOC_KEYS.LEISURE_LEAVE),
	end: gettext(LOC_KEYS.LEISURE_GET)
};

class LeisureWeekdayForm extends Component {

	constructor (props) {
		super(props);
		const {instance} = props;

		this.state = {
			active: instance.is_active,
			start: moment(instance.start_time || '08:00', 'HH:mm'),
			end: moment(instance.end_time || '17:00', 'HH:mm'),
			comment: instance.comment
		};
	}

	getValues () {
		return Object.assign({}, this.state, {
			start: this.state.start.format('HH:mm'),
			end: this.state.end.format('HH:mm'),
			comment: this.refs.comment ? this.refs.comment.value : ''
		});
	}

	handleValueChange (val, type) {
		this.state[type] = val;
		this.forceUpdate();
	}

	render () {
		const _this = this;
		const {errors} = this.props;

		return (
			<div>
				{errors && (
					Object.keys(errors).map(function (key, i) {
						return (
							<div className="error phm ptm" key={'error' + i}>
								<b>{FORM_FIELDS_LABEL_MAP[key]}</b>
								<p>{errors[key]}</p>
							</div>
						);
					})
				)}

				<div className="content padded pbn">

					<div className="form-group">
						<label> {gettext(LOC_KEYS.LEISURE_LEAVE_INFO, {name: this.props.user.activeChild.first_name})}</label>
						<Select
							clearable={false}
							name="select-active"
							value={this.state.active ? 1 : 0}
							options={ACTIVE_OPTIONS}
							onChange={(val) => this.handleValueChange(val.value, 'active')}
						/>
					</div>
					{!!this.state.active && (
						<div>
							<div className="form-group">
								<label>{ gettext(LOC_KEYS.LEISURE_LEAVE) } </label>
								<TimePicker
									showSecond={false}
									value={this.state.start}
									onChange={(val) => _this.handleValueChange(val, 'start')}
									addon={(panel) => (
										<a
											style={{
												display: 'inline-block',
												padding: '4px 10px'
											}}
											onClick={(e) => {
												e.preventDefault();
												e.stopPropagation();
												panel.close();
											}}
										>{ gettext(LOC_KEYS.TIME_SELECT) }</a>
									)}
								/>
							</div>
							<div className="form-group">
								<label> {gettext(LOC_KEYS.LEISURE_GET)} </label>
								<TimePicker
									showSecond={false}
									value={this.state.end}
									onChange={(val) => _this.handleValueChange(val, 'end')}
									addon={(panel) => (
										<a
											style={{
												display: 'inline-block',
												padding: '4px 10px'
											}}
											onClick={(e) => {
												e.preventDefault();
												e.stopPropagation();
												panel.close();
											}}
										>{ gettext(LOC_KEYS.TIME_SELECT) }</a>
									)}
								/>
							</div>
							<div className="form-group">
								<label> {gettext(LOC_KEYS.COMMENT)}</label>
								<textarea className="form-control" ref="comment" defaultValue={this.state.comment} />
							</div>
						</div>
					)}
				</div>

			</div>
		);
	}
}

export default LeisureWeekdayForm;
