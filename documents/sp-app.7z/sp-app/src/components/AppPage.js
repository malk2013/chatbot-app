import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';

const AppPage = props => {
	const classes = classnames({}, 'app-page main-bgr', props.className);

	return (
		<div {...props} className={classes}>
			{props.children}
		</div>
	);
};

AppPage.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([PropTypes.element, PropTypes.array])
};

export const AppPageContent = ({ className, title, children }) =>
	<AppPage className={className}>
		<div className="container">
			<header className="center">
				<h2>{ title }</h2>
			</header>
			<div className='content'>
				{ children }
			</div>
		</div>
	</AppPage>;

AppPageContent.propTypes = {
	className: PropTypes.string,
	title: PropTypes.string,
	children: PropTypes.element || PropTypes.array,
};

export default AppPage;