import PropTypes from 'prop-types';
import React from 'react';
import Button, {SIZES} from './Button';


const ModalsController = props => {
	if (!props.modals.length) {
		return <div></div>;
	}

	return (
		<div className="modals-container">
			{props.modals.map((modal, i) => {
				return (
					<div key={'modal-' + i} role="dialog" className="modal">

						<div className="modal-content">
							<header>
								<h3 className="modal-title">{modal.title}</h3>
							</header>
							<div className="modal-body">
								<p>{modal.body}</p>
							</div>
							<footer>
								{modal.buttons.map((btn, j) => {
									return <Button
										key={'btn-' + i + '-' + j}
										text={btn.label}
										onClick={btn.onClick}
										size={SIZES.LARGE}
									/>;
								})}
							</footer>
						</div>

					</div>
				);
			})}
		</div>
	);

};

ModalsController.propTypes = {
	modals: PropTypes.array.isRequired
};

export default ModalsController;