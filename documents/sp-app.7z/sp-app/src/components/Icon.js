import PropTypes from 'prop-types';
import React from 'react';

const Icon = props => {
	let output;

	if (props.onClick) {
		output = (
			<div className={'icon-link ' + (props.className || '')} onClick={props.onClick}>
				<span className={'icon fui-' + props.name}></span>
			</div>
		);
	} else {
		output = <span className={'icon fui-' + props.name + ' ' + (props.className || '')}></span>;
	}

	return output;
};

Icon.propTypes = {
	name: PropTypes.string.isRequired,
	onClick: PropTypes.func
};

export default Icon;