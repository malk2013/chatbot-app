import PropTypes from 'prop-types';
import React from 'react';
import classnames from 'classnames';
import Config from '../config';
import Image from './Image';


const Avatar = props => {
	const classes = classnames({
		'avatar': true,
		'default-avatar': !props.src
	}, props.size, props.className);

	const src = props.src ? props.src : Config.getAssetUrl('default-avatar.svg');

	return (
		<Image
			className={classes}
			src={src}
			isFullPath={true}
		/>
	);
};

Avatar.propTypes = {
	src: PropTypes.string.isRequired
};

export default Avatar;