import PropTypes from 'prop-types';
import React from 'react';
import { Link } from 'react-router-dom';
import classnames from 'classnames';

const LessonBox = props => {
	const { lesson, sectionCount } = props;

	const SECTION_HEIGHT = 25;

	var height = Math.min(
		Math.max(lesson.intervals * SECTION_HEIGHT + 1, 20),
		sectionCount * SECTION_HEIGHT - lesson.start_pos * SECTION_HEIGHT
	);
	var thin = (lesson.pos_per_width != 1);

	let classes = classnames({
		tiny: height <= 20,
		thin: thin,
	}, 'lesson', props.className);



	return (
		<Link to={props.to}
			className={classes}
			style={{
				top: (lesson.start_pos * SECTION_HEIGHT + 24) + 'px',
				width: lesson.pos_per_width * 100 + '%',
				height: height + 'px',
				left: lesson.pos_per_start * 100 + '%'
			}}>
			<div className="info" style={{ backgroundColor: lesson.color }}>
				{lesson.subject_code && (
					<span className="subject">
						{lesson.subject_code}
					</span>
				)}
				{lesson.teachers && (
					<span className="teacher">
						{lesson.teachers}
					</span>
				)}
				{lesson.lesson_info && (
					<span>{lesson.lesson_info}</span>
				)}
			</div>
		</Link>
	);

};

LessonBox.propTypes = {
	lesson: PropTypes.object.isRequired,
	sectionCount: PropTypes.number.isRequired
};

export default LessonBox;