import PropTypes from 'prop-types';
import React from 'react';
import { Link } from 'react-router-dom';
import classnames from 'classnames';


export const SIZES = {
	LARGE: 'large'
};


const Button = props => {
	const type = props.type || 'primary';
	const classes = classnames({
		'lg': props.size === SIZES.LARGE
	}, 'btn btn-' + type, props.className);


	let btn;
	if (props.onClick) {
		btn = <a onClick={props.onClick} className={classes} disabled={props.disabled}>{props.text}</a>;
	} else {
		btn = <Link to={props.to} className={classes} disabled={props.disabled}>{props.text}</Link>;
	}

	return btn;
};

Button.propTypes = {
	text: PropTypes.string.isRequired,
	to: PropTypes.string,
	type: PropTypes.string
};

export default Button;