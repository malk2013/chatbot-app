import PropTypes from 'prop-types';
import React, { Component } from 'react';
import classnames from 'classnames';
import Utils from '../core/Utils';
import { gettext, LOC_KEYS } from '../core/Texts';



class ConversationItem extends Component {

	get_formatted_date (date) {
		var now = new Date();
		var last = new Date(date);
		var diff_days = (now - last) / (60 * 60 * 24 * 1000);
		if (diff_days > 7) {
			return Utils.format_date('%a %n', last);
		} else {
			return Utils.format_date('%l', last);
		}
	}

	render () {
		const {conversation} = this.props;

		let sender;
		let title;
		let conversationUsers;

		if (conversation.title) {
			title = (
				<div className="title">
					{conversation.title}
				</div>
			);
		}

		if (conversation.creator.id !== this.props.user.id) {
			if (!conversation.recipients.users || conversation.recipients.users.length !== 2) {
				sender = (
					<div className="sender">
						{conversation.creator.first_name} {conversation.creator.last_name}
					</div>
				);
			}
		}

		conversationUsers = (
			<div className="users">
				{conversation.recipients.formatted}
			</div>
		);

		const classes = classnames({
			'unread': !conversation.is_read
		}, 'conversation-box');

		return (
			<div className={classes} onClick={this.props.onClick}>
				<div className="head">
					{title}
					{sender}
					{conversationUsers}
					<span className="date">{this.get_formatted_date(conversation.updated_at)}</span>
				</div>
				<i className="body">{conversation.last_message_body}</i>
			</div>
		);

	}

}

ConversationItem.propTypes = {
	user: PropTypes.object.isRequired,
	onClick: PropTypes.func.isRequired,
	conversation: PropTypes.object.isRequired
};

export default ConversationItem;