import PropTypes from 'prop-types';
import React from 'react';
import Linkify from 'react-linkify';

const LineBreakText = props => {
	let addMargin = false;
	return (
		<div className={props.className}>
			{props.text.split('\n').map((row, index) => {
				if (!row) {
					addMargin = true;
					return false;
				}

				let style = {};
				if (addMargin) {
					style.marginTop = '10px';
					addMargin = false;
				}

				return (
					<p key={index} style={style}>
						<Linkify properties={{target: '_blank'}}>
							{row}
						</Linkify>
					</p>
				);
			}).filter(row => row)}
		</div>
	);

};

LineBreakText.propTypes = {
	text: PropTypes.string.isRequired
};

export default LineBreakText;