import PropTypes from 'prop-types';
import React from 'react';


const Checkbox = props => {
	return (
		<input
			type="checkbox"
			className={'checkbox ' + (props.className || '')}
			checked={props.checked}
			value={props.value || '1'}
			onChange={() => props.onChange(!props.checked)}
		/>
	);
};

Checkbox.propTypes = {
	className: PropTypes.string,
	checked: PropTypes.bool,
	onChange: PropTypes.func.isRequired,
	value: PropTypes.string
};

export default Checkbox;