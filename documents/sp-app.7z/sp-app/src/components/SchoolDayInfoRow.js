import PropTypes from 'prop-types';
import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../components/Icon';

const SchoolDayInfoRow = props => {
	let output;
	let info;

	info = props.content.split('\n').map((txt, i) => {
		return <span key={i}>{txt}</span>;
	});

	const content = (
		<div>
			<Icon name={props.icon} />
			<strong>{props.title}</strong>
			{info}
		</div>
	);

	if (props.link) {
		output = (
			<Link to={props.link}>
				{content}
			</Link>
		);
	} else {
		output = content;
	}

	return (
		<li>
			{output}
		</li>
	);

};

SchoolDayInfoRow.propTypes = {
	icon: PropTypes.string.isRequired,
	link: PropTypes.string,
	title: PropTypes.string.isRequired,
	content: PropTypes.string.isRequired,
};

export default SchoolDayInfoRow;