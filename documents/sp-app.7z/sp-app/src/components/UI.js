import React, { Component } from 'react';

import { UI as UIHelp} from '../core/Constants';
import classnames from 'classnames';
import { TransitionGroup, CSSTransition } from 'react-transition-group';
import { Switch } from 'react-router';
import Slideout from '../core/Slideout';

import NavBar from '../components/NavBar';
import ModalsController from '../components/ModalsController';
import SlideMenu from '../components/SlideMenu';
import Swiper from '../components/Swiper';


class UI extends Component {

	componentDidMount () {
		this.slideOut = false;
		if (this.props.user && this.props.user.id) {
			if (!this.props.user.isStudent() && window.StatusBar) {
				window.StatusBar.backgroundColorByHexString('#2e87c1');
			}
		}

		this.setupSlideout();
	}

	componentDidUpdate (prevProps) {
		this.setupSlideout();

		if (this.slideOut && prevProps.menuOpen !== this.props.menuOpen) {
			if (this.props.menuOpen) {
				this.slideOut.open();
			} else {
				this.slideOut.close();
			}
		}
	}

	setupSlideout () {
		if (this.props.account.id && this.refs.main && !this.slideOut) {
			this.slideOut = new Slideout({
				panel: this.refs.main,
				menu: this.refs.menu,
				width: 320,
				tolerance: 70,
				openMenu: this.props.openMenu,
				closeMenu: this.props.closeMenu,
			});
		}
	}

	render () {
		const { account, user } = this.props;
		const classes = classnames({
			'main-container': true,
		}, user.id && user.getStyleRoleClass());

		return (
			<div className={classes} key="main">
				{this.props.menuOpen && (
					<div className="menu-overlay" onClick={this.props.closeMenu}></div>
				)}

				<div className="main-content dark-main-bgr" ref="main">
					<NavBar history={this.props.history} />

					<Swiper menuOpen={this.props.menuOpen} history={this.props.history}>
						{user.id &&
							<TransitionGroup>
								<CSSTransition
									key={this.props.location.key}
									classNames={this.props.history.action === 'PUSH' ? 'page-slide-left' : 'page-slide-right'}
									timeout={{ exit: UIHelp.ANIMATION_DURATION, enter: UIHelp.ANIMATION_DURATION }}>
									<Switch location={this.props.location}>
										{ this.props.children }
									</Switch>
								</CSSTransition>
							</TransitionGroup>
						}
					</Swiper>
				</div>

				<div className="menu-container dark-main-bgr" ref="menu">
					<SlideMenu
						className="right-menu"
						account={account}
						user={user}
						logoutUser={this.props.logoutUser}
						setActiveChild={this.props.setActiveChild}
						setActiveUser={this.props.setActiveUser}
						closeMenu={this.props.closeMenu}
					/>
				</div>

				<ModalsController modals={this.props.dialogs} />
			</div>);
	}
}

export default UI;