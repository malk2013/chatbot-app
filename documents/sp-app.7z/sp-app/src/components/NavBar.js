import React  from 'react';
import { CSSTransition, TransitionGroup } from 'react-transition-group';

import BackButton from './BackButton';
import Image from './Image';

import { routes } from '../routes';

const Navbar = ({ history }) => {

	// Construct page title from route titles.
	// TODO: not the prettiest of solutions
	const pathname = history.location.pathname.split('/')[1];
	const cleanedRoutes = routes.map(({ path, title }) => ({path: path.split('/')[1], title }));
	const matches = cleanedRoutes.filter(({ path }) => path == pathname);

	let title = undefined;
	if(matches.length) {
		const match = matches.pop();
		title = match.title;
	}
	// <Image key="logo" src="admentum-logo-inv.png" className="logo" />
	const pageTitle = (!title)
		? <div className="admentum-logo" />
		: <h1 key={title} className="page-title">{title}</h1>;

	const isBackBtnVisible = (
		history.location.pathname !== '/home' &&
		history.location.pathname !== '/' &&
		!history.location.pathname.includes('index.html')
	);

	return (
		<nav className='navbar navbar-default lighter-main-bgr'>
			<TransitionGroup>
				{isBackBtnVisible &&
					<CSSTransition
						key="back-button"
						classNames="btn-scale"
						timeout={{ exit: 500, enter: 500 }}>
						<BackButton
							onClick={history.goBack}
						/>
					</CSSTransition>
				}

				<CSSTransition
					key={title || 'logo'}
					classNames="nav-title"
					timeout={{ exit: 550, enter: 550 }}>
					{ pageTitle }
				</CSSTransition>
			</TransitionGroup>
		</nav>
	);
};

export default Navbar;
