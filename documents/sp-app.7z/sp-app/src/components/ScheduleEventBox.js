import PropTypes from 'prop-types';
import React from 'react';
import classnames from 'classnames';

const ScheduleEventBox = props => {
	const { event, sectionCount } = props;
	const SECTION_HEIGHT = 25;

	let height = Math.min(
		Math.max(event.intervals * SECTION_HEIGHT + 1, 20),
		sectionCount * SECTION_HEIGHT - event.start_pos * SECTION_HEIGHT
	);

	const classNames = classnames({
		'entire-day': event.entire_day
	}, 'event');

	return (
		<div
			className={classNames}
			style={{
				top: event.entire_day ? 0 : (event.start_pos * SECTION_HEIGHT + 24) + 'px',
				width: 100 + '%',
				height: event.entire_day ? '100%' : height + 'px'
			}}
		>
			<span className="subject">
				{event.label}
			</span>
		</div>
	);

};

ScheduleEventBox.propTypes = {
	event: PropTypes.object.isRequired,
	sectionCount: PropTypes.number.isRequired
};

export default ScheduleEventBox;