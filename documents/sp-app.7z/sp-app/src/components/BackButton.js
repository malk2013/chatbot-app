import PropTypes from 'prop-types';
import React from 'react';

const BackButton = props => {
	return (
		<div className="back-button-wrapper" onClick={props.onClick}>
			<div className="back-button main-bgr">
				<i className="icon"></i>
			</div>
		</div>
	);
};

BackButton.propTypes = {
	onClick: PropTypes.func.isRequired,
};

export default BackButton;