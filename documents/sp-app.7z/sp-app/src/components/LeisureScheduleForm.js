import React, { Component } from 'react';

import SelectWeekWithYear from '../components/SelectWeekWithYear';
import { gettext, LOC_KEYS } from '../core/Texts';


class LeisureScheduleForm extends Component {

	constructor (props) {
		super(props);

		this.state = {
			startYear: this.props.startYear,
			startWeek: this.props.startWeek,
			endYear: this.props.endYear,
			endWeek: this.props.endWeek
		};
	}

	getDays () {
		return this.state.days;
	}

	handleValueChange (val, key) {
		this.setState({
			[key]: val.value
		});
	}

	render () {
		return (
			<div className="leisure-schedule-form mvm">
				<div className="form-group">
					<label> { gettext(LOC_KEYS.AS_OF_WEEK) } </label>
					<SelectWeekWithYear
						ref="startWeek"
						name="start-week"
						startYear={this.props.startYear}
						startWeek={this.props.startWeek}
						endYear={this.props.endYear}
						endWeek={34}
						value={this.state.startYear + '-' + this.state.startWeek}
						onChange={(val) => {
							const values = val.value.split('-');
							this.setState({
								startYear: values[0],
								startWeek: values[1],
							});
						}}
					/>
				</div>

				<div className="form-group">
					<label> { gettext(LOC_KEYS.THROUGH_WEEK) }</label>
					<SelectWeekWithYear
						ref="endWeek"
						name="end-week"
						startYear={this.props.startYear}
						startWeek={this.props.startWeek}
						endYear={this.props.endYear}
						endWeek={34}
						value={this.state.endYear + '-' + this.state.endWeek}
						onChange={(val) => {
							const values = val.value.split('-');
							this.setState({
								endYear: values[0],
								endWeek: values[1],
							});
						}}
					/>
				</div>
			</div>
		);
	}
}

export default LeisureScheduleForm;
