import PropTypes from 'prop-types';
import React from 'react';
import { gettext, LOC_KEYS } from '../core/Texts';

const ErrorPage = props => {
	return (
		<div className="app-page error-page">
			<div className="container">
				<div className="content pal center">
					<p className="mbl">{props.text}</p>

					{props.retry && (
						<a onClick={props.retry} className="btn btn-main">{props.btnText || gettext(LOC_KEYS.TRY_AGAIN)}</a>
					)}
				</div>
			</div>
		</div>
	);
};

ErrorPage.propTypes = {
	text: PropTypes.string.isRequired,
	btnText: PropTypes.string,
	retry: PropTypes.func
};

export default ErrorPage;