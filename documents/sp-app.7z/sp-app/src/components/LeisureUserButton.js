import PropTypes from 'prop-types';
import React from 'react';
import Avatar from './Avatar';

const LeisureUserButton = props => {
	const {user} = props;

	let times = '-';
	if (props.schedule) {
		const startTime = props.schedule.start_time;
		const endTime = props.schedule.end_time;
		if (startTime && startTime !== 'None' && endTime && endTime !== 'None') {
			times = startTime.substr(0, 5) + ' - ' + endTime.substr(0, 5);
		}
	}


	return (
		<div
			className={'leisure-user-button ' + (props.checked ? 'checked' : '') + ' ' + (props.className || '')}
			onClick={props.onClick}
		>
			<Avatar
				src={user.avatar}
			/>

			{props.goHome && (
				<div className="go-home-circle">
					<span className="fui-home"></span>
				</div>
			)}

			<p className="name">
				{user.full_name}
			</p>

			{(props.showTimes) && (
				<p style={{fontSize: '12px'}}>{times}</p>
			)}
		</div>
	);

};

LeisureUserButton.propTypes = {
	user: PropTypes.object.isRequired,
	onClick: PropTypes.func
};

export default LeisureUserButton;