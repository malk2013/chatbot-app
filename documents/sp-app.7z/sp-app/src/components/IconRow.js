import PropTypes from 'prop-types';
import React from 'react';
import Image from './Image';


const IconRow = props => {

	return (
		<div className="icon-row">
			<Image src={'icons/' + props.icon} />
			<div className="info">
				<h4>{props.label}</h4>
				{props.value && (
					<strong>{props.value}</strong>
				)}
				{props.valueArr && (
					props.valueArr.map((value, index) => {
						return <strong key={index}>{value}</strong>;
					})
				)}
			</div>
		</div>
	);

};

IconRow.propTypes = {
	icon: PropTypes.string.isRequired,
	label: PropTypes.string.isRequired,
	value: PropTypes.string,
	valueArr: PropTypes.array
};

export default IconRow;