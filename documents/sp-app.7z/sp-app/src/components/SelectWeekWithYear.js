import PropTypes from 'prop-types';
import React, { Component } from 'react';
import Select from 'react-select';


class SelectWeekWithYear extends Component {

	render () {
		const {startYear, startWeek, endYear, endWeek} = this.props;
		let weeks = [];

		let currentYear = startYear;
		let currentWeek = startWeek;
		let safe = 1000;
		while (safe-- > 0) {
			weeks.push({
				label: 'v.' + currentWeek,
				value: currentYear + '-' + currentWeek
			});
			currentWeek++;
			if (currentWeek > 52) {
				currentWeek = 1;
				currentYear++;
			}
			if (currentYear > endYear || currentYear == endYear && currentWeek > endWeek) {
				break;
			}
		}

		return (
			<Select
				clearable={false}
				name={this.props.name || 'form-field-name'}
				value={this.props.value}
				options={weeks}
				onChange={(e) => this.props.onChange(e)}
			/>
		);
	}
}

SelectWeekWithYear.propTypes = {
	className: PropTypes.string,
	name: PropTypes.string,
	onChange: PropTypes.func.isRequired,
	value: PropTypes.string,
	startYear: PropTypes.number.isRequired,
	startWeek: PropTypes.number.isRequired,
	endYear: PropTypes.number.isRequired,
	endWeek: PropTypes.number.isRequired
};

export default SelectWeekWithYear;
