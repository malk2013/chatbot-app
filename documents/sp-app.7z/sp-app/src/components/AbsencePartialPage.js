import React, { Component } from 'react';
import { AppPageContent } from '__components/AppPage';
import ErrorBoundary from '__components/ErrorBoundary';
import Button from '__components/Button';
import DateTimePicker from '__components/DateTimePicker';
import Spinner from '__components/Spinner';
import { gettext, LOC_KEYS } from '../core/Texts';
import Utils from '../core/Utils';

const RenderProps = {
	TimeRangeLabel: (({ showSelected, selectedDay }) => (
		<div>
			<strong className="selected-day-title">{selectedDay ? Utils.format_date('%a %F', selectedDay) : ''}</strong>
			<label>
				{
					showSelected.id
						? gettext(LOC_KEYS.PRESENCE_PARTIAL_REPORTED_TR_LABEL,
							{name: showSelected.user.first_name})
						: selectedDay
							? gettext(LOC_KEYS.PRESENCE_PARTIAL_TR_LABEL_NEW)
							: gettext(LOC_KEYS.PRESENCE_PARTIAL_TR_LABEL)
				}
			</label>
		</div>
	)),
	CommentLabel: (({showSelected }) => (
		<label> {showSelected.id
			? gettext(LOC_KEYS.PRESENCE_PARTIAL_REPORTED_COMMENT_LABEL)
			: gettext(LOC_KEYS.PRESENCE_PARTIAL_COMMENT_LABEL)}
		</label>)),
	Action: (props => {
		let buttonProps = { className: 'mts' };
		if (props.pastAbsenceSelected) {
			return '';
			// return <i className='pas'>{gettext(LOC_KEYS.PRESENCE_PARTIAL_REPORTED_PAST_LABEL)}</i>;
		} else if (props.showReported.id) {
			buttonProps = { ...buttonProps,
				text: gettext(LOC_KEYS.DELETE),
				onClick: props.remove,
			};
		} else {
			buttonProps = { ...buttonProps,
				text: gettext(LOC_KEYS.PRESENCE_PARTIAL_CONFIRM_BUTTON),
				onClick: props.report,
			};
		}
		return <Button {...buttonProps} />;
	}),
};

export default class AbsencePartial extends Component {

	state = { comment: ''}

	componentDidMount () {
		if(!this.props.sicknessList.length) {
			this.props.fetch(this.props.activeChildId);
		}
	}

	componentDidUpdate (prevProps) {
		if(this.props.isFetching) return;
		if(!this.props.sicknessList.length && !this.props.isFetched) {
			this.handleInputChange('comment', '');
			return this.props.fetch(this.props.activeChildId);
		}
		/** Account for deleting or adding an absence */
		if(prevProps.sicknessList.length == 0
			&& (prevProps.sicknessList.length
			!== this.props.sicknessList.length)) {
			this.setState({
				comment: '',
			});
		}
		return false;
	}

	handleInputChange = (name, val) => {
		this.setState(previousState => ({
			...previousState,
			[name]: val
		}));
	}

	dateTimePickerRender = ({ start_time, end_time, selectedDay, showSelected = {}, pastSelected }) => {
		const { activeChildId: id, error, report, remove } = this.props;
		const { comment } = this.state;

		if (!selectedDay) {
			return [];
		}

		let label = <RenderProps.CommentLabel key='comment-label' showSelected={showSelected} />;
		let btn = <RenderProps.Action
			key='absence-action'
			report={() => report({ id, date: selectedDay, start_time, end_time, comment })}
			remove={() => remove(id, showSelected.id)}
			showReported={showSelected}
			pastAbsenceSelected={pastSelected}
		/>;

		if (showSelected.id) {
			return ([
				label,
				<div key="display-comment">
					<i>{showSelected.comment}</i>
				</div>,
				btn
			]);
		}

		return ([
			label,
			<ErrorBoundary
				key='error-comment'
				hasError={!!error.comment}
				render={() => (
					<i className='error'> {gettext(LOC_KEYS.PRESENCE_PARTIAL_ERROR_COMMENT_LABEL)} </i>
				)}
			/>,
			<input
				key='absence-comment'
				className='form-control mvs'
				type='text'
				placeholder={gettext(LOC_KEYS.PRESENCE_PARTIAL_COMMENT)}
				value={showSelected.comment || comment }
				onChange={(e) => this.handleInputChange('comment', e.target.value)}
				disabled={!!showSelected.id}
			/>,
			btn
		]);
	}

	render () {
		const { error, sicknessList, resetErrors } = this.props;

		return (
			<AppPageContent
				title={gettext(LOC_KEYS.PRESENCE_BUTTON_PARTIAL)}
				className='absence-partial-page'
			>
				<div className='center-items pam'>
					<p>
						{ gettext(LOC_KEYS.PRESENCE_PARTIAL_EXPLANATION) }
					</p>
					<DateTimePicker
						error={error}
						resetErrors={resetErrors}
						reset={this.reset}
						items={sicknessList}
						TimeRangeLabel={RenderProps.TimeRangeLabel}
						children={this.dateTimePickerRender}
					/>

					{this.props.isFetching && (
						<Spinner />
					)}
				</div>
			</AppPageContent>
		);
	}
}