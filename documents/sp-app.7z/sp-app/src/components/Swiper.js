import React, { Component } from 'react';
import Swipe from 'react-easy-swipe';

class Swiper extends Component {

	onSwipeMove (position) {
		this.swipeHorzMove = position.x;
	}

	onSwipeRight () {
		const history = this.props.history;
		if (!this.ignoreSwipe && this.swipeHorzMove > 100 && history.location.pathname !== '/home') {
			history.goBack();
		}
	}

	onSwipeStart () {
		this.swipeHorzMove = 0;
		this.ignoreSwipe = this.props.menuOpen;
	}

	render () {
		return (
			<div>
				<Swipe
					onSwipeStart={this.onSwipeStart.bind(this)}
					onSwipeMove={this.onSwipeMove.bind(this)}
					onSwipeRight={this.onSwipeRight.bind(this)}
				>
					{this.props.children}
				</Swipe>
			</div>
		);
	}
}

export default Swiper;