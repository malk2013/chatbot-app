import PropTypes from 'prop-types';
import React, { Component } from 'react';

import Icon from './Icon';


class ExternalLink extends Component {

	onClick () {
		if (window.cordova && window.cordova.InAppBrowser) {
			window.cordova.InAppBrowser.open(this.props.url, '_system');
		} else {
			window.open(this.props.url, '_blank');
		}
	}

	render () {
		return (
			<a onClick={this.onClick.bind(this)} className={this.props.className || ''}>
				{this.props.text}
				{this.props.icon && (
					<Icon name="export" />
				)}
			</a>
		);
	}

}

ExternalLink.propTypes = {
	url: PropTypes.string.isRequired,
	text: PropTypes.string.isRequired,
	className: PropTypes.string,
	icon: PropTypes.bool
};

export default ExternalLink;