import { get_data_with_auid } from '../core/Api_v2';
import React, { Component } from 'react';
import Select from 'react-select';


class MessageSelect extends Component {

	getOptions (input, callback) {
		if (!input) {
			callback(null, { complete: true });
		} else {

			get_data_with_auid('api/messages/recipients-search?q=' + encodeURIComponent(input))
				.then((response) => {
					callback(null, {
						options: response.data,
						complete: true
					});
				});
		}
	}

	logChange (val) {
		this.props.setMessageRecipient(val);
	}

	render () {
		return (
			<Select.Async
				autoBlur={true}
				autosize={false}
				searchable
				name="form-field-name"
				multi={true}
				ignoreAccents={false}
				joinValues={true}
				value={this.props.value}
				loadOptions={this.getOptions}
				isLoading={true}
				onChange={this.logChange.bind(this)}
				placeholder="Välj..."
				clearValueText="Rensa"
				noResultsText="Inga personer hittades"
				searchPromptText="Skriv för att söka"
			/>
		);
	}
}

export default MessageSelect;




