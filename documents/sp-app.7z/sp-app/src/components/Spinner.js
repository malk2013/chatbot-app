import PropTypes from 'prop-types';
import React from 'react';
import classnames from 'classnames';

const Spinner = props => {

	let classes = classnames({
		verticalMargin: !!props.verticalMargin,
		inverted: !!props.inverted,
		fullscreen: !!props.fullscreen,
	}, 'sk-spinner sk-spinner-three-bounce', props.className);


	return (
		<div className={classes}>
			<div className="sk-bounce1"></div>
			<div className="sk-bounce2"></div>
			<div className="sk-bounce3"></div>
		</div>
	);
};

Spinner.propTypes = {
	verticalMargin: PropTypes.bool,
	inverted: PropTypes.bool,
	fullscreen: PropTypes.bool
};

export default Spinner;