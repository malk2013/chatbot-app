import React, { Component } from 'react';
import TimePicker from 'rc-time-picker';
import moment from 'moment';

import Utils from '../core/Utils';
import Checkbox from './Checkbox';
import { gettext, LOC_KEYS } from '../core/Texts';

const WEEK_DAYS = gettext(LOC_KEYS.WEEK_DAYS);
const DROP = gettext(LOC_KEYS.LEISURE_LEAVE);
const GET = gettext(LOC_KEYS.LEISURE_GET);

let numArray = [0, 1, 2, 3, 4];
const FORM_FIELDS_LABEL_MAP = numArray.reduce((labels, num) => ({ ...labels,
	[`day${num}_start`]: `${DROP} - ${WEEK_DAYS[num]}`,
	[`day${num}_end`]: `${GET} - ${WEEK_DAYS[num]}`,
}), {});

class LeisureScheduleWeekForm extends Component {

	constructor (props) {
		super(props);
		const {default_week} = props;
		let dayNames = Utils.getDayNames();
		const defaultStartTime = moment('08:00', 'HH:mm');
		const defaultEndTime = moment('17:00', 'HH:mm');

		this.state = {
			days: [0, 1, 2, 3, 4].map(function (i) {
				let startTime, endTime, isActive;
				if (default_week) {
					if (default_week['day' + i + '_active']) {
						startTime = moment(default_week['day' + i + '_start'], 'HH:mm');
						endTime = moment(default_week['day' + i + '_end'], 'HH:mm');
						isActive = true;
					} else {
						startTime = defaultStartTime;
						endTime = defaultEndTime;
						isActive = false;
					}
				} else {
					startTime = defaultStartTime;
					endTime = defaultEndTime;
					isActive = true;
				}

				return {
					weekday: i,
					name: dayNames[i + 1],
					start: startTime,
					end: endTime,
					isActive: isActive
				};
			})
		};
	}

	getDays () {
		let days = Object.assign(...this.state.days.map(day => ({
			[day.weekday]: {
				start: day.start.format('HH:mm'),
				end: day.end.format('HH:mm'),
				active: day.isActive
			}
		})));

		return JSON.stringify(days);
	}

	handleValueChange (weekday, val, type) {
		weekday[type] = val;
		this.forceUpdate();
	}

	render () {
		const _this = this;
		const {days} = this.state;
		const {errors} = this.props;

		return (
			<div className="mas">
				{errors && (
					Object.keys(errors).map(function (key, i) {
						return (
							<div className="error" key={'error' + i}>
								<b>{FORM_FIELDS_LABEL_MAP[key]}</b>
								<p>{errors[key]}</p>
							</div>
						);
					})
				)}


				<table className="table leisure-schedule-table">
					<thead>
						<tr>
							<th> { gettext(LOC_KEYS.DAY) }</th>
							<th className="center"> { DROP }</th>
							<th className="center"> { GET }</th>
							<th className="center">&nbsp;</th>
						</tr>
					</thead>
					<tbody>
						{days.map(function (weekday) {
							return (
								<tr key={weekday.weekday}>
									<td className="weekday-name">{weekday.name}</td>
									<td>
										{weekday.isActive && (
											<TimePicker
												showSecond={false}
												value={weekday.start}
												onChange={(val) => _this.handleValueChange(weekday, val, 'start')}
												addon={(panel) => (
													<a
														style={{
															display: 'inline-block',
															padding: '4px 10px'
														}}
														onClick={(e) => {
															e.preventDefault();
															e.stopPropagation();
															panel.close();
														}}
													>{ gettext(LOC_KEYS.TIME_SELECT) }</a>
												)}
											/>
										)}
										{!weekday.isActive && (
											<span className="not-active center">-</span>
										)}
									</td>
									<td>
										{weekday.isActive && (
											<TimePicker
												showSecond={false}
												value={weekday.end}
												onChange={(val) => _this.handleValueChange(weekday, val, 'end')}
												addon={(panel) => (
													<a
														style={{
															display: 'inline-block',
															padding: '4px 10px'
														}}
														onClick={(e) => {
															e.preventDefault();
															e.stopPropagation();
															panel.close();
														}}
													>{ gettext(LOC_KEYS.TIME_SELECT) }</a>
												)}
											/>
										)}
										{!weekday.isActive && (
											<span className="not-active center">-</span>
										)}
									</td>
									<td>
										<Checkbox
											checked={weekday.isActive}
											onChange={(val) => _this.handleValueChange(weekday, val, 'isActive')}
										/>
									</td>
								</tr>
							);
						})}
					</tbody>
				</table>
			</div>
		);
	}
}

export default LeisureScheduleWeekForm;
