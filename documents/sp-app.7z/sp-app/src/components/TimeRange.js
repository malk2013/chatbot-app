import React, { Component } from 'react';
import TimePicker from 'rc-time-picker';
import { gettext, LOC_KEYS } from '../core/Texts';
import Button from './Button';
import moment from 'moment';

const timePickerStyle = `.rc-time-picker-panel-inner {
	display: flex;
	flex-wrap: wrap;
	justify-content: center;
}`;

const CloseButton = ({ panel }) =>
	<Button text="OK" onClick={(e) => {
		e.preventDefault();
		e.stopPropagation();
		panel.close();
	}} />;

class TimeRange extends Component {
	static defaultProps = {
		minuteStepper: 5,
		disabledHours: [0, 1, 2, 3, 4, 5, 6, 19, 20, 21, 22, 23],
		resetEnd: () => {},
	}

	initialState = {
		start_timeSet: false,
	}

	state = this.initialState;

	resetEndTime = ({ open }) => {
		/** Set for the internal knowledge of disabled hours and minutes */
		this.setState({
			start_timeSet: !open && this.props.start_time,
		});
		/** Clear the endtime if start_time is later */
		if (this.props.start_time > this.props.end_time) {
			this.props.resetEnd( !open );
		}
	}

	disabledHours = () => {
		let disabled = [ ...this.props.disabledHours ];
		if (this.state.start_timeSet && this.props.start_time) {
			const selectedTime = this.props.start_time.hours();
			// TODO: 4 hours is now hardcoded here
			let appropiateAbsence = [];
			for(let value=selectedTime; value <= (selectedTime + 4); value++) {
				appropiateAbsence.push(value);
			}
			for(let value=7; value < 19; value++) {
				if(!appropiateAbsence.includes(value)) {
					disabled.push(value);
				}
			}

		}
		return disabled;
	}

	disabledMinutes = (h) => {
		const arr = [];
		const minStep = this.props.minuteStepper;
		for(let value=0; value < 60; value++) {
			if(value % minStep) arr.push(value);
		}
		if (this.state.start_timeSet) {
			const selectedHour = this.props.start_time.hours();
			const selectedMinutes = this.props.start_time.minutes();
			if(h == selectedHour) {
				for(let value=0; value <= selectedMinutes; value=value+minStep) {
					arr.push(value);
				}
			}
			if(h == selectedHour+4) {
				for(let value=55; value > selectedMinutes; value=value-minStep) {
					arr.push(value);
				}
			}
		}
		return arr;
	}

	commonProps = ({
		disabledHours: this.disabledHours,
		disabledMinutes: this.disabledMinutes,
		showSecond: false,
		hideDisabledOptions: true,
		minuteStep: this.props.minuteStepper,
		addon: ((panel) => <CloseButton panel={panel} />),
	});

	render () {
		const { start_time, end_time, className } = this.props;
		const defaultTime = moment('09:00', 'HH:mm');
		return (
			<div className={`time-range ${className}`}>
				<style>{timePickerStyle} </style>
				<TimePicker
					value={start_time}
					onChange={(val) => this.props.onChange('start_time', val)}
					onClose={this.resetEndTime}
					onOpen={this.resetEndTime}
					placeholder={gettext(LOC_KEYS.TIME_RANGE_START)}
					defaultOpenValue={defaultTime}
					disabled={this.props.disabled}
					{ ...this.commonProps }
				/>
				<TimePicker
					value={end_time}
					onChange={(val) => this.props.onChange('end_time', val)}
					placeholder={gettext(LOC_KEYS.TIME_RANGE_END)}
					defaultOpenValue={start_time}
					disabled={this.props.disabled}
					{ ...this.commonProps }
				/>
			</div>
		);
	}
}

export default TimeRange;