import PropTypes from 'prop-types';
import React, { Component } from 'react';

import LineBreakText from '../components/LineBreakText';

class MessageBox extends Component {

	render () {
		const {message} = this.props;

		return (
			<div className="message-box" onClick={this.props.onClick}>
				<div className="head">
					<strong>{message.creator.first_name + ' ' + message.creator.last_name}</strong>
					<span className="date">{message.created_at}</span>
				</div>
				<LineBreakText className="body" text={message.body} />
			</div>
		);

	}

}

MessageBox.propTypes = {
	message: PropTypes.object.isRequired
};

export default MessageBox;