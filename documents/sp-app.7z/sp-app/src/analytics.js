
export default class Analytics {

	static  startTracker () {
		if (window.appVersion && window.ga) {
			window.ga.startTrackerWithId('UA-109071345-3', 30);
			window.ga.setAppVersion(window.appVersion);
		}
	}

	static setUserId (userId) {
		if (window.ga && userId) {
			window.ga.setUserId(userId);
		}
	}

	static trackView (view) {
		if (window.ga) {
			window.ga.trackView(view);
		}
	}

}
