import React, { Component } from 'react';
import { connect } from 'react-redux';


export default function withUser (WrappedComponent) {
    const WithUser = props => {
        return <WrappedComponent {...props} />;
    };

    const mapStateToProps = (state) => {
		const { auth } = state;
		const { user } = auth;

		return {
			user
		};
	};

    return connect(mapStateToProps)(WithUser);
}