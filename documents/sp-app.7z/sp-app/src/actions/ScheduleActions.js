import { fetch } from '../core/Api_v2';

export const FETCH_SCHEDULE_REQUEST = 'FETCH_SCHEDULE_REQUEST';
export const FETCH_SCHEDULE_SUCCESS = 'FETCH_SCHEDULE_SUCCESS';
export const FETCH_SCHEDULE_FAILURE = 'FETCH_SCHEDULE_FAILURE';

export const FETCH_LESSON_REQUEST = 'FETCH_LESSON_REQUEST';
export const FETCH_LESSON_SUCCESS = 'FETCH_LESSON_SUCCESS';
export const FETCH_LESSON_FAILURE = 'FETCH_LESSON_FAILURE';

export const SET_WEEKDAY = 'SET_WEEKDAY';
export const SHOW_PREV_DAY = 'SHOW_PREV_DAY';
export const SHOW_NEXT_DAY = 'SHOW_NEXT_DAY';
export const SHOW_PREV_WEEK = 'SHOW_PREV_WEEK';
export const SHOW_NEXT_WEEK = 'SHOW_NEXT_WEEK';

export const RESET_SCHEDULE = 'RESET_SCHEDULE';


// ****************************** Schedule ******************************
function requestSchedule () {
	return {
		type: FETCH_SCHEDULE_REQUEST
	};
}

function receiveSchedule (schedule) {
	return {
		type: FETCH_SCHEDULE_SUCCESS,
		schedule: schedule
	};
}

function scheduleError (message) {
	return {
		type: FETCH_SCHEDULE_FAILURE,
		message
	};
}

export function fetchSchedule (endpoint) {
	return fetch(endpoint, {
		request: requestSchedule,
		success: receiveSchedule,
		error: scheduleError
	});
}


// ****************************** Lesson ******************************
function requestLesson () {
	return {
		type: FETCH_LESSON_REQUEST
	};
}

function receiveLesson (lesson) {
	return {
		type: FETCH_LESSON_SUCCESS,
		lesson
	};
}

function errorLesson (message) {
	return {
		type: FETCH_LESSON_FAILURE,
		message
	};
}

export function fetchLesson (lessonId) {
	return fetch('api/schedule/lessons/' + lessonId, {
		request: requestLesson,
		success: receiveLesson,
		error: errorLesson
	});
}



export function setWeekday (weekday) {
	return {
		type: SET_WEEKDAY,
		weekday
	};
}

export function showPrevDay () {
	return {
		type: SHOW_PREV_DAY
	};
}

export function showNextDay () {
	return {
		type: SHOW_NEXT_DAY
	};
}

export function showPrevWeek () {
	return {
		type: SHOW_PREV_WEEK
	};
}

export function showNextWeek () {
	return {
		type: SHOW_NEXT_WEEK
	};
}

export function resetSchedule () {
	return {
		type: RESET_SCHEDULE
	};
}
