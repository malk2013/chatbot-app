import { fetch } from '../core/Api_v2';

export const FETCH_INFO_REQUEST = 'FETCH_INFO_REQUEST';
export const FETCH_INFO_SUCCESS = 'FETCH_INFO_SUCCESS';
export const FETCH_INFO_FAILURE = 'FETCH_INFO_FAILURE';
export const RESET_SCHOOL_DAY_INFO = 'RESET_SCHOOL_DAY_INFO';

function requestSchoolDayInfo () {
	return {
		type: FETCH_INFO_REQUEST
	};
}

function receiveSchoolDayInfo (schoolDayInfo) {
	return {
		type: FETCH_INFO_SUCCESS,
		schoolDayInfo: schoolDayInfo
	};
}

function schoolDayInfoError (message) {
	return {
		type: FETCH_INFO_FAILURE,
		message
	};
}

export function fetchSchoolDayInfo (activeChildId) {
	return fetch('api/users/' + activeChildId + '/school_day', {
		request: requestSchoolDayInfo,
		success: receiveSchoolDayInfo,
		error: schoolDayInfoError
	});
}

export function resetSchoolDayInfo () {
	return {
		type: RESET_SCHOOL_DAY_INFO
	};
}
