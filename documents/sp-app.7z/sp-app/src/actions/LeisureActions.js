import { push } from 'react-router-redux';
import Utils from '../core/Utils';

import { fetch, post } from '../core/Api_v2';

export const FETCH_LEISURE_INFO_REQUEST = 'FETCH_LEISURE_INFO_REQUEST';
export const FETCH_LEISURE_INFO_SUCCESS = 'FETCH_LEISURE_INFO_SUCCESS';
export const FETCH_LEISURE_INFO_FAILURE = 'FETCH_LEISURE_INFO_FAILURE';
export const RESET_LEISURE_INFO = 'RESET_LEISURE_INFO';

export const SAVE_LEISURE_SCHEDULE_REQUEST = 'SAVE_LEISURE_SCHEDULE_REQUEST';
export const SAVE_LEISURE_SCHEDULE_SUCCESS = 'SAVE_LEISURE_SCHEDULE_SUCCESS';
export const SAVE_LEISURE_SCHEDULE_FAILURE = 'SAVE_LEISURE_SCHEDULE_FAILURE';

export const DELETE_LEISURE_SCHEDULE_REQUEST = 'DELETE_LEISURE_SCHEDULE_REQUEST';
export const DELETE_LEISURE_SCHEDULE_SUCCESS = 'DELETE_LEISURE_SCHEDULE_SUCCESS';
export const DELETE_LEISURE_SCHEDULE_FAILURE = 'DELETE_LEISURE_SCHEDULE_FAILURE';

export const SAVE_DEFAULT_WEEK_REQUEST = 'SAVE_DEFAULT_WEEK_REQUEST';
export const SAVE_DEFAULT_WEEK_SUCCESS = 'SAVE_DEFAULT_WEEK_SUCCESS';
export const SAVE_DEFAULT_WEEK_FAILURE = 'SAVE_DEFAULT_WEEK_FAILURE';

export const SET_LEISURE_WEEK = 'SET_LEISURE_WEEK';
export const SHOW_PREV_LEISURE_DAY = 'SHOW_PREV_LEISURE_DAY';
export const SHOW_NEXT_LEISURE_DAY = 'SHOW_NEXT_LEISURE_DAY';
export const SHOW_LEISURE_DAY_IN_WEEK = 'SHOW_LEISURE_DAY_IN_WEEK';
export const SHOW_PREV_LEISURE_WEEK = 'SHOW_PREV_LEISURE_WEEK';
export const SHOW_NEXT_LEISURE_WEEK = 'SHOW_NEXT_LEISURE_WEEK';
export const FETCH_LEISURE_WEEK_REQUEST = 'FETCH_LEISURE_WEEK_REQUEST';
export const FETCH_LEISURE_WEEK_SUCCESS = 'FETCH_LEISURE_WEEK_SUCCESS';
export const FETCH_LEISURE_WEEK_FAILURE = 'FETCH_LEISURE_WEEK_FAILURE';

export const UPDATE_WEEKDAY_REQUEST = 'UPDATE_WEEKDAY_REQUEST';
export const UPDATE_WEEKDAY_SUCCESS = 'UPDATE_WEEKDAY_SUCCESS';
export const UPDATE_WEEKDAY_FAILURE = 'UPDATE_WEEKDAY_FAILURE';



// ****************************** Leisure info ******************************
function requestLeisureInfo () {
	return {
		type: FETCH_LEISURE_INFO_REQUEST
	};
}

function receiveLeisureInfo (response) {
	return {
		type: FETCH_LEISURE_INFO_SUCCESS,
		leisureInfo: response.leisure_info
	};
}

function leisureInfoError (message) {
	return {
		type: FETCH_LEISURE_INFO_FAILURE,
		message
	};
}

export function fetchLeisureInfo (activeChildId) {
	return fetch('api/users/' + activeChildId + '/leisure/info', {
		request: requestLeisureInfo,
		success: receiveLeisureInfo,
		error: leisureInfoError
	});
}

export function resetLeisureInfo () {
	return {
		type: RESET_LEISURE_INFO
	};
}



// ****************************** Save Leisure Schedule ******************************
function requestSaveLeisureSchedule () {
	return {
		type: SAVE_LEISURE_SCHEDULE_REQUEST
	};
}

function receiveSaveLeisureSchedule (response) {
	return {
		type: SAVE_LEISURE_SCHEDULE_SUCCESS,
		leisureInfo: response.leisure_info
	};
}

function saveLeisureScheduleError (message) {
	return {
		type: SAVE_LEISURE_SCHEDULE_FAILURE,
		message
	};
}

export function saveLeisureSchedule (activeChildId, startYear, startWeek, endYear, endWeek) {
	const postData = {
		userId: activeChildId,
		startYear: startYear,
		startWeek: startWeek,
		endYear: endYear,
		endWeek: endWeek,
		action: 'save-schedule'
	};

	return post('api/users/' + activeChildId + '/leisure/schedule', {
		request: requestSaveLeisureSchedule,
		success: receiveSaveLeisureSchedule,
		error: saveLeisureScheduleError
	}, Utils.serialize(postData));
}




// ****************************** Save Default Week ******************************
function requestSaveDefaultWeek () {
	return {
		type: SAVE_DEFAULT_WEEK_REQUEST
	};
}

function receiveSaveDefaultWeek (response) {
	return {
		type: SAVE_DEFAULT_WEEK_SUCCESS,
		leisureInfo: response.leisure_info
	};
}

function saveDefaultWeekError (data) {
	return {
		type: SAVE_DEFAULT_WEEK_FAILURE,
		errors: data.response.data
	};
}

export function saveDefaultWeek (activeChildId, days, successCallback) {
	const postData = {
		userId: activeChildId,
		days: days,
		action: 'save-default-week'
	};

	return post('api/users/' + activeChildId + '/leisure/schedule', {
		request: requestSaveDefaultWeek,
		success: receiveSaveDefaultWeek,
		error: saveDefaultWeekError,
		successCallback: successCallback
	}, Utils.serialize(postData));
}




// ****************************** Delete Leisure Schedule ******************************
function requestDeleteLeisureSchedule () {
	return {
		type: DELETE_LEISURE_SCHEDULE_REQUEST
	};
}

function receiveDeleteLeisureSchedule (response) {
	return {
		type: DELETE_LEISURE_SCHEDULE_SUCCESS,
		leisureInfo: response.leisure_info
	};
}

function deleteLeisureScheduleError (message) {
	return {
		type: DELETE_LEISURE_SCHEDULE_FAILURE,
		message
	};
}

export function deleteLeisureSchedule (activeChildId) {
	const postData = {
		userId: activeChildId,
		action: 'delete-schedule'
	};

	return post('api/users/' + activeChildId + '/leisure/schedule', {
		request: requestDeleteLeisureSchedule,
		success: receiveDeleteLeisureSchedule,
		error: deleteLeisureScheduleError,
		successCallback: ((response, dispatch) => {
			// TODO: This needs to be checked, possibly do the push in the component/container
			// else, make sure to have dispatch and dispatch the push
			dispatch(push('/leisure'));
		})
	}, Utils.serialize(postData));
}



// ****************************** Week navigation ******************************
function requestLeisureWeek () {
	return {
		type: FETCH_LEISURE_WEEK_REQUEST
	};
}

function receiveLeisureWeek (response) {
	return {
		type: FETCH_LEISURE_WEEK_SUCCESS,
		leisureWeek: response.leisure_week
	};
}

function leisureWeekError (message) {
	return {
		type: FETCH_LEISURE_WEEK_FAILURE,
		message
	};
}


export function setWeek (week, year, weekday) {
	return {
		type: SET_LEISURE_WEEK,
		week,
		weekday,
		year
	};
}

export function showPrevLeisureDay () {
	return {
		type: SHOW_PREV_LEISURE_DAY
	};
}

export function showPrevLeisureWeek () {
	return {
		type: SHOW_PREV_LEISURE_WEEK
	};
}

export function showNextLeisureWeek () {
	return {
		type: SHOW_NEXT_LEISURE_WEEK
	};
}

export function showNextLeisureDay () {
	return {
		type: SHOW_NEXT_LEISURE_DAY
	};
}

export function showLeisureDayInWeek (day) {
	return {
		type: SHOW_LEISURE_DAY_IN_WEEK,
		day: day
	};
}


export function fetchLeisureWeek (activeChildId, week, year) {
	return fetch('api/users/' + activeChildId + '/leisure/week/' + week + '/' + year, {
		request: requestLeisureWeek,
		success: receiveLeisureWeek,
		error: leisureWeekError
	});
}


// ****************************** Update weekday ******************************
function requestUpdateWeekday () {
	return {
		type: UPDATE_WEEKDAY_REQUEST
	};
}

function receiveUpdateWeekday (response) {
	return {
		type: UPDATE_WEEKDAY_SUCCESS,
		leisureWeek: response.leisure_week
	};
}

function updateWeekdayError (error) {
	return {
		type: UPDATE_WEEKDAY_FAILURE,
		message: error.response.data
	};
}

export function updateWeekday (data, successCallback) {
	const postData = {
		start: data.start,
		end: data.end,
		active: data.active,
		comment: data.comment,
		action: 'update-weekday'
	};

	return post('api/users/' + data.userId + '/leisure/weekday/' + data.date, {
		request: requestUpdateWeekday,
		success: receiveUpdateWeekday,
		error: updateWeekdayError,
		successCallback: successCallback
	}, Utils.serialize(postData));
}


