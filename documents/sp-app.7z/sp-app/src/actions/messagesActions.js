import { replace } from 'react-router-redux';

import { fetch, post } from '../core/Api_v2';

import Utils from '../core/Utils';

export const FETCH_CONVERSATIONS_REQUEST = 'FETCH_CONVERSATIONS_REQUEST';
export const FETCH_CONVERSATIONS_SUCCESS = 'FETCH_CONVERSATIONS_SUCCESS';
export const FETCH_CONVERSATIONS_FAILURE = 'FETCH_CONVERSATIONS_FAILURE';
export const SET_LAST_MESSAGE_BODY = 'SET_LAST_MESSAGE_BODY';
export const RESET_CONVERSATIONS = 'RESET_CONVERSATIONS';


export const FETCH_UNREAD_MESSAGES_COUNT_REQUEST = 'FETCH_UNREAD_MESSAGES_COUNT_REQUEST';
export const FETCH_UNREAD_MESSAGES_COUNT_SUCCESS = 'FETCH_UNREAD_MESSAGES_COUNT_SUCCESS';
export const FETCH_UNREAD_MESSAGES_COUNT_FAILURE = 'FETCH_UNREAD_MESSAGES_COUNT_FAILURE';

export const FETCH_CONVERSATION_REQUEST = 'FETCH_CONVERSATION_REQUEST';
export const FETCH_CONVERSATION_SUCCESS = 'FETCH_CONVERSATION_SUCCESS';
export const FETCH_CONVERSATION_FAILURE = 'FETCH_CONVERSATION_FAILURE';

export const POST_MESSAGE_REQUEST = 'POST_MESSAGE_REQUEST';
export const POST_MESSAGE_SUCCESS = 'POST_MESSAGE_SUCCESS';
export const POST_MESSAGE_FAILURE = 'POST_MESSAGE_FAILURE';

export const CREATE_CONVERSATION_REQUEST = 'CREATE_CONVERSATION_REQUEST';
export const CREATE_CONVERSATION_SUCCESS = 'CREATE_CONVERSATION_SUCCESS';
export const CREATE_CONVERSATION_FAILURE = 'CREATE_CONVERSATION_FAILURE';

export const TOGGLE_MESSAGE_FORM = 'TOGGLE_MESSAGE_FORM';
export const TOGGLE_RECIPIENTS = 'TOGGLE_RECIPIENTS';
export const SET_MESSAGE_RECIPIENT = 'SET_MESSAGE_RECIPIENT';


// ****************************** Unread message count ******************************
function requestUnreadMessageCount () {
	return {
		type: FETCH_UNREAD_MESSAGES_COUNT_REQUEST
	};
}

function receiveUnreadMessageCount (data) {
	return {
		type: FETCH_UNREAD_MESSAGES_COUNT_SUCCESS,
		count: data.unread_count,
		absenceCountMap: data.unconfirmed_absence_count_map || 0
	};
}

function errorUnreadMessageCount (message) {
	return {
		type: FETCH_UNREAD_MESSAGES_COUNT_FAILURE,
		message
	};
}

export function fetchUnreadMessageCount (userId) {
	return fetch('api/me/' + userId + '/unreadmessagecount', {
		request: requestUnreadMessageCount,
		success: receiveUnreadMessageCount,
		error: errorUnreadMessageCount
	});
}

/*
export function setUnreadMessagesCount () {
	return fetch('api/me/unreadmessagecount', {
		request: requestUnreadMessageCount,
		success: receiveUnreadMessageCount,
		error: errorUnreadMessageCount
	});
}
*/


// ****************************** Conversations ******************************
function requestConversations () {
	return {
		type: FETCH_CONVERSATIONS_REQUEST
	};
}

function receiveConversations (conversations, page) {
	return {
		type: FETCH_CONVERSATIONS_SUCCESS,
		conversations,
		page
	};
}

function conversationsError (message) {
	return {
		type: FETCH_CONVERSATIONS_FAILURE,
		message
	};
}

export function fetchConversations (userId, page) {
	return fetch('api/me/' + userId + '/conversations?page=' + page, {
		request: requestConversations,
		success: (conversations) => receiveConversations(conversations, page),
		error: conversationsError
	});
}

export function updateLastMessage (conversationId, lastMessageBody) {
	return {
		type: SET_LAST_MESSAGE_BODY,
		conversationId,
		lastMessageBody
	};
}

export function resetConversations () {
	return {
		type: RESET_CONVERSATIONS
	};
}



// ****************************** Single Conversation ******************************
function requestConversation () {
	return {
		type: FETCH_CONVERSATION_REQUEST
	};
}

function receiveConversation (conversation, page) {
	return {
		type: FETCH_CONVERSATION_SUCCESS,
		conversation,
		page
	};
}

function conversationError (message) {
	return {
		type: FETCH_CONVERSATION_FAILURE,
		message
	};
}

export function fetchConversation (conversationId) {
	return fetch('api/conversations/' + conversationId, {
		request: requestConversation,
		success: receiveConversation,
		error: conversationError
	});
}

export function toggleRecipients (conversationId) {
	return {
		type: TOGGLE_RECIPIENTS,
		conversationId
	};
}

export function toggleMessageForm (conversationId) {
	return {
		type: TOGGLE_MESSAGE_FORM,
		conversationId
	};
}

function requestPostMessage () {
	return {
		type: POST_MESSAGE_REQUEST
	};
}

function receivePostMessage (conversation) {
	return {
		type: POST_MESSAGE_SUCCESS,
		conversation
	};
}

function errorPostMessage (data) {
	return {
		type: POST_MESSAGE_FAILURE,
		message: (data.response && data.response.data)
			? data.response.data.message
			: false
	};
}

export function postMessage (conversationId, message) {
	return post('api/conversations/' + conversationId, {
		request: requestPostMessage,
		success: receivePostMessage,
		error: errorPostMessage
	}, 'message=' + encodeURIComponent(message));
}



// ****************************** Create conversation ******************************
function requestCreateConversation () {
	return {
		type: CREATE_CONVERSATION_REQUEST
	};
}

function receiveCreateConversation (data) {
	return {
		type: CREATE_CONVERSATION_SUCCESS,
		id: data.id,
	};
}

function createConversationError (data) {
	return {
		type: CREATE_CONVERSATION_FAILURE,
		message: (data.response && data.response.data)
			? data.response.data.message
			: false
	};
}

export const createConversation = (to, title, body) => {
	const postData = {
		to: to,
		title: title,
		body: body
	};

	return post('api/conversations/create', {
		request: requestCreateConversation,
		success: receiveCreateConversation,
		error: createConversationError,
		successCallback: ((conversation, dispatch) => {
			// TODO: This needs to be checked, possibly do the push in the component/container
			// else, make sure to have dispatch and dispatch the push
			dispatch(replace('/conversation/'+ conversation.id));
		})
	}, Utils.serialize(postData));
};


export function setMessageRecipient (value) {
	return {
		type: SET_MESSAGE_RECIPIENT,
		value
	};
}

