import { fetch, post, remove } from '../core/Api_v2';

export const FETCH_SICKNESS_STATUS_REQUEST = 'FETCH_SICKNESS_STATUS_REQUEST';
export const FETCH_SICKNESS_STATUS_SUCCESS = 'FETCH_SICKNESS_STATUS_SUCCESS';
export const FETCH_SICKNESS_STATUS_FAILURE = 'FETCH_SICKNESS_STATUS_FAILURE';

export const FETCH_SICKNESS_REPORT_REQUEST = 'FETCH_SICKNESS_REPORT_REQUEST';
export const FETCH_SICKNESS_REPORT_SUCCESS = 'FETCH_SICKNESS_REPORT_SUCCESS';
export const FETCH_SICKNESS_REPORT_FAILURE = 'FETCH_SICKNESS_REPORT_FAILURE';

export const RESET_SICKNESS_ERRORS = 'RESET_SCIKNESS_ERRORS';
export const RESET_SICKNESS_STATUS = 'RESET_SICKNESS_STATUS';

function requestSicknessStatus () {
	return {
		type: FETCH_SICKNESS_STATUS_REQUEST
	};
}

function receiveSicknessStatus (status) {
	return {
		type: FETCH_SICKNESS_STATUS_SUCCESS,
		status
	};
}

function sicknessStatusError (message) {
	return {
		type: FETCH_SICKNESS_STATUS_FAILURE,
		message
	};
}

export function fetchSicknessStatus (activeChildId) {
	return fetch('api/presence/sickness/report/' + activeChildId, {
		request: requestSicknessStatus,
		success: receiveSicknessStatus,
		error: sicknessStatusError
	});
}


function requestSicknessReport () {
	return {
		type: FETCH_SICKNESS_REPORT_REQUEST
	};
}

function receiveSicknessReport (status) {
	return {
		type: FETCH_SICKNESS_REPORT_SUCCESS,
		status
	};
}

function sicknessReportError (message) {
	return {
		type: FETCH_SICKNESS_REPORT_FAILURE,
		message
	};
}

function sicknessReportErrorMultiple (err) {
	return {
		type: FETCH_SICKNESS_REPORT_FAILURE,
		message: err.response.data.message,
	};
}

const sicknessActions = {
	request: requestSicknessReport,
	success: receiveSicknessReport,
	error: sicknessReportError
};

export function fetchPartialSickness (activeChildId) {
	return fetch(`api/presence/sickness/report-partial/${activeChildId}/`, sicknessActions);
}

export function reportPartialSickness ({ id: activeChildId, date, start_time, end_time, comment }) {
	const actions = { ...sicknessActions, success: resetSicknessStatus, error: sicknessReportErrorMultiple };
	return post(`api/presence/sickness/report-partial/${activeChildId}/`, actions, {
		date,
		start_time,
		end_time,
		comment
	});
}

export function reportCancelPartialSickness (activeChildId, sicknessId) {
	const actions = { ...sicknessActions, success: resetSicknessStatus, error: sicknessReportErrorMultiple };
	return remove(`api/presence/sickness/report-partial/${activeChildId}/${sicknessId}`, actions);
}

export function reportSickness (activeChildId) {
	return post(`api/presence/sickness/report/${activeChildId}`, sicknessActions);
}

export function reportCancelSickness (activeChildId) {
	return remove(`api/presence/sickness/report/${activeChildId}`, sicknessActions);
}

export function resetSicknessErrors () {
	return {
		type: RESET_SICKNESS_ERRORS
	};
}

export function resetSicknessStatus () {
	return {
		type: RESET_SICKNESS_STATUS
	};
}
