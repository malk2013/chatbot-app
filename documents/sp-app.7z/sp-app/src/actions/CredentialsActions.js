export const CredentialsActionTypes = {
	CLEAR_CREDENTIALS: 'CLEAR_CREDENTIALS',
	CHECK_CREDENTIALS: 'CHECK_CREDENTIALS',
	CHECK_CREDENTIALS_SUCCESS: 'CHECK_CREDENTIALS_SUCCESS',
	CHECK_CREDENTIALS_FAILURE: 'CHECK_CREDENTIALS_FAILURE',
	ADD_CREDENTIALS: 'ADD_CREDENTIALS',
	ADD_CREDENTIALS_SUCCESS: 'ADD_CREDENTIALS_SUCCESS',
	ADD_CREDENTIALS_FAILURE: 'ADD_CREDENTIALS_FAILURE'
};


export function clearCredentials () {
	return {
		type: CredentialsActionTypes.CLEAR_CREDENTIALS
	};
}
export function checkCredentials () {
	return {
		type: CredentialsActionTypes.CHECK_CREDENTIALS
	};
}
// TODO: doesn't seem to be used
export function checkCredentialsSucess () {
	return {
		type: CredentialsActionTypes.CHECK_CREDENTIALS_SUCCESS
	};
}
// TODO: doesn't seem to be used
export function checkCredentialsFailure () {
	return {
		type: CredentialsActionTypes.CHECK_CREDENTIALS_FAILURE
	};
}
export function addCredentials () {
	return {
		type: CredentialsActionTypes.ADD_CREDENTIALS
	};
}
export function addCredentialsSucess () {
	return {
		type: CredentialsActionTypes.ADD_CREDENTIALS_SUCCESS
	};
}
export function addCredentialsFailure (hint) {
	return {
		type: CredentialsActionTypes.ADD_CREDENTIALS_FAILURE,
		hint
	};
}
