export const SHOW_MODAL = 'SHOW_MODAL';
export const CLOSE_MODAL = 'CLOSE_MODAL';


export function showModal () {
	return {
		type: SHOW_MODAL
	};
}


export function closeModal () {
	return {
		type: CLOSE_MODAL
	};
}

export function showConfirmDialog (options) {
	return dispatch => {
		dispatch({
			type: SHOW_MODAL,
			options: Object.assign({
				type: 'confirm',
				buttons: [{
					label: 'Ja',
					onClick: () => {
						dispatch(closeModal());
						options.callback();
					}
				}, {
					label: 'Nej',
					onClick: () => {
						dispatch(closeModal());
					}
				}]
			}, options)
		});
	};
}
