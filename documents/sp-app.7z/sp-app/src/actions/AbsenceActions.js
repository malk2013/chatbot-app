import Utils from '../core/Utils';

import { fetch, post } from '../core/Api_v2';

export const FETCH_ABSENCES_REQUEST = 'FETCH_ABSENCES_REQUEST';
export const FETCH_ABSENCES_SUCCESS = 'FETCH_ABSENCES_SUCCESS';
export const FETCH_ABSENCES_FAILURE = 'FETCH_ABSENCES_FAILURE';

export const FETCH_ABSENCE_REQUEST = 'FETCH_ABSENCE_REQUEST';
export const FETCH_ABSENCE_SUCCESS = 'FETCH_ABSENCE_SUCCESS';
export const FETCH_ABSENCE_FAILURE = 'FETCH_ABSENCE_FAILURE';

export const TOGGLE_SHOW_CONFIRMED = 'TOGGLE_SHOW_CONFIRMED';

export const CONFIRM_ABSENCE_REQUEST = 'CONFIRM_ABSENCE_REQUEST';
export const CONFIRM_ABSENCE_SUCCESS = 'CONFIRM_ABSENCE_SUCCESS';
export const CONFIRM_ABSENCE_FAILURE = 'CONFIRM_ABSENCE_FAILURE';


// ****************************** Absences ******************************
const requestAbsences = (page) => ({
	type: FETCH_ABSENCES_REQUEST,
	page
});

const receiveAbsences = (data) => ({
	type: FETCH_ABSENCES_SUCCESS,
	...data,
});

const absencesError = (message) => ({
	type: FETCH_ABSENCES_FAILURE,
	message
});

export function fetchAbsences (activeChildId, page, confirmed) {
	let url = 'api/users/' + activeChildId + (confirmed ? '/confirmed_absence' : '/unconfirmed_absence');
	url += '?page=' + page;
	return fetch(url, {
		request: () => requestAbsences(page),
		success: (response) => receiveAbsences(response, page),
		error: absencesError
	});
}

export function fetchConfirmedAbsences (activeChildId) {
	return fetch('api/users/' + activeChildId + '/confirmed_absence', {
		request: requestAbsences,
		success: (response) => receiveAbsences(response),
		error: absencesError
	});
}


export const toggleShowConfirmed = () => ({
	type: TOGGLE_SHOW_CONFIRMED
});


// ****************************** Single absence ******************************
const requestAbsence = () => ({
	type: FETCH_ABSENCE_REQUEST
});

const receiveAbsence = (response) => ({
	type: FETCH_ABSENCE_SUCCESS,
	absence: response.absence
});

const absenceError = (message) => ({
	type: FETCH_ABSENCE_FAILURE,
	message
});

export function fetchAbsence (absenceId) {
	return fetch('api/presence/absence/' + absenceId, {
		request: requestAbsence,
		success: receiveAbsence,
		error: absenceError
	});
}


// ****************************** Confirm absence ******************************
const requestConfirmAbsence = () => ({
	type: CONFIRM_ABSENCE_REQUEST
});

const receiveConfirmAbsence = (response) => ({
	type: CONFIRM_ABSENCE_SUCCESS,
	absence: response.absence
});

const confirmAbsenceError = (message) => ({
	type: CONFIRM_ABSENCE_FAILURE,
	message
});

export function confirmAbsence (absenceId, userId) {
	return post('api/presence/absence/' + absenceId, {
		request: requestConfirmAbsence,
		success: receiveConfirmAbsence,
		error: confirmAbsenceError
	}, Utils.serialize({
		action: 'confirm',
		user_id: userId
	}));
}
