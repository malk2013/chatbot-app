import Utils from '../core/Utils';
import { fetch, post } from '../core/Api_v2';


export const FETCH_TEACHER_LEISURE_INFO_REQUEST = 'FETCH_TEACHER_LEISURE_INFO_REQUEST';
export const FETCH_TEACHER_LEISURE_INFO_SUCCESS = 'FETCH_TEACHER_LEISURE_INFO_SUCCESS';
export const FETCH_TEACHER_LEISURE_INFO_FAILURE = 'FETCH_TEACHER_LEISURE_INFO_FAILURE';

export const UPDATE_USER_LEISURE_REQUEST = 'UPDATE_USER_LEISURE_REQUEST';
export const UPDATE_USER_LEISURE_SUCCESS = 'UPDATE_USER_LEISURE_SUCCESS';
export const UPDATE_USER_LEISURE_FAILURE = 'UPDATE_USER_LEISURE_FAILURE';

export const SET_ACTIVE_LEISURE_GROUP = 'SET_ACTIVE_LEISURE_GROUP';



// ****************************** Teacher leisure info ******************************
function requestTeacherLeisureInfo () {
	return {
		type: FETCH_TEACHER_LEISURE_INFO_REQUEST
	};
}

function receiveTeacherLeisureInfo (response) {
	return {
		type: FETCH_TEACHER_LEISURE_INFO_SUCCESS,
		leisureInfo: response.leisure_info
	};
}

function teacherLeisureInfoError (message) {
	return {
		type: FETCH_TEACHER_LEISURE_INFO_FAILURE,
		message
	};
}

export function fetchTeacherLeisureInfo (leisureGroupId) {
	return fetch('api/leisure/group/' + leisureGroupId, {
		request: requestTeacherLeisureInfo,
		success: receiveTeacherLeisureInfo,
		error: teacherLeisureInfoError
	});
}


export function setActiveLeisureGroupId (activeLeisureGroupId) {
	return {
		type: SET_ACTIVE_LEISURE_GROUP,
		activeLeisureGroupId
	};
}


// ****************************** Register ******************************
function requestRegisterLeisureStart () {
	return {
		type: UPDATE_USER_LEISURE_REQUEST
	};
}

function receiveRegisterLeisureStart (response) {
	return {
		type: UPDATE_USER_LEISURE_SUCCESS,
		userId: response.user_id,
		leisureGroupId: response.leisure_group_id,
		weekday: response.weekday
	};
}

function registerLeisureStartError (message) {
	return {
		type: UPDATE_USER_LEISURE_FAILURE,
		message
	};
}

function registerLeisure (leisureGroupId, userId, action) {
	const postData = {
		userId: userId,
		action: action
	};

	return post('api/leisure/group/' + leisureGroupId, {
		request: requestRegisterLeisureStart,
		success: receiveRegisterLeisureStart,
		error: registerLeisureStartError
	}, Utils.serialize(postData));
}

export function registerLeisureStart (leisureGroupId, userId) {
	return registerLeisure(leisureGroupId, userId, 'register-start');
}

export function resetLeisureStart (leisureGroupId, userId) {
	return registerLeisure(leisureGroupId, userId, 'reset-start');
}

export function registerLeisureEnd (leisureGroupId, userId) {
	return registerLeisure(leisureGroupId, userId, 'register-end');
}
export function resetLeisureEnd (leisureGroupId, userId) {
	return registerLeisure(leisureGroupId, userId, 'reset-end');
}
