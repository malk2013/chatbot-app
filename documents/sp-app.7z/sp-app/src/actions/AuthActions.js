import Utils from '../core/Utils';
import Config from '../config';

import Analytics from '../analytics';
import { fetch, post, refreshToken, removeToken } from '../core/Api_v2';

import { resetSchoolDayInfo } from '../actions/HomeActions';
import { resetLeisureInfo } from '../actions/LeisureActions';
import { fetchUnreadMessageCount, resetConversations } from '../actions/MessagesActions';
import { resetSicknessStatus } from '../actions/PresenceActions';
import { resetSchedule } from '../actions/ScheduleActions';
import { closeMenu } from '../actions/UIActions';

export const REFRESH_TOKEN = 'REFRESH_TOKEN';

export const LOGIN_REQUEST = 'LOGIN_REQUEST';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAILURE = 'LOGIN_FAILURE';

export const LOGOUT_REQUEST = 'LOGOUT_REQUEST';
export const LOGOUT_SUCCESS = 'LOGOUT_SUCCESS';
export const LOGOUT_FAILURE = 'LOGOUT_FAILURE';

export const ACCOUNT_REQUEST = 'ACCOUNT_REQUEST';
export const ACCOUNT_SUCCESS = 'ACCOUNT_SUCCESS';
export const ACCOUNT_ERROR = 'ACCOUNT_ERROR';

export const USER_REQUEST = 'USER_REQUEST';
export const USER_SUCCESS = 'USER_SUCCESS';
export const USER_ERROR = 'USER_ERROR';

export const SET_ACTIVE_CHILD = 'SET_ACTIVE_CHILD';
export const SET_ACTIVE_USER = 'SET_ACTIVE_USER';

/*
const requestLogin = (creds) => ({
	type: LOGIN_REQUEST,
	creds
});
*/

export const receiveLogin = () => ({
	type: LOGIN_SUCCESS,
});

const loginError = (message) => ({
	type: LOGIN_FAILURE,
	message
});

const requestLogout = () => ({
	type: LOGOUT_REQUEST,
});

const receiveLogout = () => ({
	type: LOGOUT_SUCCESS,
});

const requestAccount = () => ({
	type: ACCOUNT_REQUEST,
});

const receiveAccount = (data) => ({
	type: ACCOUNT_SUCCESS,
	account: data.account,
	user: data.user,
	app_build: data.app_build
});

export const accountError = (message) => ({
	type: ACCOUNT_ERROR,
	message
});

const requestUser = () => ({
	type: USER_REQUEST,
});

const receiveUser = (data) => ({
	type: USER_SUCCESS,
	user: data
});

export const userError = (message) => ({
	type: USER_ERROR,
	message
});

export const serverError = () => ({
	type: ACCOUNT_ERROR,
	message: 'Anslutningen misslyckades'
});

export const refreshTokenTry = {
	type: REFRESH_TOKEN
};

export function loginUser (creds) {
	return dispatch => {
		dispatch(refreshTokenTry);
		return refreshToken(creds)
			.then(data => dispatch(receiveLogin(data)))
			.catch(err => {
				if (err && (err.error === 'invalid_grant' || err.error === 'invalid_request')) {
					dispatch(loginError('Felaktigt lösenord eller användarnamn'));
				} else {
					dispatch(loginError('Anslutningen till Admentum misslyckades'));
				}
			});
	};
}

export function logoutUser () {
	return dispatch => {
		return removeToken()
			.then(() => {
				dispatch(requestLogout());
				localStorage.removeItem('sp_access_token');
				localStorage.removeItem('sp_refresh_token');
				dispatch(resetSchoolDayInfo());
				dispatch(resetConversations());
				dispatch(resetLeisureInfo());
				dispatch(resetSchedule());
				dispatch(resetSicknessStatus());
				dispatch(closeMenu());
				dispatch(receiveLogout());})
			.catch(err => {
				console.log(err);
			});
	};
}

export function authenticatedUser(data) {
	return dispatch => {
		dispatch(receiveLogin(data))
	};
}

// Logs the user out
// export function logoutUser () {
// 	return dispatch => {
// 		dispatch(requestLogout());
// 		localStorage.removeItem('sp_access_token');
// 		localStorage.removeItem('sp_refresh_token');
// 		dispatch(resetSchoolDayInfo());
// 		dispatch(resetConversations());
// 		dispatch(resetLeisureInfo());
// 		dispatch(resetSchedule());
// 		dispatch(resetSicknessStatus());
// 		dispatch(closeMenu());
// 		dispatch(receiveLogout());
// 	};
// }

function _registerDevice (userId, dispatch) {
	if (window.plugins && window.plugins.OneSignal) {
		window.plugins.OneSignal.getIds(function (ids) {
			const postData = Object.assign({
				user_id: userId,
				one_signal_user_id: ids.userId,
				one_signal_push_token: ids.pushToken
			}, window.device);

			dispatch(post('api/me/device', {}, Utils.serialize(postData)));
		});
	}
}

function _resetAll (dispatch) {
	dispatch(resetConversations());
	dispatch(resetSchoolDayInfo());
	dispatch(resetSchedule());
	dispatch(resetSicknessStatus());
	dispatch(resetLeisureInfo());
}


export function fetchAccount () {
	return fetch('api/me/', {
		request: requestAccount,
		success: receiveAccount,
		error: (err => {
			return accountError(
				err.response && err.response.status === 405
					? 'NO_SP_USER'
					: 'Anslutningen misslyckades'
			);
		}),
		successCallback: ((data, dispatch) => {
			// Reload the page if a new bundle build is available.
			// We need to submit a native update to include build number
			// in bundle.js path.
			if (!localStorage.getItem('appCurrentBuild')) {
				localStorage.setItem('appCurrentBuild', Config.getBuildNumber());
			}
			if (data.app_build && data.app_build > localStorage.getItem('appCurrentBuild')) {
				localStorage.setItem('appCurrentBuild', data.app_build);
				window.location.reload();
			}


			Analytics.setUserId(data.user.id);

			localStorage.setItem('auid', data.user.id);
			Config.setLanguage(data.account.language);
			_registerDevice(data.user.id, dispatch);
		})
	});
}

function changeActiveChild (childId) {
	return {
		type: SET_ACTIVE_CHILD,
		childId
	};
}

export function setActiveChild (childId) {
	return dispatch => {
		dispatch(changeActiveChild(childId));
		dispatch(resetSchoolDayInfo());
		dispatch(resetSchedule());
		dispatch(resetSicknessStatus());
		dispatch(resetLeisureInfo());
	};
}

export function setActiveUser (userId) {
	return fetch('api/me/' + userId, {
		request: requestUser,
		success: receiveUser,
		error: userError,
		successCallback: ((userData, dispatch) => {
			localStorage.setItem('auid', userData.user.id);
			_registerDevice(userData.user.id, dispatch);
			_resetAll(dispatch);
			dispatch(fetchUnreadMessageCount(userData.user.id));
		})
	});
}
