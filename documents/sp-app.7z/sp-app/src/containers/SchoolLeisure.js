import React, { Component } from 'react';
import { connect } from 'react-redux';
import {UI} from '../core/Constants';
import Select from 'react-select';

import Analytics from '../analytics';
import Config from '../config';

import * as teacherLeisureActions from '../actions/TeacherLeisureActions';
import AppPage from '../components/AppPage';
import Avatar from '../components/Avatar';
import IconButton from '../components/IconButton';
import SchoolDayInfoRow from '../components/SchoolDayInfoRow';
import Spinner from '../components/Spinner';

import { gettext, LOC_KEYS } from '../core/Texts';

class SchoolLeisure extends Component {

	componentDidMount () {
		Analytics.trackView('SchoolLeisure');

		var _this = this;
		setTimeout(function () {
			if (_this.props.activeLeisureGroupId === false) {
				const groups = _this.props.user.getTeachingLeisureGroups();
				if (groups.length > 0) {
					_this.props.setActiveLeisureGroupId(groups[0].id);
				} else {
					_this.props.history.replace('/home');
				}
			}
		}, UI.ANIMATION_DURATION + 50);
	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	shouldComponentUpdate (nextProps) {
		const {activeLeisureGroupId, leisureInfo} = this.props;
		const nextActiveLeisureGroupId = nextProps.activeLeisureGroupId;
		const nextLeisureInfo = nextProps.leisureInfo;
		return (
			activeLeisureGroupId !== nextActiveLeisureGroupId ||
			!!leisureInfo !== !!nextLeisureInfo ||
			(leisureInfo && nextLeisureInfo) && leisureInfo.timestamp !== nextLeisureInfo.timestamp
		);
	}

	changeLeisureGroup (val) {
		this.props.setActiveLeisureGroupId(val.value);
	}


	checkContent (props) {
		const {isFetching, activeLeisureGroupId, leisureInfo} = props;

		if (!isFetching && !leisureInfo && activeLeisureGroupId) {
			props.fetchTeacherLeisureInfo(activeLeisureGroupId);
		}
	}

	render () {
		const {activeLeisureGroupId, leisureInfo, user} = this.props;
		let content;
		let showLoading = true;
		const leisureGroups = user.getTeachingLeisureGroups().map(lg => {
			return { value: lg.id, label: lg.name };
		});

		if (leisureInfo) {
			showLoading = false;

			const leftChildrenCount = leisureInfo.leisure_day.user_dicts.filter(ud => (!ud.reported_sick && ud.schedule && ud.schedule.status === 1)).length;
			const leftLabel = (leftChildrenCount === 1)
				? gettext(LOC_KEYS.ONE_DROPPED)
				: leftChildrenCount + gettext(LOC_KEYS.MORE_DROPPED);
			const pickedUpChildrenCount = leisureInfo.leisure_day.user_dicts.filter(ud => (!ud.reported_sick && ud.schedule && ud.schedule.status === 2)).length;
			const pickedUpLabel = (pickedUpChildrenCount === 1)
				? gettext(LOC_KEYS.ONE_FETCHED)
				: pickedUpChildrenCount + gettext(LOC_KEYS.MORE_FETCHED);
			const sickChildrenCount = leisureInfo.leisure_day.user_dicts.filter(ud => ud.reported_sick).length;
			const sickLabel = (sickChildrenCount === 1)
				? gettext(LOC_KEYS.ONE_ILL)
				: sickChildrenCount + gettext(LOC_KEYS.MORE_ILL);

			const udComments = leisureInfo.leisure_day.user_dicts.filter(ud => ud.schedule && ud.schedule.comment);

			content = (
				<div>
					<Select
						clearable={false}
						searchable={false}
						name={'select-leisure-group'}
						value={activeLeisureGroupId}
						options={leisureGroups}
						onChange={(e) => this.changeLeisureGroup(e)}
						className="lg"
					/>

					<div className="container mtm">
						<header className="center">
							<h2>{leisureInfo.leisure_day.formatted_date}</h2>
						</header>

						<div className="content">

							<div className="icon-list">
								<ul>

									<SchoolDayInfoRow
										icon="calendar"
										title={ gettext(LOC_KEYS.SCHOOL_DAY_TODAYS_TIMES) }
										content={leisureInfo.leisure_day.user_interval}
									/>

									<SchoolDayInfoRow
										icon="user"
										title={ gettext(LOC_KEYS.STUDENTS) }
										content={`${leisureInfo.leisure_day.user_dicts.length} ${gettext(LOC_KEYS.STUDENTS).toLowerCase()} (${leftLabel}, ${pickedUpLabel}, ${sickLabel})`}
									/>

								</ul>
							</div>
						</div>
					</div>

					<div className="center mvs">
						<IconButton
							backgroundColor='#3a99d8'
							className="mam"
							label={ gettext(LOC_KEYS.LEISURE_LEAVE_CHILD) }
							onClick={(e) => {e.preventDefault(); e.stopPropagation(); this.props.history.push('/school/leisure/leave');}}
							urlIcon={Config.getAssetUrl('icons/enter.svg')}
							imageStyle={{marginLeft: '-19px'}}
						/>

						<IconButton
							backgroundColor='#e44d42'
							className="mam"
							label={ gettext(LOC_KEYS.LEISURE_GET_CHILD) }
							onClick={(e) => {e.preventDefault(); e.stopPropagation(); this.props.history.push('/school/leisure/pickup');}}
							urlIcon={Config.getAssetUrl('icons/exit.svg')}
							imageStyle={{marginLeft: '-19px'}}
						/>
					</div>

					{udComments.length > 0 && (
						<div className="container mtm">
							<header className="center">
								<h2>{ gettext(LOC_KEYS.COMMENT) }</h2>
							</header>

							<div className="content">
								{udComments.map((ud, i) => {
									return (
										<div key={i} className="leisure-user-comment">
											<Avatar
												src={ud.user.avatar}
												size="sm"
											/>
											<div className="inner">
												<strong>{ud.user.full_name}</strong>
												<p>
													{ud.schedule.comment}
												</p>
											</div>
										</div>
									);
								})}
							</div>
						</div>
					)}
				</div>
			);

		}


		if (showLoading) {
			content = (
				<div className="container">
					<header className="center">
						<h2>{ gettext(LOC_KEYS.LOADING) }</h2>
					</header>

					<div className="content center pam">
						<Spinner verticalMargin={true} />
					</div>
				</div>
			);
		}

		return (
			<AppPage className="leisure-page">
				{content}
			</AppPage>
		);
	}
}

const mapStateToProps = (state) => {
	const { auth, leisure } = state;
	const { user } = auth;
	const { activeLeisureGroupId, leisureInfo } = leisure;

	return {
		activeLeisureGroupId,
		leisureInfo,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchTeacherLeisureInfo: (leisureGroupId) => {
			dispatch(teacherLeisureActions.fetchTeacherLeisureInfo(leisureGroupId));
		},

		setActiveLeisureGroupId: (activeLeisureGroupId) => {
			dispatch(teacherLeisureActions.setActiveLeisureGroupId(activeLeisureGroupId));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(SchoolLeisure);
