import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import AuthApp from './AuthApp';

import * as authActions from '../actions/AuthActions';
import * as UIActions from '../actions/UIActions';

const mapStateToProps = (state) => {
	const { auth, modals, ui } = state;
	const { account, accountErrorMessage, isFetching, user, userErrorMessage } = auth;
	const { dialogs } = modals;
	const { menuOpen } = ui;

	return {
		account,
		accountErrorMessage,
		dialogs,
		isFetching,
		menuOpen,
		user,
		userErrorMessage,
		location: state.router.location,
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		openMenu: () => {
			dispatch(UIActions.openMenu());
		},
		closeMenu: () => {
			dispatch(UIActions.closeMenu());
		},
		fetchAccount: () => {
			dispatch(authActions.fetchAccount());
		},
		logoutUser: () => {
			dispatch(authActions.logoutUser());
		},
		setActiveChild: (childId) => {
			dispatch(authActions.setActiveChild(childId));
		},
		setActiveUser: (userId) => {
			dispatch(authActions.setActiveUser(userId));
		}
	};
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(AuthApp));