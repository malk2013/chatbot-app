import React, { Component } from 'react';
import { connect } from 'react-redux';
import Linkify from 'react-linkify';

import Analytics from '../analytics';

import * as scheduleActions from '../actions/ScheduleActions';
import AppPage from '../components/AppPage';
import IconRow from '../components/IconRow';
import Spinner from '../components/Spinner';
import { gettext, LOC_KEYS } from '../core/Texts';

class Lesson extends Component {

	componentDidMount () {
		Analytics.trackView('Lesson');

		const {week} = this.props.match.params;
		const {user, weekSchedules} = this.props;

		if (!weekSchedules || !weekSchedules[week]) {
			const scheduleEndPoint = user.getScheduleEndPoint();
			if (scheduleEndPoint) {
				this.props.fetchSchedule(scheduleEndPoint +'?week=' + week);
			}
		}

		this.props.fetchLesson(this.props.match.params.id);
	}

	render () {
		const {week, weekday} = this.props.match.params;
		const id = parseInt(this.props.match.params.id);
		const {weekSchedules, isFetchingLesson, lesson} = this.props;
		let content;
		let title = '-';

		if (weekSchedules && weekSchedules[week]) {
			const scheduleLesson = weekSchedules[week].days[weekday - 1].lessons.find(lesson => {
				return lesson.lesson_id === id;
			});

			if (scheduleLesson) {
				title = scheduleLesson.subject_name;
				content = (
					<div>
						<IconRow
							icon="building.svg"
							label={ gettext(LOC_KEYS.CLASS_ROOM) }
							value={scheduleLesson.room || '-'}
						/>
						<IconRow
							icon="clocks.svg"
							label={ gettext(LOC_KEYS.TIME) }
							value={scheduleLesson.time || '-'}
						/>
						<IconRow
							icon="mortarboard.svg"
							label={ gettext(LOC_KEYS.TEACHER) }
							valueArr={scheduleLesson.teachers_full.map(teacher => {
								return teacher.first_name + ' ' + teacher.last_name;
							})}
						/>
						<IconRow
							icon="shirt.svg"
							label={ gettext(LOC_KEYS.STUDY_GROUP) }
							value={scheduleLesson.groups || '-'}
						/>

						<div className="lesson-info">
							<h3>{ gettext(LOC_KEYS.INFO) }</h3>
							<div className="mts">
								{isFetchingLesson && (
									<Spinner />
								)}

								{lesson && (
									<div>
										<Linkify properties={{target: '_blank', className: 'underlined'}}>
											{lesson.information ? lesson.information.split('\n').map((row, i) => (
												<p key={'row-' + i} style={{minHeight: '20px'}}>{row}</p>)
											) : (
												<i className="no-info"> { gettext(LOC_KEYS.LESSON_NO_INFO) } </i>
											)}
										</Linkify>
									</div>
								)}

								{lesson && lesson.drive_files && !!lesson.drive_files.length && (
									<div className="mtl">
										<h3>{ gettext(LOC_KEYS.FILES) }</h3>
										<ul className="list files-list mts">
											{lesson.drive_files.map((drive_file, i) => (
												<li key={'drive-file-' + i}>
													<a href={drive_file.url} target="_blank">{drive_file.name}</a>
												</li>
											))}
										</ul>
									</div>
								)}
							</div>
						</div>
					</div>
				);
			} else {
				content = (
					<div className="pal center"> { gettext(LOC_KEYS.LESSON_NO_LESSON) } </div>
				);
			}

		} else {
			content = <Spinner verticalMargin={true} />;
		}

		return (
			<AppPage className="schedule-lesson">
				<div className="container">
					<header className="center">
						<h2>{title}</h2>
					</header>

					<div className="content">
						{content}
					</div>
				</div>
			</AppPage>
		);
	}

}

const mapStateToProps = (state) => {
	const { auth, schedule } = state;
	const { user } = auth;
	const { weekSchedules, isFetchingLesson, lesson } = schedule;

	return {
		user,
		isFetchingLesson,
		lesson,
		weekSchedules
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchLesson: (lessonId) => {
			dispatch(scheduleActions.fetchLesson(lessonId));
		},

		fetchSchedule: (endpoint) => {
			dispatch(scheduleActions.fetchSchedule(endpoint));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Lesson);
