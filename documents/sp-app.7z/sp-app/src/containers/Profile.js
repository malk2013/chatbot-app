import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as authActions from '../actions/AuthActions';
import AppPage from '../components/AppPage';


class Profile extends Component {

	componentDidMount () {
		Analytics.trackView('Profile');
	}

	handleClick () {
		this.props.logoutUser();
	}

	render () {
		var tmp = [];
		for (var i = 100; i >= 0; i--) {
			tmp.push(i);
		}
		return (
			<AppPage>
				<div>Profile</div>
				<div>
					{JSON.stringify(this.props.user)}
					{tmp.map(i => {
						return <div key={i}>{i}</div>;
					})}
				</div>
				<button onClick={(event) => this.handleClick(event)} className="btn btn-primary">
					Logout
				</button>
			</AppPage>
		);
	}

}

Profile.propTypes = {
	logoutUser: PropTypes.func.isRequired,
};


const mapStateToProps = (state) => {
	const { auth } = state;
	const { user } = auth;

	return {
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		logoutUser: () => {
			dispatch(authActions.logoutUser());
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Profile);