import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as UIActions from '../actions/UIActions';

import Login from './Login';

import { ProtectedRouteArea } from '../routes';

class MobileRoot extends Component {

	constructor (props) {
		super(props);
		window.addEventListener('orientationchange', this.setOrientation.bind(this));
	}

	setOrientation () {
		this.props.setOrientation(window.screen.orientation);
	}

	render () {
		const { isAuthenticated } = this.props;
		// const history = this.props.history

		if(isAuthenticated) {
			return(<ProtectedRouteArea />);
		}
		// else if(window.location.pathname.includes('user_token')){
		// 	return(<UserToken history={history}/>);
		// }
		else {
			return(<Login />); // window.location.href = "http://localhost:3000/user/login/?next=http://localhost:8080"
		}
	}

}

const mapStateToProps = (state) => ({
	isAuthenticated: state.auth.hasTokens,
});

const mapDispatchToProps = (dispatch) => {
	return {
		setOrientation: (orientation) => {
			dispatch(UIActions.setOrientation(orientation));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(MobileRoot);