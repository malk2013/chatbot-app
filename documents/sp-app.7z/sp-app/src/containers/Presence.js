import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Analytics from '../analytics';

import AppPage from '__components/AppPage';
import SubMenu from '__components/SubMenu';

import { gettext, LOC_KEYS } from '../core/Texts';


class Presence extends Component {

	componentDidMount () {
		Analytics.trackView('Presence');
	}

	render () {
		const { history } = this.props;
		const items = [{
			text: gettext(LOC_KEYS.PRESENCE_BUTTON_PARTIAL),
			onClick: () => history.push('/absence/partial')
		},{
			text: gettext(LOC_KEYS.PRESENCE_BUTTON_CONFIRMED),
			onClick: () => history.push('/absence/confirmed')
		}, {
			text: gettext(LOC_KEYS.PRESENCE_BUTTON_UNCONFIRMED),
			onClick: () => history.push('/absence/unconfirmed')
		}];

		return (
			<AppPage className="home-page dark-main">
				<SubMenu items={items} />
			</AppPage>
		);
	}
}

Presence.propTypes = {
	history: PropTypes.shape({
		push: PropTypes.func.isRequired
	}).isRequired
};

export default Presence;
