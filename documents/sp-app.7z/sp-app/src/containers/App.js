import React from 'react';
import { CSSTransition, TransitionGroup } from 'react-transition-group';

const App = props => {
	return (
		<TransitionGroup>
			<CSSTransition
				classNames='fade-animation'
				timeout={{ exit: 1000, enter: 1000, appear: 1000 }}
				appear={true}>
				{ props.children }
			</CSSTransition>
		</TransitionGroup>
	);
};

export default App;