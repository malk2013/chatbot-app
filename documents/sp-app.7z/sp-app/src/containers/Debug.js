import React, { Component } from 'react';
import Select from 'react-select';
import Config from '../config';
import AppPage from '../components/AppPage';
import Button from '../components/Button';


class Debug extends Component {

	constructor (props) {
		super(props);

		this.state = {
			backend: Config.getBackendKey()
		};
	}

	handleValueChange (val, type) {
		this.state[type] = val;
		this.forceUpdate();
	}

	submitForm () {
		Config.setBackend(this.state.backend);
	}

	render () {

		const options = Config.getSelectableEnvironments();

		return (
			<AppPage className="debug-page">
				<div className="container">
					<header className="center">
						<h2>Backend</h2>
					</header>

					<div className="content center pam">

						<Select
							clearable={false}
							name="select-active"
							value={this.state.backend}
							options={options}
							onChange={(val) => this.handleValueChange(val.value, 'backend')}
						/>


						<div className="center pam">
							<Button
								onClick={(event) => this.submitForm(event)}
								text="Ändra"
								className="mhs"
							/>
						</div>

					</div>
				</div>
			</AppPage>
		);
	}
}

export default Debug;
