import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as leisureActions from '../actions/LeisureActions';
import AppPage from '../components/AppPage';
import Button from '../components/Button';
import LeisureWeekdayForm from '../components/LeisureWeekdayForm';
import Spinner from '../components/Spinner';
import { gettext, LOC_KEYS } from '../core/Texts';

class LeisureWeekday extends Component {

	componentDidMount () {
		Analytics.trackView('LeisureWeekday');

		const {date} = this.props.match.params;
		const {currentLeisureWeek} = this.props;
		this.currentDayDict = false;
		if (currentLeisureWeek && currentLeisureWeek.day_dicts) {
			this.currentDayDict = currentLeisureWeek.day_dicts.find(dayDict => dayDict.date === date);
		}

		if (!this.currentDayDict) {
			this.props.history.replace('/leisure');
		}
	}

	updateWeekday () {
		const {user, history} = this.props;
		const data = Object.assign({
			userId: user.activeChild.id,
			date: this.currentDayDict.date,
		}, this.refs.weekdayForm.getValues());

		this.props.updateWeekday(data, function () {
			history.goBack();
		});
	}

	render () {
		const {leisureError, isSavingLeisure, user, history} = this.props;
		let content;

		if (!this.currentDayDict || isSavingLeisure) {

			content = (
				<div className="content center pam">
					<Spinner verticalMargin={true} />;
				</div>
			);

		} else {
			content = (
				<div>
					<LeisureWeekdayForm
						ref="weekdayForm"
						user={user}
						instance={this.currentDayDict}
						errors={leisureError}
					/>

					{!isSavingLeisure && (
						<div className="center pbm">
							<Button
								onClick={(event) => this.updateWeekday(event)}
								text={ gettext(LOC_KEYS.CHANGES_SAVE) }
								className="mhs"
							/>

							<Button
								onClick={history.goBack}
								text={ gettext(LOC_KEYS.CANCEL) }
								className="mhs"
							/>
						</div>
					)}
				</div>
			);
		}

		return (
			<AppPage className="leisure-default-week-page">
				<div className="container">
					<header className="center">
						<h2>{this.currentDayDict ? this.currentDayDict.day_name + ', ' + this.currentDayDict.formatted_date : gettext(LOC_KEYS.LOADING)}</h2>
					</header>

					{content}
				</div>
			</AppPage>
		);
	}
}

const mapStateToProps = (state) => {
	const { auth, leisure } = state;
	const { user } = auth;
	const { currentLeisureWeek, leisureError, isSavingLeisure, leisureInfo } = leisure;

	return {
		currentLeisureWeek,
		leisureError,
		isSavingLeisure,
		leisureInfo,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		updateWeekday: (data, successCallback) => {
			dispatch(leisureActions.updateWeekday(data, successCallback));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(LeisureWeekday);
