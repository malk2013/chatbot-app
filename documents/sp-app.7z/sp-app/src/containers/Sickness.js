import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as presenceActions from '../actions/PresenceActions';
import Utils from '../core/Utils';
import { gettext, LOC_KEYS } from '../core/Texts';

import AppPage from '../components/AppPage';
import Button, { SIZES } from '../components/Button';
import Spinner from '../components/Spinner';

import { getSickness } from '../reducers/presence';


class Sickness extends Component {

	componentDidMount () {
		Analytics.trackView('Sickness');
		this.checkContent(this.props);
	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	checkContent (props) {
		const {sicknessError, sicknessStatus, isFetching, user} = props;

		if (!sicknessStatus && !isFetching && !sicknessError && user.isParentWithActiveChild()) {
			this.props.fetchSicknessStatus(user.activeChild.id);
		}
	}

	reportSickness () {
		this.props.reportSickness(this.props.user.activeChild.id);
	}

	reportCancelSickness () {
		this.props.reportCancelSickness(this.props.user.activeChild.id);
	}

	render () {
		const {isFetched, sicknessError, sicknessStatus, user} = this.props;
		let content;

		if (sicknessError) {
			content = (
				<div className="center phm">
					<p className="error mtm">{sicknessError}</p>
					<a
						onClick={() => this.props.fetchSicknessStatus(user.activeChild.id)}
						className="btn btn-main mvm"
					>{ gettext(LOC_KEYS.TRY_AGAIN) }</a>
				</div>

			);
		} else if (isFetched) {
			if (sicknessStatus && sicknessStatus.sickness) {
				content = (
					<div className="pal">
						{(sicknessStatus && sicknessStatus.show_next_day) && (
							<p>
								{ gettext(LOC_KEYS.SICKNESS_IS_REPORTED_TOMORROW, {
									name: user.getActiveChildFullName(),
									date: Utils.format_date('%j %F', new Date(sicknessStatus.date))
								}) }
							</p>
						)}
						{!(sicknessStatus && sicknessStatus.show_next_day) && (
							<p>
								{ gettext(LOC_KEYS.SICKNESS_IS_REPORTED_TODAY, {
									name: user.getActiveChildFullName()
								}) }
							</p>
						)}

						{sicknessStatus.canUndo
							? <a
								className="mts mbs"
								onClick={this.reportCancelSickness.bind(this)}
								size={SIZES.LARGE}
								style={{display: 'block', textDecoration: 'underline'}} >
								{ gettext(LOC_KEYS.SICKNESS_REPORT_UNDO) }
							</a>
							: <i className="mts mbs" style={{display: 'block'}}>
								{ gettext(LOC_KEYS.SICKNESS_REPORT_UNDO_INFO) }
							</i>}
					</div>
				);
			} else {
				const day = (sicknessStatus && sicknessStatus.show_next_day) ?
					gettext(LOC_KEYS.SICKNESS_REPORT_REFERS_TOMORROW, {
						date: Utils.format_date('%j %F', new Date(sicknessStatus.date))
					})
					:
					gettext(LOC_KEYS.SICKNESS_REPORT_REFERS_TODAY, {
						date: Utils.format_date('%j %F', new Date(sicknessStatus.date))
					});

				content = (
					<div className="pal">
						<p>{ gettext(LOC_KEYS.SICKNESS_REPORT_INSTRUCTIONS) } <span>{day}</span>.</p>

						<Button
							className="mtl mbs"
							size={SIZES.LARGE}
							text={gettext(LOC_KEYS.SICKNESS_REPORT_NAME, {
								'name': this.props.user.activeChild.first_name
							})}
							onClick={this.reportSickness.bind(this)}
						/>

						{sicknessStatus && !sicknessStatus.show_next_day && (
							<p className="grey mtl phm">{ gettext(LOC_KEYS.SICKNESS_REPORT_INFO) }</p>
						)}
					</div>
				);
			}
		} else {
			content = (
				<Spinner verticalMargin={true} />
			);
		}

		return (
			<AppPage className="sickness-page">
				<div className="container">
					<header className="center">
						<h2>{ gettext(LOC_KEYS.SICKNESS_REPORT_NAME, {
							'name': this.props.user.activeChild.first_name
						}) }</h2>
					</header>

					<div className="content">
						{content}
					</div>
				</div>
			</AppPage>
		);

	}
}

const mapStateToProps = (state) => {
	const { auth, presence } = state;
	const { user } = auth;

	const { isFetching, isFetched, sicknessError } = presence;

	return {
		user,
		isFetched,
		isFetching,
		sicknessError,
		sicknessStatus: getSickness(state),
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchSicknessStatus: (activeChildId) => {
			dispatch(presenceActions.fetchSicknessStatus(activeChildId));
		},
		reportSickness: (activeChildId) => {
			dispatch(presenceActions.reportSickness(activeChildId));
		},
		reportCancelSickness: (activeChildId) => {
			dispatch(presenceActions.reportCancelSickness(activeChildId));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Sickness);
