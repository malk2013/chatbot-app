import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from 'react-redux';
import axios from 'axios';
import * as authActions from '../actions/AuthActions';

class UserToken extends Component {

	// constructor(props) {
	// 	super(props);
	
	// 	this.state = {redirect: false}
	// }

	componentWillMount () {
		if(window.location.search.split('code=')[1].split('&')[0]){
			let config = {
				method: 'GET',
				url: 'http://localhost:3002/user_token/?code='+window.location.search.split('code=')[1].split('&')[0]+'&mobile_app=true',
			};

			return axios(config)
				.then(response => {
					localStorage.setItem('sp_access_token', response.data.access_token);
					localStorage.setItem('sp_refresh_token', response.data.refresh_token);
					axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('sp_access_token')}`;
					this.redirect_to_dashboard(response.data);
				})
				.catch(err => {
					console.log('Error: ', err);
					return Promise.reject(err.data);
				});
		}
		this.props.history.push('/');
	}

	redirect_to_dashboard(data){
		this.props.history.push('/');
		this.props.authenticatedUser(data);
	}

	render () {
		return(<div></div>);
	}
}

UserToken.propTypes = {
	authenticatedUser: PropTypes.func.isRequired,
};


const mapStateToProps = (state) => {
	const { auth } = state;
	const { user } = auth;

	return {
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		authenticatedUser: (data) => {
			dispatch(authActions.authenticatedUser(data));
		},
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(UserToken);