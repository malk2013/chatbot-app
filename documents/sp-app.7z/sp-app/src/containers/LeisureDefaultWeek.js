import React, { Component } from 'react';
import { connect } from 'react-redux';
import { push, replace } from 'react-router-redux';

import Analytics from '../analytics';

import * as leisureActions from '../actions/LeisureActions';
import AppPage from '../components/AppPage';
import Button from '../components/Button';
import LeisureScheduleWeekForm from '../components/LeisureScheduleWeekForm';
import Spinner from '../components/Spinner';
import { gettext, LOC_KEYS } from '../core/Texts';


class LeisureDefaultWeek extends Component {

	componentDidMount () {
		Analytics.trackView('LeisureDefaultWeek');

		this.checkContent(this.props);
		this._notices = {
			savedNotice: false
		};
	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	checkContent (props) {
		/*
		TODO PRIO: FIX! Tmp moved this to the delete schedule action, but this kind of redirects are
		probably used on other places as well..
		const {isSavingLeisure, leisureInfo, history} = props;

		if (!isSavingLeisure && (!leisureInfo || !leisureInfo.has_leisure_schedule || !leisureInfo.leisure_schedule.default_week)) {
			history.replace('/leisure');
		}
		*/
	}

	deleteSchedule () {
		const {user} = this.props;
		this.props.deleteLeisureSchedule(user.activeChild.id);
	}

	saveDefaultWeek () {
		const _this = this;
		const {user} = this.props;
		this.props.saveDefaultWeek(user.activeChild.id, this.refs.defaultWeekForm.getDays(), function () {
			_this._notices.savedNotice = true;
			_this.forceUpdate();

			setTimeout(function () {
				_this._notices.savedNotice = false;
				_this.forceUpdate();
			}, 2000);
		});
	}

	render () {
		const {defaultWeekError, isSavingLeisure, leisureInfo, history} = this.props;
		let content;

		if (!leisureInfo || !leisureInfo.has_leisure_schedule || !leisureInfo.leisure_schedule.default_week) {

			content = (
				<div className="content center pam">
					<Spinner verticalMargin={true} />
				</div>
			);

		} else {
			content = (
				<div>
					<p className="center pas ptm">
						{ gettext(LOC_KEYS.LEISURE_REG_SCHEDULE_CHANGE_WEEK_INFO).replace(
							'%period%',
							leisureInfo.leisure_schedule.start_year !== leisureInfo.leisure_schedule.end_year
								? 'v.' + leisureInfo.leisure_schedule.start_week + ' (' + leisureInfo.leisure_schedule.start_year + ') - v.' + leisureInfo.leisure_schedule.end_week + ' (' + leisureInfo.leisure_schedule.end_year + ')'
								: 'v.' + leisureInfo.leisure_schedule.start_week + ' - v.' + leisureInfo.leisure_schedule.end_week
						) }
					</p>
					<p className="center pas ptm">
						{ gettext(LOC_KEYS.LEISURE_REG_SCHEDULE_CHANGE_INFO) }
						<a onClick={history.goBack}> { gettext(LOC_KEYS.LEISURE_PREV_VIEW) } </a>
					</p>

					<LeisureScheduleWeekForm
						ref="defaultWeekForm"
						default_week={leisureInfo.leisure_schedule.default_week}
						errors={defaultWeekError}
					/>

					{this._notices && this._notices.savedNotice && (
						<p className="center pts success"> { gettext(LOC_KEYS.CHANGES_SAVED) } </p>
					)}

					{isSavingLeisure && (
						<div className="center mts">
							<Spinner verticalMargin={true} />;
						</div>
					)}

					{!isSavingLeisure && (
						<div className="center mts pbm">
							<Button
								onClick={(event) => this.saveDefaultWeek(event)}
								text={ gettext(LOC_KEYS.CHANGES_SAVE) }
								className="mts"
							/>

							<Button
								onClick={history.goBack}
								text={ gettext(LOC_KEYS.CANCEL) }
								className="mhs"
							/>
						</div>
					)}
				</div>
			);
		}

		return (
			<AppPage className="leisure-default-week-page">
				<div className="container">
					<header className="center">
						<h2>{ gettext(LOC_KEYS.LEISURE_REG_BASIS_SCHEDULE) }</h2>
					</header>

					{content}
				</div>


				<div className="center pas">
					<Button
						onClick={(event) => this.deleteSchedule(event)}
						text={ gettext(LOC_KEYS.LEISURE_REMOVE_SCHEDULE) }
						className="danger mts"
					/>
				</div>
			</AppPage>
		);
	}
}

const mapStateToProps = (state) => {
	const { auth, leisure } = state;
	const { user } = auth;
	const { defaultWeekError, isSavingLeisure, leisureInfo } = leisure;

	return {
		defaultWeekError,
		isSavingLeisure,
		leisureInfo,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		saveDefaultWeek: (activeChildId, days, successCallback) => {
			dispatch(leisureActions.saveDefaultWeek(activeChildId, days, successCallback));
		},

		deleteLeisureSchedule: (activeChildId) => {
			dispatch(leisureActions.deleteLeisureSchedule(activeChildId));
		},
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(LeisureDefaultWeek);
