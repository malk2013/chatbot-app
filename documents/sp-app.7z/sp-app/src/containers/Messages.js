import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as messagesActions from '../actions/MessagesActions';
import Utils from '../core/Utils';
import AppPage from '../components/AppPage';
import Button from '../components/Button';
import ConversationItem from '../components/ConversationItem';
import Spinner from '../components/Spinner';

import { gettext, LOC_KEYS } from '../core/Texts';

let _eventsBinded = false;

class Messages extends Component {

	constructor (props) {
		super(props);

		if (!_eventsBinded) {
			_eventsBinded = true;

			window.emitter.on('conversationUpdated', function (conversationId, lastMessageBody) {
				this.props.updateLastMessage(conversationId, lastMessageBody);
			}.bind(this));

			document.addEventListener('resume', function () {
				props.resetConversations();
			});
		}
	}

	componentDidMount () {
		Analytics.trackView('Messages');

		this.checkContent(this.props);
	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	shouldComponentUpdate (nextProps) {
		const nextConversations = nextProps.conversations;
		const currConversations = this.props.conversations;
		if (!nextConversations || !currConversations) {
			return true;
		}

		let changed = (
			nextProps.isFetched !== this.props.isFetched ||
			nextProps.page !== this.props.page ||
			nextConversations.length != currConversations.length
		);

		if (!changed && nextConversations) {
			// Loop through conversations and check last message body
			const l = nextConversations.length;
			for (let i=0; i<l; i++) {
				if (nextConversations[i].last_message_body !== currConversations.last_message_body) {
					return true;
				}
			}
		}

		return changed;
	}

	checkContent (props) {
		const {conversations, conversationsTimestamp, isFetching, conversationsErrorMessage, user} = props;

		if ((!conversations || Utils.hasMinutesPassed(conversationsTimestamp, 5)) && !isFetching && !conversationsErrorMessage) {
			props.fetchConversations(user.id, 1);
		}
	}

	nextPage () {
		this.props.fetchConversations(this.props.user.id, this.props.page + 1);
	}

	prevPage () {
		this.props.fetchConversations(this.props.user.id, this.props.page - 1);
	}

	refetchPage () {
		this.props.fetchConversations(this.props.user.id, this.props.page || 1);
	}

	render () {
		let {conversations, isFetched, page, history} = this.props;
		conversations = conversations || [];

		let conversationList;
		let prevButton = '';
		let nextButton = '';

		if (!isFetched) {
			conversationList = (
				<Spinner verticalMargin={true} />
			);
		} else {
			if (conversations.length) {
				conversationList = conversations.map(conversation => {
					return <ConversationItem
						key={conversation.id}
						conversation={conversation}
						user={this.props.user}
						onClick={() => {history.push('/conversation/' + conversation.id);}}
					/>;
				});

				if (page > 1) {
					prevButton = <button className="btn btn-primary pull-left prev-button" onClick={this.prevPage.bind(this)}> { gettext(LOC_KEYS.PREVIOUS_PAGE) }</button>;
				}
				if (conversations.length === 10) {
					nextButton = <button className="btn btn-primary pull-right next-button" onClick={this.nextPage.bind(this)}> { gettext(LOC_KEYS.NEXT_PAGE) } </button>;
				}
			} else {
				if (this.props.conversationsErrorMessage) {
					conversationList = (
						<div className="pal center">
							<p> { gettext(LOC_KEYS.MESSAGES_ERROR) }</p>
							<a className="link mtm" onClick={this.refetchPage.bind(this)}> {gettext(LOC_KEYS.TRY_AGAIN)} </a>
						</div>
					);
				} else {
					conversationList = (
						<div className="pal center"> { gettext(LOC_KEYS.MESSAGES_EMPTY_INBOX) } </div>
					);
				}
			}
		}

		return (
			<AppPage>
				<div className="container">
					<header className="messages-header clearfix">
						<h2> {gettext(LOC_KEYS.INBOX)} </h2>
						<Button to="/new-message" text={gettext(LOC_KEYS.MESSAGES_NEW_CONVO)} />
					</header>

					<div className="content">
						{conversationList}

						<nav className="conversations-nav center pvs mhs">
							{prevButton}
							<span>{gettext(LOC_KEYS.PAGE)} {page}</span>
							{nextButton}
						</nav>
					</div>
				</div>
			</AppPage>
		);
	}
}

const mapStateToProps = (state) => {
	const { auth, messages } = state;
	const { user } = auth;
	const { isFetching, isFetched, conversations, conversationsTimestamp, page, conversationsErrorMessage } = messages;

	return {
		user,
		isFetching,
		isFetched,
		conversations,
		conversationsTimestamp,
		page,
		conversationsErrorMessage
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		resetConversations: () => {
			dispatch(messagesActions.resetConversations());
		},

		updateLastMessage: (conversationId, lastMessageBody) => {
			dispatch(messagesActions.updateLastMessage(conversationId, lastMessageBody));
		},

		fetchConversation: (userId, conversationId) => {
			dispatch(messagesActions.fetchConversation(userId, conversationId));
		},

		fetchConversations: (userId, page) => {
			dispatch(messagesActions.fetchConversations(userId ,page));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Messages);
