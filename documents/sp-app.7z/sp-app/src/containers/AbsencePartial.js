import { connect } from 'react-redux';
import moment from 'moment';

import Utils from '../core/Utils';

import AbsencePartial from '../components/AbsencePartialPage';

import { 
	reportPartialSickness, 
	fetchPartialSickness, 
	reportCancelPartialSickness, 
	resetSicknessStatus,
	resetSicknessErrors
} from '../actions/PresenceActions';

import { getPartialAbsences } from '../reducers/presence';


/**
 * Turns the date, start and end time into Moment objects
 * @param {Object[]} object_list
 */
function dateObject (object_list) {
	return object_list
		.map(sick => ({
			...sick,
			'moment_date': moment(`${sick.date} ${sick.start_time}`),
			'start_time': moment(sick.start_time, 'HH:mm'),
			'end_time': moment(sick.end_time, 'HH:mm'),
		}));
}

const mapStateToProps = (state) => ({
	activeChildId: state.auth.user.activeChild.id,
	sicknessList: dateObject(getPartialAbsences(state)),
	isFetching: state.presence.isFetching,
	isFetched: state.presence.isFetched,
	error: state.presence.sicknessError,
});

const mapDispatchToProps = (dispatch) => ({
	reset: () => dispatch(resetSicknessStatus()),
	fetch: (activeChildId) => {
		dispatch(fetchPartialSickness(activeChildId));
	},
	report: props => {
		const formatted = Utils.formatInput(props);
		dispatch(reportPartialSickness(formatted));
	},
	remove: (activeChildId, sickness_id) => {
		dispatch(reportCancelPartialSickness(activeChildId, sickness_id));
	},
	resetErrors: () => dispatch(resetSicknessErrors()),
});

export default connect(mapStateToProps, mapDispatchToProps)(AbsencePartial);