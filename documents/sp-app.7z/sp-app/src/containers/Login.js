import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import Config, { ExternalLinks } from '../config';
import * as authActions from '../actions/AuthActions';
import Button, {SIZES} from '../components/Button';
import Image from '../components/Image';
import Spinner from '../components/Spinner';
import { gettext, LOC_KEYS } from '../core/Texts';
import ExternalLink from '../components/ExternalLink';


export class Login extends Component {

	componentDidMount () {
		Analytics.trackView('Login');

		if (window.StatusBar) {
			window.StatusBar.backgroundColorByHexString('#55a1fc');
		}
	}

	handleClick () {
		const username = this.refs.username;
		const password = this.refs.password;

		localStorage.setItem('sp_last_username', username.value.trim());

		this.props.loginUser({
			username: username.value.trim(),
			password: password.value.trim()
		});
	}

	render () {
		const { isFetching, loginErrorMessage } = this.props;
		const defaultUsername = localStorage.getItem('sp_last_username') || '';
		const loading = isFetching;

		return (
			<div id="login-container">
				<div id="login-box">
					<div id="admentum-logo" />
					<div className="clearfix login-fields">
						<input
							type="text"
							ref="username"
							className="form-field effect-20"
							placeholder={ gettext(LOC_KEYS.USERNAME) }
							defaultValue={defaultUsername}
							autoCorrect="off"
							autoCapitalize="none"
						/>

						<input
							type="password"
							ref="password"
							className="form-field effect-20"
							placeholder={ gettext(LOC_KEYS.PASSWORD) }
							autoCorrect="off"
							autoCapitalize="none"
						/>
					</div>

					{!loading && (
						<Button
							onClick={(event) => this.handleClick(event)}
							text={ gettext(LOC_KEYS.LOG_IN)}
							size={SIZES.LARGE}
							type="login"
							className="login-button"
						/>
					)}

					<p className="mtm">
						<ExternalLink
							href="#"
							className="link"
							text={ gettext(LOC_KEYS.FORGOT_PASSWORD) }
							url={ExternalLinks.forgotPassword}
						/>
					</p>

					{!Config.isProdEnv() && (
						<p className="mts">
							<span style={{color: '#aaa'}}>{Config.getBackendUrl()}</span>
						</p>
					)}

					{loading && <Spinner verticalMargin={true} />}
					{loginErrorMessage && <p className="error mtm">{loginErrorMessage}</p>}
				</div>
			</div>

			// {/* {window.appVersion && (
			// 	<div className="login-info">
			// 		V. {window.appVersion}-{Config.getBuildNumber()}
			// 	</div>
			// )} */}
		);
	}
}

const mapStateToProps = (state) => ({
	loginErrorMessage: state.auth.loginErrorMessage,
});


const mapDispatchToProps = (dispatch) => {
	return {
		loginUser: (credentials) => {
			dispatch(authActions.loginUser(credentials));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);