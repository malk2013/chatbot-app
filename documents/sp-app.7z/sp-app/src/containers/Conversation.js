import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as messagesActions from '../actions/MessagesActions';
import AppPage from '../components/AppPage';
import Button from '../components/Button';
import MessageBox from '../components/MessageBox';
import Spinner from '../components/Spinner';
import { gettext, LOC_KEYS } from '../core/Texts';


class Conversation extends Component {

	componentDidMount () {
		Analytics.trackView('Conversation');
		const {id} = this.props.match.params;
		const {conversation, isConversationFetching} = this.props;

		if (!conversation[id] && !isConversationFetching) {
			this.props.fetchConversation(id);
		}

		this._bindedRefetchConversation = this.refetchConversation.bind(this);
		document.addEventListener('resume', this._bindedRefetchConversation);
	}

	componentWillUnmount () {
		document.removeEventListener('resume', this._bindedRefetchConversation);
	}

	getFormattedUsers (conversation) {
		if (conversation.recipients.users && conversation.recipients.users.length > 2) {

			if (conversation.showRecipients) {

				return (
					<span>
						<span className="mrs">
							{conversation.recipients.users.map(user => user.first_name + ' ' + user.last_name).join(', ')}
						</span>
						-
						<a className="link mls" onClick={() => this.props.toggleRecipients(this.props.match.params.id)}>
							{ gettext(LOC_KEYS.HIDE) }
						</a>
					</span>
				);

			} else {

				return (
					<span>
						<span className="mrs">{conversation.recipients.formatted}</span>
						- <a className="link mls" onClick={() => this.props.toggleRecipients(this.props.match.params.id)}>
							{ gettext(LOC_KEYS.SHOW) }
						</a>
					</span>
				);
			}

		} else {
			return (
				<span>
					{conversation.recipients.formatted}
				</span>
			);
		}
	}

	postMessage () {
		this.props.postMessage(this.props.match.params.id, this.refs.message.value);
	}

	refetchConversation () {
		const {id} = this.props.match.params;
		this.props.fetchConversation(id);
	}

	render () {
		const {messageError} = this.props;
		const {id} = this.props.match.params;
		const conversation = this.props.conversation[id];
		let title, info, content;

		if (conversation) {
			title = (conversation.title) ? conversation.title : gettext(LOC_KEYS.CONV_NO_TITLE);

			const isInformationLocked = (conversation.is_information && conversation.creator.id !== this.props.user.id);

			info = (
				<div className="conversation-info">
					<ul>
						<li>
							<label> { gettext(LOC_KEYS.CONV_SENDER) }</label>
							<span>{conversation.creator.first_name + ' ' + conversation.creator.last_name}</span>
						</li>
						<li>
							{!conversation.recipients.to_group && (
								<label>{ gettext(LOC_KEYS.CONV_PARTICIPANTS) }</label>
							)}
							<span>{this.getFormattedUsers(conversation)}</span>
						</li>
					</ul>

					{isInformationLocked && (
						<div className="is-information-container center pvs phm mts">
							<h4><span className="fui-icon fui-info-circle"></span> { gettext(LOC_KEYS.INFO) }</h4>
							<p> { gettext(LOC_KEYS.CONV_NO_REPLY) } </p>
						</div>
					)}

					{!isInformationLocked && (
						<div>
							{conversation.showMessageForm && (
								<div className="conversation-message-form">
									<div className="form-group mtm mbn">
										<textarea
											className="message form-control"
											placeholder="Skriv ett meddelande"
											ref="message"
										/>
									</div>
									{this.props.isPostMessageFetching && (
										<div className="pam">
											<Spinner />
										</div>
									)}

									{messageError && (
										<p className="error center pas">{messageError}</p>
									)}

									{!this.props.isPostMessageFetching && (
										<div className="form-group center">
											<Button
												text={ gettext(LOC_KEYS.CANCEL) }
												onClick={() => this.props.toggleMessageForm(this.props.match.params.id)}
											/>
											<Button
												text={ gettext(LOC_KEYS.SEND) }
												onClick={this.postMessage.bind(this)}
											/>
										</div>
									)}
								</div>
							)}

							{!conversation.showMessageForm && (
								<div className="center mtm">
									<Button text={ gettext(LOC_KEYS.WRITE) } onClick={() => this.props.toggleMessageForm(this.props.match.params.id)} />
								</div>
							)}
						</div>
					)}
				</div>
			);

			let messages = [...conversation.messages];
			const messageBoxes = messages.reverse().map((message, index) => {
				return <MessageBox
					key={index}
					message={message}
				/>;
			});

			content = (
				<div>
					{messageBoxes}
				</div>
			);
		} else if (this.props.conversationErrorMessage) {
			title = gettext(LOC_KEYS.ERROR);
			content = <div className="center pal">
				<p className="mbm"> { gettext(LOC_KEYS.CONV_ERROR) } </p>
				<a onClick={this.refetchConversation.bind(this)} className="btn btn-main"> { gettext(LOC_KEYS.TRY_AGAIN) } </a>
			</div>;
		} else {
			title = gettext(LOC_KEYS.LOADING);
			content = <Spinner verticalMargin={true} />;
		}

		return (
			<AppPage className="conversation-page">
				<div className="container">
					<header className="center">
						<h2>{title}</h2>
					</header>

					{info}

					<div className="content">
						{content}
					</div>
				</div>
			</AppPage>
		);
	}
}

const mapStateToProps = (state) => {
	const { auth, messages } = state;
	const { user } = auth;
	const { conversation, conversationErrorMessage, messageError, isPostMessageFetching, isConversationFetching } = messages;

	return {
		conversation,
		conversationErrorMessage,
		isConversationFetching,
		isPostMessageFetching,
		messageError,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchConversation: (conversationId) => {
			dispatch(messagesActions.fetchConversation(conversationId));
		},
		toggleRecipients: (conversationId) => {
			dispatch(messagesActions.toggleRecipients(conversationId));
		},
		toggleMessageForm: (conversationId) => {
			dispatch(messagesActions.toggleMessageForm(conversationId));
		},
		postMessage: (conversationId, message) => {
			dispatch(messagesActions.postMessage(conversationId, message));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Conversation);
