import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as homeActions from '../actions/HomeActions';

import Analytics from '../analytics';
import Utils from '../core/Utils';
import AppPage from '../components/AppPage';
import SchoolDayInfoRow from '../components/SchoolDayInfoRow';
import Spinner from '../components/Spinner';

import { gettext, LOC_KEYS } from '../core/Texts';

class SchoolDay extends Component {

	componentDidMount () {
		Analytics.trackView('SchoolDay');

		this.checkContent(this.props);
	}

	componentWillReceiveProps (nextProps) {
		const {user} = nextProps;
		if (!user.isParentWithActiveChild() && !user.isStudent()) {
			nextProps.history.replace('/home');
		}

		this.checkContent(nextProps);
	}

	checkContent (props) {
		const {isFetching, shoolDayErrorMessage, schoolDayInfo} = props;

		if (!schoolDayInfo && !isFetching && !shoolDayErrorMessage) {
			this.fetchInfo(props);
		}
	}

	fetchInfo (props) {
		const {fetchSchoolDayInfo, user} = props;

		if (user.isParentWithActiveChild()) {
			fetchSchoolDayInfo(user.activeChild.id);
		} else if (user.isStudent()) {
			fetchSchoolDayInfo(user.id);
		}
	}

	formatLessonsRow (lessonCount, subjects) {
		let output;
		if (lessonCount === 0) {
			output = gettext(LOC_KEYS.NO_LESSONS);
		} else {
			if (lessonCount === 1) {
				output = gettext(LOC_KEYS.ONE_LESSON);
			} else {
				output = lessonCount + gettext(LOC_KEYS.MORE_LESSONS);
			}

			if (subjects) {
				output += ':\n' + subjects.join(', ');
			}
		}

		return output;
	}

	formatNextLessonRow (nextLesson) {
		if (!nextLesson) {
			return '-';
		} else {
			let output = nextLesson.start.substr(0, 5) + ', ' + nextLesson.subject;
			/*if (nextLesson.room) {
				output += '. Sal ' + nextLesson.room;
			}*/

			return output;
		}
	}

	render () {
		const {shoolDayErrorMessage, schoolDayInfo, user} = this.props;

		if (!user.isParentWithActiveChild() && !user.isStudent()) {
			return null;
		}

		let content;
		if (shoolDayErrorMessage) {
			content = (
				<div className="center phm">
					<p className="error mtm">{shoolDayErrorMessage}</p>
					<a
						onClick={() => this.fetchInfo(this.props)}
						className="btn btn-main mvm"
					> { gettext(LOC_KEYS.TRY_AGAIN) } </a>
				</div>
			);

		} else if (schoolDayInfo) {
			if (user.isStudent() || user.isParentWithActiveChild()) {

				let nextLessonLink = '';
				if (schoolDayInfo.next_lesson) {
					const week = Utils.getWeek();
					const weekday = Utils.getCurrentWeekday();
					nextLessonLink = 'lesson/' + week + '/' + weekday + '/' + schoolDayInfo.next_lesson.id;
				}

				let info = '';
				if (schoolDayInfo.breaks) {
					info += schoolDayInfo.breaks.map(scheduleBreak => scheduleBreak.name).join('\n') + '\n';
				}

				if (schoolDayInfo.schedule_event_instances) {
					info += schoolDayInfo.schedule_event_instances.map(info => (
						info.schedule_event.name + ', ' + info.schedule_event.formatted_time
					)).join('\n') + '\n';
				}

				content = (
					<ul>
						<SchoolDayInfoRow
							icon="calendar"
							title={Utils.format_date('%l, %a %F', new Date())}
							content={schoolDayInfo.start + ' - ' + schoolDayInfo.end}
						/>

						<SchoolDayInfoRow
							icon="time"
							title={gettext(LOC_KEYS.SCHOOL_DAY_NEXT_LESSON)}
							content={this.formatNextLessonRow(schoolDayInfo.next_lesson)}
							link={nextLessonLink}
						/>

						<SchoolDayInfoRow
							icon="bookmark"
							title={gettext(LOC_KEYS.SCHOOL_DAY_LESSONS)}
							content={this.formatLessonsRow(schoolDayInfo.lesson_count, schoolDayInfo.subjects)}
						/>

						<SchoolDayInfoRow
							icon="heart"
							title={gettext(LOC_KEYS.SCHOOL_DAY_TODAYS_FOOD)}
							content={schoolDayInfo.food ? schoolDayInfo.food.menu : gettext(LOC_KEYS.NO_INFO)}
						/>

						<SchoolDayInfoRow
							icon="info-circle"
							title={gettext(LOC_KEYS.SCHOOL_DAY_OTHER_INFO)}
							content={info || gettext(LOC_KEYS.NO_INFO)}
						/>
					</ul>
				);
			}
		} else {
			content = <Spinner verticalMargin={true} />;
		}

		return (
			<AppPage className="school-day-page">
				<div className="container">
					<header className="center">
						<h2>{gettext(LOC_KEYS.SCHOOL_DAY_HEADER,
							{ 'name': user.isStudent()
								? gettext(LOC_KEYS.MINE)
								: Utils.addS(user.activeChild.first_name) })}</h2>
					</header>

					<div className="content">
						<div className="school-day-info">
							{content}
						</div>
					</div>
				</div>
			</AppPage>
		);

	}

}

const mapStateToProps = (state) => {
	const { auth, home } = state;
	const { user } = auth;
	const { isFetching, shoolDayErrorMessage, schoolDayInfo } = home;

	return {
		isFetching,
		shoolDayErrorMessage,
		schoolDayInfo,
		user,
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchSchoolDayInfo: (activeChildId) => {
			dispatch(homeActions.fetchSchoolDayInfo(activeChildId));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(SchoolDay);
