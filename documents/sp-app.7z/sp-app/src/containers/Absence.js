import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

import Analytics from '../analytics';
import * as absenceActions from '../actions/AbsenceActions';

import AppPage from '../components/AppPage';
import Button from '../components/Button';
import Spinner from '../components/Spinner';

import { gettext, LOC_KEYS } from '../core/Texts';


class Absence extends Component {

	componentDidMount () {
		Analytics.trackView('Absence');
		const {id} = this.props.match.params;
		const {absence, isFetching} = this.props;

		if (!absence && !isFetching || (absence && absence.id !== id)) {
			setTimeout(() => (this.props.fetchAbsence(id)), 300);
		}
	}

	render () {
		let {absence, isConfirming, user} = this.props;

		return (
			<AppPage className="absence-page">

				{(!absence || (absence && absence.id != this.props.match.params.id)) && (
					<div className="container">
						<header className="center">
							{!absence &&
								<h2>{ gettext(LOC_KEYS.LOADING) }</h2>
							}
							{absence && (absence.confirmed
								? <h2>{ gettext(LOC_KEYS.PRESENCE_BUTTON_CONFIRMED) }</h2>
								: <h2>{ gettext(LOC_KEYS.PRESENCE_BUTTON_UNCONFIRMED) }</h2>
							)}
						</header>
						<div className="content">
							<Spinner verticalMargin={true} />
						</div>
					</div>
				)}

				{absence && absence.id == this.props.match.params.id && (
					<div>
						<div className="container">
							<header className="center">
								{absence.confirmed
									? <h2>{ gettext(LOC_KEYS.PRESENCE_BUTTON_CONFIRMED) }</h2>
									: <h2>{ gettext(LOC_KEYS.PRESENCE_BUTTON_UNCONFIRMED) }</h2>}
							</header>

							<div className="content pam">
								<div className="center">
									<div>
										{ gettext(LOC_KEYS.ABSENCE_REPORTED_ABSENT, { name: user.activeChild.first_name}) }
										{' '}
										{absence.lesson.info.subject},
										{' kl '}
										{absence.lesson.info.time }
									</div>

									<div className="mtm">
										{absence.confirmed && (
											<p> { gettext(LOC_KEYS.ABSENCE_REPORTED_CONFIRMED) } </p>
										)}

										{!absence.confirmed && !isConfirming && (
											<div>
												<Button
													onClick={() => {this.props.confirmAbsence(absence.id, user.id);}}
													text={ gettext(LOC_KEYS.ABSENCE_REPORTED_CONFIRM) }
												/>
												<p className="mtm dark-grey">
													{ gettext(LOC_KEYS.ABSENCE_INFORM_SICKNESS, { name: user.activeChild.first_name})}
													<Link to='' onClick={() => {this.props.history.push('/sickness');}}>
														{ gettext(LOC_KEYS.ABSENCE_SICKNESS)}
													</Link>
												</p>
											</div>
										)}
										{!absence.confirmed && isConfirming && (
											<Spinner verticalMargin={false} />
										)}
									</div>
								</div>
							</div>
						</div>

						<div className="container mtl">
							<header className="center">
								<h2> { gettext(LOC_KEYS.ABSENCE_EVENTS) } </h2>
							</header>

							<div className="content">
								<ul className="main-list">
									{absence.logs.map(log => {
										return (
											<li key={log.id}>
												<div className="clearfix">
													<strong className="pull-left">
														{log.created_at}
													</strong>
													{log.created_by && (
														<span className="txt-sm pull-right mtxxs">
															{log.created_by.first_name + ' ' + log.created_by.last_name}
														</span>
													)}
												</div>
												<p>
													{log.content}
												</p>
											</li>
										);
									})}
								</ul>
							</div>
						</div>
					</div>
				)}
			</AppPage>
		);
	}
}


const mapStateToProps = (state) => {
	const { auth, absence } = state;
	const { user } = auth;
	const { errorMessage, isConfirming, isFetching } = absence;
	return {
		absence: absence.absence,
		errorMessage,
		isConfirming,
		isFetching,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		confirmAbsence: (absenceId, userId) => {
			dispatch(absenceActions.confirmAbsence(absenceId, userId));
		},

		fetchAbsence: (absenceId) => {
			dispatch(absenceActions.fetchAbsence(absenceId));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Absence);
