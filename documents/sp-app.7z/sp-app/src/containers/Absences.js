import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as absenceActions from '../actions/AbsenceActions';

import AppPage from '../components/AppPage';
import AbsenceRow from '../components/AbsenceRow';
import Button from '../components/Button';
import Spinner from '../components/Spinner';

import { gettext, LOC_KEYS} from '../core/Texts';

class Absences extends Component {

	componentWillMount () {
		Analytics.trackView('Absences');
		const { match, showConfirmed, toggleShowConfirmed } = this.props;
		if (
			(match.path == '/absence/unconfirmed' && showConfirmed) ||
			(match.path == '/absence/confirmed' && !showConfirmed)
		) {
			toggleShowConfirmed();
		} else {
			this.checkContent(this.props);
		}
	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	checkContent (props) {
		const {absences, isFetching, errorMessage, showConfirmed, user} = props;

		if (!absences && !isFetching && !errorMessage && user.isParentWithActiveChild()) {
			props.fetchAbsences(user.activeChild.id, 1, showConfirmed);
		}
	}

	refetchPage () {
		const {pagination, showConfirmed, user} = this.props;
		let page = pagination.page || 1;
		this.props.fetchAbsences(user.activeChild.id, page, showConfirmed);
	}

	render () {
		let {absences, isFetching, pagination, showConfirmed, user} = this.props;
		absences = absences || [];

		return (
			<AppPage className="absence-page">
				<div className="container">
					<header className="center">
						{showConfirmed
							? <h2>{ gettext(LOC_KEYS.PRESENCE_BUTTON_CONFIRMED) }</h2>
							: <h2>{ gettext(LOC_KEYS.PRESENCE_BUTTON_UNCONFIRMED) }</h2>}
					</header>

					<div className="content">
						{(absences.length > 0) && (
							<div>
								<div className="center pam">
									{showConfirmed
										? <p>{ gettext(LOC_KEYS.ABSENCES_REPORTED_CONFIRMED_INFO) }</p>
										: <p>{ gettext(LOC_KEYS.ABSENCES_REPORTED_UNCONFIRMED_INFO, { name: user.activeChild.first_name }) }</p>
									}
								</div>
								<div>
									{absences.map(absence => {
										return <AbsenceRow
											key={absence.id}
											absence={absence}
											history={this.props.history}
											user={user}
										/>;
									})}

									{(pagination.page < pagination.num_pages) && (
										<div className="center pam">
											<Button
												onClick={() => {this.props.fetchAbsences(user.activeChild.id, pagination.page + 1, showConfirmed);}}
												text={ gettext(LOC_KEYS.SHOW_MORE) }
											/>
										</div>
									)}
								</div>
							</div>
						)}

						{(!isFetching && this.props.errorMessage) && (
							<div className="pal center">
								<p>{this.props.errorMessage}</p>
								<a className="link mtm" onClick={this.refetchPage.bind(this)}> { gettext(LOC_KEYS.TRY_AGAIN) } </a>
							</div>
						)}

						{(!isFetching && !absences.length && !this.props.errorMessage) && (
							<div className="pal center">
								{showConfirmed && (
									<span>{ gettext(LOC_KEYS.ABSENCES_NO_CONFIRMED, { name: user.activeChild.first_name}) }</span>
								)}

								{!showConfirmed && (
									<span>{ gettext(LOC_KEYS.ABSENCES_NO_UNCONFIRMED, { name: user.activeChild.first_name}) }</span>
								)}
							</div>
						)}

						{isFetching && (
							<Spinner verticalMargin={true} />
						)}
					</div>
				</div>
			</AppPage>
		);
	}
}


Absences.propTypes = {
	history: PropTypes.shape({
		push: PropTypes.func.isRequired
	}).isRequired
};


const mapStateToProps = (state) => {
	const { auth, absence } = state;
	const { user } = auth;
	const { absences, errorMessage, isFetching, pagination, showConfirmed } = absence;
	return {
		absences,
		errorMessage,
		isFetching,
		pagination,
		showConfirmed,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchAbsences: (activeChildId, page, confirmed) => {
			dispatch(absenceActions.fetchAbsences(activeChildId, page, confirmed));
		},

		toggleShowConfirmed: () => {
			dispatch(absenceActions.toggleShowConfirmed());
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Absences);
