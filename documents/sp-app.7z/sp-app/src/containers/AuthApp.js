import React, { Component } from 'react';

import Spinner from '__components/Spinner';

import UI from '__components/UI';
import ErrorPage from '__components/ErrorPage';
import { gettext, LOC_KEYS } from '../core/Texts';


const FullSpinner = (
	<div className="center">
		<Spinner fullscreen={true} inverted={true} />
	</div>
);

class AuthApp extends Component {
	componentWillMount () {
		if (!this.props.user.id && !this.props.isFetching) {
			this.props.fetchAccount();
		}
	}

	render () {
		const {account, accountErrorMessage, user, isFetching} = this.props;

		const FullErrorPage = (
			<ErrorPage
				text={accountErrorMessage}
				retry={this.props.fetchAccount}
			/>
		);
		if (!user.id) {

			if (!localStorage.getItem('sp_refresh_token')) {
				return (
					<ErrorPage
						text={ gettext(LOC_KEYS.LOG_IN_AGAIN)}
						btnText="Ok"
						retry={this.props.logoutUser}
					/>
				);
			} else if (accountErrorMessage) {
				if (accountErrorMessage === 'NO_SP_USER') {
					return (
						<ErrorPage
							text={ gettext(LOC_KEYS.NO_SP_USER)}
							btnText="Ok"
							retry={this.props.logoutUser}
						/>
					);
				} else {
					return FullErrorPage;
				}
			} else {
				return FullSpinner;
			}
		} else if (isFetching) {
			return FullSpinner;
		} else if (user.id && accountErrorMessage) {
			return FullErrorPage;
		}

		return (
			<UI
				menuOpen={this.props.menuOpen}
				history={this.props.history}
				location={this.props.location}
				account={account}
				user={user}
				setActiveChild={this.props.setActiveChild}
				setActiveUser={this.props.setActiveUser}
				openMenu={this.props.openMenu}
				closeMenu={this.props.closeMenu}
				dialogs={this.props.dialogs}
				logoutUser={this.props.logoutUser}
			>
				{ this.props.children }
			</UI>
		);
	}
}

export default AuthApp;