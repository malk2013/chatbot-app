import React, { Component } from 'react';
import { connect } from 'react-redux';

import moment from 'moment';

import Analytics from '../analytics';

import * as leisureActions from '../actions/LeisureActions';
import AppPage from '../components/AppPage';
import Button from '../components/Button';
import LeisureScheduleForm from '../components/LeisureScheduleForm';
import LeisureScheduleWeekForm from '../components/LeisureScheduleWeekForm';
import Icon from '../components/Icon';
import SchoolDayInfoRow from '../components/SchoolDayInfoRow';
import Spinner from '../components/Spinner';
import Utils from '../core/Utils';
import { gettext, LOC_KEYS } from '../core/Texts';


class Leisure extends Component {

	componentDidMount () {
		Analytics.trackView('Leisure');

		if (this.props.currentWeekday === false) {
			this.props.setWeek(Utils.getWeek(), Utils.getYear(), Utils.getClosestSchoolWeekday() - 1);
		}

		this.checkContent(this.props);
	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	checkContent (props) {
		const {currentLeisureWeek, currentWeek, currentYear, fetchLeisureWeekError, isFetching, leisureInfo,  user} = props;

		if (!leisureInfo && !isFetching) {
			if (user.isParentWithActiveChild()) {
				props.fetchLeisureInfo(user.activeChild.id);
			}
		} else {
			// Check if the user has navigated to a new week and load it if neccessary.
			if ((!currentLeisureWeek || currentLeisureWeek.week != currentWeek) && !isFetching && !fetchLeisureWeekError) {
				props.fetchLeisureWeek(user.activeChild.id, currentWeek || Utils.getWeek(), currentYear || Utils.getYear());
			}
		}
	}

	saveDefaultWeek () {
		const {user} = this.props;
		this.props.saveDefaultWeek(user.activeChild.id, this.refs.defaultWeekForm.getDays());
	}

	deleteSchedule () {
		const {user} = this.props;
		this.props.deleteLeisureSchedule(user.activeChild.id);
	}

	submitScheduleForm () {
		const {user} = this.props;
		const startYear = this.refs.leisureScheduleForm.state.startYear;
		const startWeek = this.refs.leisureScheduleForm.state.startWeek;
		const endYear = this.refs.leisureScheduleForm.state.endYear;
		const endWeek = this.refs.leisureScheduleForm.state.endWeek;

		this.props.saveLeisureSchedule(user.activeChild.id, startYear, startWeek, endYear, endWeek);
	}

	render () {
		const {defaultWeekError, isSavingLeisure, leisureInfo, user} = this.props;
		let content;
		let showLoading = true;

		let dt = new Date();
		let currentYear = dt.getFullYear();
		let onejan = new Date(currentYear, 0, 1);
		let currentWeek = Math.ceil((((dt - onejan) / 86400000) + onejan.getDay() + 1) / 7);

		if (leisureInfo) {
			if (!leisureInfo.leisure_group.name) {

				// ****************************** Active child has no leisure group ******************************
				showLoading = false;
				content = (
					<div className="container">
						<header className="center">
							<h2> { gettext(LOC_KEYS.LEISURE_REG_SCHEDULE)}</h2>
						</header>

						<div className="content center pam">
							<p> { gettext(LOC_KEYS.LEISURE_NO_GROUP, { name: user.activeChild.first_name})} </p>
						</div>
					</div>
				);

			} else if (
				leisureInfo.has_leisure_schedule && (
					leisureInfo.leisure_schedule.end_year < currentYear ||
					(
						leisureInfo.leisure_schedule.end_year === currentYear &&
						leisureInfo.leisure_schedule.end_week < currentWeek
					)
				)
			) {

				// ****************************** The register schedule is outdated ******************************
				showLoading = false;
				content = (
					<div className="container">
						<header className="center">
							<h2> { gettext(LOC_KEYS.LEISURE_REG_SCHEDULE)}</h2>
						</header>

						<div className="content center pam">
							<p> { gettext(LOC_KEYS.LEISURE_REG_SCHEDULE_OUTDATED_INFO) } </p>

							<div className="center pas mts">
								<Button
									onClick={(event) => this.deleteSchedule(event)}
									text={ gettext(LOC_KEYS.CONTINUE) }
								/>
							</div>
						</div>
					</div>
				);

			} else if (!leisureInfo.has_leisure_schedule) {

				// ****************************** Step 1 - Register schedule ******************************
				showLoading = false;
				content = (
					<div className="container">
						<header className="center">
							<h2> { gettext(LOC_KEYS.LEISURE_REG_SCHEDULE)}</h2>
						</header>

						<div className="content center pam">
							<p> { gettext(LOC_KEYS.LEISURE_REG_SCHEDULE_INFO, { name: user.activeChild.first_name}) } </p>

							<LeisureScheduleForm
								ref="leisureScheduleForm"
								startYear={leisureInfo.schedule.start_year}
								startWeek={leisureInfo.schedule.start_week}
								endYear={leisureInfo.schedule.end_year}
								endWeek={leisureInfo.schedule.end_week}
							/>

							{!isSavingLeisure && (
								<Button
									onClick={(event) => this.submitScheduleForm(event)}
									text={ gettext(LOC_KEYS.CONTINUE) }
									className="mts"
								/>
							)}

							{isSavingLeisure && (
								<Spinner verticalMargin={true} />
							)}
						</div>
					</div>
				);

			} else {

				if (!leisureInfo.leisure_schedule.default_week) {

					// ****************************** Step 2 - Register default week ******************************
					showLoading = false;
					content = (
						<div>
							<div className="container">
								<header className="center">
									<h2>{ gettext(LOC_KEYS.LEISURE_REG_SCHEDULE) }</h2>
								</header>

								<div>
									<div className="content center">
										<p className="phm ptm pbs">
											{ gettext(LOC_KEYS.LEISURE_REG_SCHEDULE_LABEL) }
										</p>

										<LeisureScheduleWeekForm
											ref="defaultWeekForm"
											errors={defaultWeekError}
										/>

										{!isSavingLeisure && (
											<Button
												onClick={(event) => this.saveDefaultWeek(event)}
												text={ gettext(LOC_KEYS.SAVE)}
												className="mts mbm"
											/>
										)}
									</div>
								</div>
							</div>
						</div>
					);

				} else {

					// ****************************** Main view ******************************
					const {currentLeisureWeek, currentWeek, currentWeekday, showLeisureDayInWeek} = this.props;
					const todaysDate = Utils.format_date_standard(new Date());
					if (currentLeisureWeek && currentWeek && currentWeekday !== false && currentLeisureWeek.week == currentWeek) {
						const today = currentLeisureWeek.day_dicts[currentWeekday];

						showLoading = false;
						const now = Date.now();
						content = (
							<div>
								<div className="container">
									<header className="arrow-header">
										<h2>{today.day_name + ', ' + today.formatted_date}</h2>
										<Icon name="arrow-left" className="prev-day" onClick={this.props.showPrevLeisureDay} />
										<Icon name="arrow-right" className="next-day" onClick={this.props.showNextLeisureDay} />
									</header>

									<div className="icon-list">
										<ul>
											<SchoolDayInfoRow
												icon="calendar"
												title={ gettext(LOC_KEYS.SCHOOL_DAY_TODAYS_TIMES) }
												content={today.is_active ? today.start_time + ' - ' + today.end_time : gettext(LOC_KEYS.LEISURE_NONE_TODAY)}
											/>
											{today.comment && (
												<SchoolDayInfoRow
													icon="info-circle"
													title={ gettext(LOC_KEYS.COMMENT) }
													content={today.comment}
												/>
											)}
											<li className="center" style={{ padding: '10px' }}>
												{todaysDate <= today.date && (
													<Button
														onClick={(e) => {
															e.preventDefault();
															e.stopPropagation();
															this.props.history.push('/leisure/weekday/' + today.date);
														}}
														text={ gettext(LOC_KEYS.CHANGE) }
														className="wide"
													/>
												)}
											</li>
										</ul>
									</div>
								</div>

								<div className="container mtm pbm mbs">
									<header className="arrow-header">
										<h2>v.{currentWeek}</h2>
										<Icon name="arrow-left" className="prev-day" onClick={this.props.showPrevLeisureWeek} />
										<Icon name="arrow-right" className="next-day" onClick={this.props.showNextLeisureWeek} />
									</header>

									<div className="mas">
										<table className="table leisure-schedule-table">
											<thead>
												<tr>
													<th>{ gettext(LOC_KEYS.DATE) }</th>
													<th>{ gettext(LOC_KEYS.DAY) }</th>
													<th className="center">{ gettext(LOC_KEYS.LEISURE_LEAVE) } </th>
													<th className="center">{ gettext(LOC_KEYS.LEISURE_GET) } </th>
												</tr>
											</thead>
											<tbody>
												{[0, 1, 2, 3, 4].map(function (i) {
													const day = currentLeisureWeek.day_dicts[i];
													const isToday = moment(day.date).isSame(now, 'day');
													const startTime = day.is_active ? day.start_time : '-';
													const endTime = day.is_active ? day.end_time : '-';

													return (
														<tr
															key={i}
															className={currentWeekday == i ? 'selected' : ''}
															onClick={() => showLeisureDayInWeek(i)}
														>
															<td className="weekday-name">
																{isToday ? (
																	<strong>{day.formatted_date}</strong>
																) : day.formatted_date}
															</td>
															<td className="weekday-name">
																{isToday ? (
																	<strong>{day.day_name}</strong>
																) : day.day_name}
															</td>
															<td className="center">
																{isToday ? (
																	<strong>{startTime}</strong>
																) : startTime}
															</td>
															<td className="center">
																{isToday ? (
																	<strong>{endTime}</strong>
																) : endTime}
															</td>
														</tr>
													);
												})}
											</tbody>
										</table>
									</div>
								</div>

								<div className="center pas">
									<Button
										text={ gettext(LOC_KEYS.LEISURE_REG_BASIS_SCHEDULE) }
										className="full-width"
										onClick={(e) => {e.preventDefault(); e.stopPropagation(); this.props.history.push('/leisure/default-week');}}
									/>
								</div>
							</div>
						);
					}
				}

			}
		}


		if (showLoading) {
			content = (
				<div className="container">
					<header className="center">
						<h2>{ LOC_KEYS.LOADING }</h2>
					</header>

					<div className="content center pam">
						<Spinner verticalMargin={true} />
					</div>
				</div>
			);
		}

		return (
			<AppPage className="leisure-page">
				{content}
			</AppPage>
		);
	}
}

const mapStateToProps = (state) => {
	const { auth, leisure } = state;
	const { user } = auth;
	const { currentLeisureWeek, currentWeek, currentWeekday, defaultWeekError, fetchLeisureWeekError, isSavingLeisure, isFetching, leisureInfo } = leisure;

	return {
		currentLeisureWeek,
		currentWeek,
		currentWeekday,
		defaultWeekError,
		fetchLeisureWeekError,
		isFetching,
		isSavingLeisure,
		leisureInfo,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchLeisureInfo: (activeChildId) => {
			dispatch(leisureActions.fetchLeisureInfo(activeChildId));
		},

		deleteLeisureSchedule: (activeChildId) => {
			dispatch(leisureActions.deleteLeisureSchedule(activeChildId));
		},

		saveLeisureSchedule: (activeChildId, startYear, startWeek, endYear, endWeek) => {
			dispatch(leisureActions.saveLeisureSchedule(activeChildId, startYear, startWeek, endYear, endWeek));
		},

		saveDefaultWeek: (activeChildId, days) => {
			dispatch(leisureActions.saveDefaultWeek(activeChildId, days));
		},

		setWeek: (week, year, weekday) => {
			dispatch(leisureActions.setWeek(week, year, weekday));
		},

		fetchLeisureWeek: (activeChildId, week, year) => {
			dispatch(leisureActions.fetchLeisureWeek(activeChildId, week, year));
		},

		showPrevLeisureDay: () => {
			dispatch(leisureActions.showPrevLeisureDay());
		},

		showNextLeisureDay: () => {
			dispatch(leisureActions.showNextLeisureDay());
		},

		showLeisureDayInWeek: (day) => {
			dispatch(leisureActions.showLeisureDayInWeek(day));
		},

		showPrevLeisureWeek: () => {
			dispatch(leisureActions.showPrevLeisureWeek());
		},

		showNextLeisureWeek: () => {
			dispatch(leisureActions.showNextLeisureWeek());
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Leisure);
