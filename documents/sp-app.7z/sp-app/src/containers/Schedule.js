import React, { Component } from 'react';
import { connect } from 'react-redux';
import classnames from 'classnames';

import Analytics from '../analytics';

import Environment from '../core/Environment';
import Utils from '../core/Utils';

import * as scheduleActions from '../actions/ScheduleActions';
import AppPage from '../components/AppPage';
import ScheduleEventBox from '../components/ScheduleEventBox';
import Icon from '../components/Icon';
import LessonBox from '../components/LessonBox';
import Spinner from '../components/Spinner';

import { gettext, LOC_KEYS } from '../core/Texts';

class Schedule extends Component {

	componentDidMount () {
		Analytics.trackView('Schedule');

		if (this.props.currentWeekday === false) {
			this.props.setWeekday(Utils.getClosestSchoolWeekday());
		}
		this.checkContent(this.props);
	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	checkContent (props) {
		const {currentWeek, isFetching, user, weekSchedules} = props;

		// Check if the user has navigated to a new week and load it if neccessary.
		if ((!currentWeek || !weekSchedules[props.currentWeek]) && !isFetching) {
			const scheduleEndPoint = user.getScheduleEndPoint();
			if (scheduleEndPoint) {
				props.fetchSchedule(scheduleEndPoint + '?week=' + props.currentWeek);
			}
		}
	}

	goNext () {
		if (this.shouldDisplayWeek()) {
			this.props.showNextWeek();
		} else {
			this.props.showNextDay();
		}
	}

	goPrev () {
		if (this.shouldDisplayWeek()) {
			this.props.showPrevWeek();
		} else {
			this.props.showPrevDay();
		}
	}

	shouldDisplayWeek () {
		return Environment.isTabletSized() || Environment.isLandscape();
	}

	render () {
		let content;
		let title;

		const { weekSchedules, currentWeek, currentWeekday } = this.props;

		if (currentWeekday && currentWeek && weekSchedules[currentWeek]) {
			const displayWeek = this.shouldDisplayWeek();
			const currentWeekSchedule = weekSchedules[currentWeek];
			const {time_range, section_count, days, breaks} = currentWeekSchedule;
			const day = days[currentWeekday - 1];
			const displayDays = (displayWeek) ? days : [day];

			title = (displayWeek) ? 'Vecka ' + currentWeek : day.name + ' ' + day.formated_date;

			let breaksMap = {};
			breaks.forEach(schoolBreak => {
				breaksMap[schoolBreak.id] = schoolBreak;
			});

			const classNames = classnames({
				'display-week': displayWeek,
				'display-day': !displayWeek
			}, 'schedule-calendar');


			content = (
				<div className={classNames}>
					<ul className="time-index">
						{time_range.map((time, i) => {
							return <li key={i}>{time}</li>;
						})}
					</ul>
					<ul className="calendar-list">
						{displayDays.map((displayDay, i) => (
							<li className="day" key={i}>
								{displayWeek && (
									<div className="head">
										<strong>{ displayDay.name }</strong>
										<span>{ displayDay.formated_date }</span>
									</div>
								)}

								<div className="body">
									<ul>
										{Array(section_count + 2).fill().map((_, i) => (<li key={i}></li>))}
									</ul>

									{displayDay.lessons.map(lesson => {
										const weekday = displayWeek ? i + 1 : currentWeekday;
										const lessonHref = `/lesson/${currentWeek}/${weekday}/${lesson.lesson_id}`;
										return (
											<LessonBox
												key={lesson.lesson_id}
												lesson={lesson}
												sectionCount={section_count}
												to={lessonHref}
											/>
										);
									})}

									{displayDay.breaks.map((breakId, i) => (
										<div className="break" key={i}>
											<span> {breaksMap[breakId].name}</span>
										</div>
									))}

									{displayDay.events.map((event, i) => (
										<ScheduleEventBox
											key={i}
											event={event}
											sectionCount={section_count}
										/>
									))}
								</div>
							</li>
						))}
					</ul>
				</div>
			);
		} else {
			content = <Spinner verticalMargin={true} />;
			title = gettext(LOC_KEYS.LOADING);
		}

		return (
			<AppPage className="schedule-page">
				<div className="container">
					<header className="arrow-header">
						<h2>{title}</h2>
						<Icon name="arrow-left" className="prev-day" onClick={this.goPrev.bind(this)} />
						<Icon name="arrow-right" className="next-day" onClick={this.goNext.bind(this)} />
					</header>

					<div className="content">
						{content}
					</div>
				</div>
			</AppPage>
		);

	}
}

const mapStateToProps = (state) => {
	const { auth, schedule, ui } = state;
	const { user } = auth;
	const { orientation } = ui;
	const { isFetching, weekSchedules, currentWeek, currentWeekday } = schedule;

	return {
		currentWeek,
		currentWeekday,
		isFetching,
		orientation,
		weekSchedules,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchSchedule: (endpoint) => {
			dispatch(scheduleActions.fetchSchedule(endpoint));
		},
		showPrevDay: () => {
			dispatch(scheduleActions.showPrevDay());
		},
		showNextDay: () => {
			dispatch(scheduleActions.showNextDay());
		},
		showPrevWeek: () => {
			dispatch(scheduleActions.showPrevWeek());
		},
		showNextWeek: () => {
			dispatch(scheduleActions.showNextWeek());
		},
		setWeekday: (weekday) => {
			dispatch(scheduleActions.setWeekday(weekday));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Schedule);
