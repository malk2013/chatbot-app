import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from 'react-redux';
import Analytics from '../analytics';
import Config from '../config';
import * as messagesActions from '../actions/MessagesActions';
import * as UIActions from '../actions/UIActions';
import Utils from '../core/Utils';
import AppPage from '__components/AppPage';
import HomeButton from '__components/HomeButton';
import { gettext, LOC_KEYS } from '../core/Texts';

class Home extends Component {

	componentDidMount () {
		Analytics.trackView('Home');

		// this.props.fetchUnreadMessageCount();
		this.updateUnreadMessageCount();

		document.addEventListener('resume', this.updateUnreadMessageCount.bind(this), false);
	}

	componentWillUnmount () {
		document.removeEventListener('resume', this.updateUnreadMessageCount.bind(this));
	}

	updateUnreadMessageCount () {
		if (this.props.user) {
			this.props.fetchUnreadMessageCount(this.props.user.id);
		}
	}

	render () {
		const {user} = this.props;
		return (
			<AppPage className="home-page">
				{user.isParentWithActiveChild() && (
					<HomeButton
						icon="bag.svg"
						text={gettext(LOC_KEYS.HOME_BUTTON_PARENT_SCHOOLDAY,
							{ 'name': Utils.addS(user.activeChild.first_name)})}
						onClick={() => this.props.history.push('/school-day')}
					/>
				)}

				{user.isStudent() && (
					<HomeButton
						icon="bag.svg"
						text={gettext(LOC_KEYS.HOME_BUTTON_STUDENT_SCHOOLDAY)}
						onClick={() => this.props.history.push('/school-day')}
					/>
				)}

				<HomeButton
					icon="communication.svg"
					text={gettext(LOC_KEYS.HOME_BUTTON_MESSAGES)}
					notification={this.props.unreadMessagesCount}
					onClick={() => this.props.history.push('/messages')}
				/>

				{user.hasSchedule() && (
					<HomeButton
						icon="calendar.svg"
						text={gettext(LOC_KEYS.HOME_BUTTON_SCHEDULE)}
						onClick={() => this.props.history.push('/schedule')}
					/>
				)}

				{user.isParentWithActiveChild() && (
					<HomeButton
						icon="shield.svg"
						text={gettext(LOC_KEYS.HOME_BUTTON_SICKNESS)}
						onClick={() => this.props.history.push('/sickness')}
					/>
				)}

				{user.isParentWithActiveChild() && (
					<HomeButton
						icon="clocks.svg"
						text={gettext(LOC_KEYS.HOME_BUTTON_PRESENCE)}
						notification={this.props.unconfirmedAbsenceCountMap[user.activeChild.id] || 0}
						onClick={() => this.props.history.push('/absence')}
					/>
				)}

				{(user.isParentWithActiveChild() && user.activeChild.has_leisure_group) && (
					<HomeButton
						urlIcon={Config.getAssetUrl('icons/pencils.svg')}
						text={gettext(LOC_KEYS.HOME_BUTTON_LEISURE)}
						onClick={() => this.props.history.push('/leisure')}
					/>
				)}

				{user.isLeisureTeacher() && (
					<HomeButton
						icon="bag.svg"
						text={gettext(LOC_KEYS.HOME_BUTTON_LEISURE)}
						onClick={() => this.props.history.push('/school/leisure')}
					/>
				)}

				<div className="menu-link-container center">
					<span className="menu-link" onClick={this.props.openMenu}> { gettext(LOC_KEYS.OPEN_MENU) } </span>
				</div>
			</AppPage>
		);

	}
}

Home.propTypes = {
	user: PropTypes.object,
	history: PropTypes.shape({
		push: PropTypes.func.isRequired
	}).isRequired
};


const mapStateToProps = (state) => {
	const { auth, messages } = state;
	const { user } = auth;
	const { unconfirmedAbsenceCountMap, unreadMessagesCount } = messages;

	return {
		unconfirmedAbsenceCountMap,
		unreadMessagesCount,
		user,
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		openMenu: () => {
			dispatch(UIActions.openMenu());
		},

		fetchUnreadMessageCount: (userId) => {
			dispatch(messagesActions.fetchUnreadMessageCount(userId));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);