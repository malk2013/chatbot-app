import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as modalActions from '../actions/ModalActions';
import * as teacherLeisureActions from '../actions/TeacherLeisureActions';

import AppPage from '../components/AppPage';
import LeisureUserButton from '../components/LeisureUserButton';

import { gettext, LOC_KEYS } from '../core/Texts';

const Status = {
	LEAVED: 1,
	PICKEDUP: 2
};

const MarkStatus = {
	PICKEDUP: 1,
	RESETTED: 2,
	PICKEDUP_UNREGISTERED: 3,
	RESETTED_UNREGISTERED: 4
};

class SchoolLeisurePickup extends Component {

	componentDidMount () {
		Analytics.trackView('SchoolLeisurePickup');

		this._state = {
			marked: {},
			showTimes: false
		};

		this.checkContent(this.props);
	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	checkContent (props) {
		const {leisureInfo, history} = props;

		if (!leisureInfo) {
			history.replace('/school/leisure');
		}
	}

	registerLeisureStart (e, userId) {
		var _this = this;

		if (this._state.marked[userId] !== MarkStatus.PICKEDUP) {
			this._state.marked[userId] = MarkStatus.PICKEDUP;
			this.forceUpdate();

			setTimeout(function () {
				_this.props.registerLeisureEnd(_this.props.activeLeisureGroupId, userId);
			}, 500);
		} else {
			this._state.marked[userId] = MarkStatus.RESETTED;
			this.forceUpdate();

			setTimeout(function () {
				_this.props.resetLeisureEnd(_this.props.activeLeisureGroupId, userId);
			}, 500);
		}
	}

	resetLeisureStart (e, userId) {
		const _this = this;
		const ud = this.props.leisureInfo.leisure_day.user_dicts.find(ud => ud.user.id == userId);
		this.props.showConfirmDialog({
			title: gettext(LOC_KEYS.CONFIRM),
			body: gettext(LOC_KEYS.LEISURE_MARK_FETCHED, { name: ud.user.full_name}),
			callback: function () {
				_this.props.resetLeisureEnd(_this.props.activeLeisureGroupId, userId);
			}
		});
	}

	toggleTimes () {
		this._state.showTimes = !this._state.showTimes;
		this.forceUpdate();
	}

	render () {
		const {leisureInfo} = this.props;

		if (!leisureInfo) {
			return <AppPage className="leisure-page">
				{ gettext(LOC_KEYS.LOADING) }
			</AppPage>;
		}

		const markedUsers = (this._state) ? this._state.marked : {};
		const showTimes = this._state ? this._state.showTimes : false;

		const availableChildren = leisureInfo.leisure_day.user_dicts.filter(ud => (
			ud.schedule && (
				ud.schedule.status === Status.LEAVED ||
				ud.schedule.status === Status.PICKEDUP && markedUsers[ud.user.id]
			)
		));

		const pickedUpChildren = leisureInfo.leisure_day.user_dicts.filter(ud => (
			ud.schedule && ud.schedule.status === Status.PICKEDUP &&  !markedUsers[ud.user.id]
		));

		const content = (
			<div>
				<div className="container">
					<header className="center leisure-header">
						<h2>{ gettext(LOC_KEYS.LEISURE_PICK_FETCHED) }</h2>
						<span className={'fui-time ' + (showTimes ? 'active' : '')} onClick={this.toggleTimes.bind(this)}></span>
					</header>

					<div className="content pvm phs center">
						{availableChildren.length === 0 && (
							<i> { gettext(LOC_KEYS.LEISURE_ALL_FETCHED) } </i>
						)}

						{availableChildren.map((ud) => {
							return <LeisureUserButton
								className="red"
								key={'user-' + ud.user.id}
								user={ud.user}
								onClick={(e) => this.registerLeisureStart(e, ud.user.id)}
								checked={markedUsers[ud.user.id] === MarkStatus.PICKEDUP}
								status={ud.schedule ? ud.schedule.status : '-'}
								goHome={ud.schedule ? ud.schedule.go_home : false}
								showTimes={showTimes}
								schedule={ud.schedule}
							/>;
						})}
					</div>
				</div>

				{!!pickedUpChildren.length && (
					<div className="container mtm">
						<header className="center">
							<h2> { gettext(LOC_KEYS.LEISURE_FETCHED_CHILDREN) } </h2>
						</header>

						<div className="content pvm phs center">
							{pickedUpChildren.map((ud) => {
								return <LeisureUserButton
									className="red"
									key={'user-' + ud.user.id}
									user={ud.user}
									onClick={(e) => this.resetLeisureStart(e, ud.user.id)}
									checked={true}
									showTimes={showTimes}
									schedule={ud.schedule}
								/>;
							})}
						</div>
					</div>
				)}
			</div>
		);

		return (
			<AppPage className="leisure-page">
				{content}
			</AppPage>
		);
	}
}

const mapStateToProps = (state) => {
	const { auth, leisure } = state;
	const { user } = auth;
	const { activeLeisureGroupId, leisureInfo } = leisure;

	return {
		activeLeisureGroupId,
		leisureInfo,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		showConfirmDialog: (options) => {
			dispatch(modalActions.showConfirmDialog(options));
		},

		registerLeisureEnd: (leisureGroupId, userId) => {
			dispatch(teacherLeisureActions.registerLeisureEnd(leisureGroupId, userId));
		},

		resetLeisureEnd: (leisureGroupId, userId) => {
			dispatch(teacherLeisureActions.resetLeisureEnd(leisureGroupId, userId));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(SchoolLeisurePickup);
