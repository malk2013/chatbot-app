import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';
import Config from '../config';

import AppPage from '../components/AppPage';
import Button from '../components/Button';
import ExternalLink from '../components/ExternalLink';
import { gettext, LOC_KEYS } from '../core/Texts';


class About extends Component {

	componentDidMount () {
		Analytics.trackView('About');
	}

	render () {
		return (
			<AppPage className="about-page">
				<div className="container">
					<header className="center">
						<h2> { gettext(LOC_KEYS.ABOUT_SKOLPLATT) } </h2>
					</header>

					<div className="content center pam">

						<p>Version {window.appVersion || '-'} <span style={{color: '#aaa'}}>| {Config.getBuildNumber()}</span></p>

						<p>© 2018 Admentum AB</p>

						{!Config.isProdEnv() && (
							<p><span style={{color: '#aaa'}}>{Config.getBackendUrl()}</span></p>
						)}
						{(this.props.user.isSuperUser() || !Config.isProdEnv()) && (
							<Button
								text="Config"
								className="mts"
								onClick={(e) => {e.preventDefault(); e.stopPropagation(); this.props.history.push('/debug');}}
							/>
						)}

						<p className="mvm">
							<span>{ gettext(LOC_KEYS.ABOUT_TERMS) }</span>
							<ExternalLink
								className="link"
								url="http://www.admentum.se/terms"
								text={ gettext(LOC_KEYS.ABOUT_TERMS_LINK) }
								icon={true}
							/>
						</p>

						<p>
							<span>{ gettext(LOC_KEYS.ABOUT_MORE_INFO) } </span>
							<ExternalLink
								className="link"
								url="http://www.admentum.se"
								text="www.admentum.se"
								icon={true}
							/>
						</p>

					</div>
				</div>
			</AppPage>
		);
	}
}


const mapStateToProps = (state) => {
	const { auth } = state;
	const { user } = auth;
	return {
		user
	};
};

export default connect(mapStateToProps)(About);