import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as messagesActions from '../actions/MessagesActions';
import AppPage from '../components/AppPage';
import MessageSelect from '../components/MessageSelect';

import { gettext, LOC_KEYS } from '../core/Texts';


class NewMessage extends Component {

	componentDidMount () {
		Analytics.trackView('NewMessage');
	}

	fixIosFocus (e) {
		e.preventDefault();
		this.refs.title.focus();
	}

	submitForm () {
		const {isCreateFetching} = this.props;
		if (isCreateFetching) {
			return;
		}
		const to = this.props.newMessageRecipients ? this.props.newMessageRecipients.map(recipient => {
			return recipient.id;
		}) : [];
		const title = this.refs.title.value;
		const body = this.refs.body.value;
		this.props.createConversation(to, title, body);
	}

	render () {
		let {createConversationErrorMessage} = this.props;

		return (
			<AppPage className="new-message">
				<div className="container">
					<header className="center">
						<h2>{gettext(LOC_KEYS.MESSAGES_NEW_CONVO)}</h2>
					</header>

					<div className="content padded">
						{createConversationErrorMessage && (
							<p className="error center pas">{createConversationErrorMessage}</p>
						)}

						<div className="form-group">
							<label> { gettext(LOC_KEYS.RECIPIENT) } </label>
							<MessageSelect
								value={this.props.newMessageRecipients}
								setMessageRecipient={this.props.setMessageRecipient}
							/>
						</div>
						<div className="form-group">
							<label>{ gettext(LOC_KEYS.SUBJECT) }</label>
							<input type="text" className="form-control" placeholder={gettext(LOC_KEYS.MESSAGE_SUBJECT_PLACEHOLDER)} ref="title" onClick={this.fixIosFocus.bind(this)} />
						</div>
						<div className="form-group">
							<label>{ gettext(LOC_KEYS.MESSAGE) }</label>
							<textarea className="form-control" placeholder={gettext(LOC_KEYS.MESSAGE_MESSAGE_PLACEHOLDER)} ref="body" rows="5"></textarea>
						</div>
						<div className="form-group center">
							<button className="btn btn-primary lg" onClick={this.submitForm.bind(this)}>{ gettext(LOC_KEYS.SEND) }</button>
						</div>
					</div>
				</div>
			</AppPage>
		);
	}

}

const mapStateToProps = (state) => {
	const { auth, messages } = state;
	const { user } = auth;
	const { newMessageRecipients, createConversationErrorMessage, isCreateFetching } = messages;

	return {
		createConversationErrorMessage,
		isCreateFetching,
		newMessageRecipients,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		setMessageRecipient: (val) => {
			dispatch(messagesActions.setMessageRecipient(val));
		},
		createConversation: (to, title, body) => {
			dispatch(messagesActions.createConversation(to, title, body));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(NewMessage);
