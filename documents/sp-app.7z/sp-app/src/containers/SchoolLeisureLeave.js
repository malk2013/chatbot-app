import React, { Component } from 'react';
import { connect } from 'react-redux';

import Analytics from '../analytics';

import * as modalActions from '../actions/ModalActions';
import * as teacherLeisureActions from '../actions/TeacherLeisureActions';

import AppPage from '../components/AppPage';
import LeisureUserButton from '../components/LeisureUserButton';

import { gettext, LOC_KEYS } from '../core/Texts';


const MarkStatus = {
	LEAVED: 1,
	RESETTED: 2,
	LEAVED_UNREGISTERED: 3,
	RESETTED_UNREGISTERED: 4
};


class SchoolLeisureLeave extends Component {

	componentDidMount () {
		Analytics.trackView('SchoolLeisureLeave');

		this._state = {
			marked: {},
			showTimes: false
		};

		this.checkContent(this.props);

	}

	componentWillReceiveProps (nextProps) {
		this.checkContent(nextProps);
	}

	checkContent (props) {
		const {leisureInfo} = props;

		if (!leisureInfo) {
			props.history.replace('/school/leisure');
		}
	}

	registerLeisureStart (e, userId, unregistered) {
		var _this = this;

		if (unregistered) {
			if (this._state.marked[userId] !== MarkStatus.LEAVED) {
				this._state.marked[userId] = MarkStatus.LEAVED;
				this.forceUpdate();

				setTimeout(function () {
					_this.props.registerLeisureStart(_this.props.activeLeisureGroupId, userId);
				}, 500);
			} else {
				this._state.marked[userId] = MarkStatus.RESETTED;
				this.forceUpdate();

				setTimeout(function () {
					_this.props.resetLeisureStart(_this.props.activeLeisureGroupId, userId);
				}, 500);
			}
		} else {
			if (this._state.marked[userId] !== MarkStatus.LEAVED_UNREGISTERED) {
				this._state.marked[userId] = MarkStatus.LEAVED_UNREGISTERED;
				this.forceUpdate();

				setTimeout(function () {
					_this.props.registerLeisureStart(_this.props.activeLeisureGroupId, userId);
				}, 500);
			} else {
				this._state.marked[userId] = MarkStatus.RESETTED_UNREGISTERED;
				this.forceUpdate();

				setTimeout(function () {
					_this.props.resetLeisureStart(_this.props.activeLeisureGroupId, userId);
				}, 500);
			}
		}
	}

	resetLeisureStart (e, userId) {
		const _this = this;
		const ud = this.props.leisureInfo.leisure_day.user_dicts.find(ud => ud.user.id == userId);
		this.props.showConfirmDialog({
			title: 'Bekräfta',
			body: 'Vill du avmarkera ' + ud.user.full_name + ' som lämnad?',
			callback: function () {
				delete _this._state.marked[userId];
				_this.props.resetLeisureStart(_this.props.activeLeisureGroupId, userId);
			}
		});
	}

	toggleTimes () {
		this._state.showTimes = !this._state.showTimes;
		this.forceUpdate();
	}

	render () {
		const {leisureInfo} = this.props;

		if (!leisureInfo) {
			return <AppPage className="leisure-page">
				{ gettext(LOC_KEYS.LOADING) }
			</AppPage>;
		}

		const markedUsers = this._state ? this._state.marked : {};
		const showTimes = this._state ? this._state.showTimes : false;

		// Get sick children:
		const sickChildren = leisureInfo.leisure_day.user_dicts.filter(user => user.reported_sick);

		// Get available children:
		// Children with registered start times, children that recently has been marked as leaved
		const availableChildren = leisureInfo.leisure_day.user_dicts.filter((user) => (
			!user.reported_sick && user.schedule && user.schedule.is_active && (
				(user.schedule.status === 0 && user.schedule.start_time && user.schedule.start_time !== 'None') ||
				user.schedule.status === 1 && (
					markedUsers[user.user.id] === MarkStatus.LEAVED ||
					markedUsers[user.user.id] === MarkStatus.RESETTED
				)
			)
		));

		// Get left children:
		// Left children that hasn't recently been marked
		const leftChildren = leisureInfo.leisure_day.user_dicts.filter((user) => (
			!user.reported_sick && user.schedule && user.schedule.status === 1 && !markedUsers[user.user.id]
		));

		// Not registrered children
		const notRegisteredChildren = leisureInfo.leisure_day.user_dicts.filter((user) => (
			(
				// Children without schedules
				!user.reported_sick && !user.schedule ||
				// or with inactive schedules or missing start time
				(user.schedule && user.schedule.status === 0 && (
					!user.schedule.is_active || !user.schedule.start_time || user.schedule.start_time === 'None'
				)) ||
				// or recently marked
				user.schedule && user.schedule.status === 1 && (
					markedUsers[user.user.id] === MarkStatus.LEAVED_UNREGISTERED ||
					markedUsers[user.user.id] === MarkStatus.RESETTED_UNREGISTERED
				)
			)
		));


		const content = (
			<div>
				<div className="container">
					<header className="center leisure-header">
						<h2>Välj barn som har lämnats</h2>
						<span className={'fui-time ' + (showTimes ? 'active' : '')} onClick={this.toggleTimes.bind(this)}></span>
					</header>

					<div className="content pvm phs center">
						{availableChildren.length === 0 && (
							<i>Alla barn med registrerade tider har lämnats</i>
						)}

						{availableChildren.map((ud) => {
							return <LeisureUserButton
								key={'user-' + ud.user.id}
								user={ud.user}
								onClick={(e) => this.registerLeisureStart(e, ud.user.id, true)}
								checked={markedUsers[ud.user.id] === MarkStatus.LEAVED}
								status={ud.schedule ? ud.schedule.status : '-'}
								showTimes={showTimes}
								schedule={ud.schedule}
							/>;
						})}
					</div>
				</div>

				{!!leftChildren.length && (
					<div className="container mtm">
						<header className="center">
							<h2>Lämnade barn</h2>
						</header>

						<div className="content pvm phs center">
							{leftChildren.map((ud) => {
								return <LeisureUserButton
									key={'user-' + ud.user.id}
									user={ud.user}
									onClick={(e) => this.resetLeisureStart(e, ud.user.id)}
									checked={true}
									showTimes={showTimes}
									schedule={ud.schedule}
								/>;
							})}
						</div>
					</div>
				)}

				{!!notRegisteredChildren.length && (
					<div className="container mtm">
						<header className="center">
							<h2>Barn utan registrerade tider</h2>
						</header>

						<div className="content pvm phs center">
							{notRegisteredChildren.map((ud) => {
								return <LeisureUserButton
									key={'user-' + ud.user.id}
									user={ud.user}
									checked={markedUsers[ud.user.id] === MarkStatus.LEAVED_UNREGISTERED}
									onClick={(e) => this.registerLeisureStart(e, ud.user.id, false)}
									showTimes={false}
									schedule={ud.schedule}
								/>;
							})}
						</div>
					</div>
				)}

				{!!sickChildren.length && (
					<div className="container mtm">
						<header className="center">
							<h2>Sjukanmälda</h2>
						</header>

						<div className="content pvm phs center">
							{sickChildren.map((ud) => {
								return <LeisureUserButton
									key={'user-' + ud.user.id}
									user={ud.user}
									checked={false}
									showTimes={false}
									schedule={ud.schedule}
								/>;
							})}
						</div>
					</div>
				)}
			</div>
		);

		return (
			<AppPage className="leisure-page">
				{content}
			</AppPage>
		);
	}
}

const mapStateToProps = (state) => {
	const { auth, leisure } = state;
	const { user } = auth;
	const { activeLeisureGroupId, leisureInfo } = leisure;

	return {
		activeLeisureGroupId,
		leisureInfo,
		user
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		showConfirmDialog: (options) => {
			dispatch(modalActions.showConfirmDialog(options));
		},

		registerLeisureStart: (leisureGroupId, userId) => {
			dispatch(teacherLeisureActions.registerLeisureStart(leisureGroupId, userId));
		},

		resetLeisureStart: (leisureGroupId, userId) => {
			dispatch(teacherLeisureActions.resetLeisureStart(leisureGroupId, userId));
		}
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(SchoolLeisureLeave);
