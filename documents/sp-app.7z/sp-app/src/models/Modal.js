
export default class Modal {

	constructor (options) {
		this.title = options.title || 'Bekräfta';
		this.body = options.body || 'Är du säkert?';
		this.buttons = options.buttons || [];
	}

}
