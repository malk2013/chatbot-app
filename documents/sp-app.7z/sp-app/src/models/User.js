import {USER_ROLES} from '../core/Constants';


export default class User {

	/*
	// Enable to debug issues.
          // window.plugins.OneSignal.setLogLevel({logLevel: 4, visualLevel: 4});

          var notificationOpenedCallback = function(jsonData) {
            console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));
          };

          window.plugins.OneSignal
            .startInit('4c0e432d-abe0-40e9-b882-e0ec0387baab')
            .handleNotificationOpened(notificationOpenedCallback)
            .endInit();

          // Call syncHashedEmail anywhere in your app if you have the user's email.
          // This improves the effectiveness of OneSignal's "best-time" notification scheduling feature.
          // window.plugins.OneSignal.syncHashedEmail(userEmail);
          */

	constructor (data) {
		this.sp_account = data.sp_account;
		this.email = data.email;
		this.id = data.id;
		this.first_name = data.first_name;
		this.last_name = data.last_name;
		this.full_name = data.first_name + ' ' + data.last_name;
		this.role = data.role;
		this.school = data.school;
		this.username = data.username;
		this.children = data.children || [];
		this.activeChild = data.activeChild || false;

		this._isLeisureTeacher = data.is_leisure_teacher || false;
		this._teachingLeisureGroups = data.teaching_leisure_groups || [];
	}

	getStyleRoleClass () {
		if (this.role === USER_ROLES.STUDENT) {
			return 'student';
		} else {
			return 'parent';
		}
	}

	getScheduleEndPoint () {
		if (this.isParentWithActiveChild()) {
			return 'api/me/' + this.id + '/schedule/' + this.activeChild.id;
		} else {
			return 'api/me/' + this.id + '/schedule';
		}
	}

	hasSchedule () {
		return true;
		// return (this.isStudent() || this.isParentWithActiveChild());
	}

	hasMulitpleUsers () {
		return this.sp_account.users.length > 1;
	}

	isSuperUser () {
		return this.role === 4 && this.school.id === 27;
	}

	isParent () {
		return this.role === USER_ROLES.PARENT;
	}

	isParentWithSingleChild () {
		return this.isParent() && this.children.length === 1;
	}

	isParentWithMultipleChildrens () {
		return this.isParent() && this.children.length > 1;
	}

	isParentWithActiveChild () {
		return this.isParent()  && this.activeChild;
	}

	isStudent () {
		return this.role === USER_ROLES.STUDENT;
	}

	isTeacher () {
		return this.role === USER_ROLES.TEACHER;
	}

	isSchoolStaff () {
		return (
			this.role === USER_ROLES.TEACHER ||
			this.role === USER_ROLES.PRINCIPAL
		);
	}

	isLeisureTeacher () {
		return this.isSchoolStaff() && this._isLeisureTeacher;
	}

	getActiveChildFullName () {
		return this.isParentWithActiveChild() ? this.activeChild.first_name + ' ' + this.activeChild.last_name : '';
	}

	getTeachingLeisureGroups () {
		return (this.isSchoolStaff())
			? this._teachingLeisureGroups
			: false;
	}

	setBodyBgr () {
		// Ugly bg color fix for now..
		if (this.isParent()) {
			document.body.style.backgroundColor = '#344a5e';
			if (window.StatusBar) {
				window.StatusBar.backgroundColorByHexString('#55a1fc');
			}
		} else {
			document.body.style.backgroundColor = '';
			if (window.StatusBar) {
				window.StatusBar.backgroundColorByHexString('#59b36f');
			}
		}
	}
}