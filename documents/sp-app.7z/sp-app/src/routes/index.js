import { Switch, Route } from 'react-router-dom';
import React from 'react';
import { connect } from 'react-redux';

import { gettext, LOC_KEYS } from '../core/Texts';

import About from '__containers/About';
import Absences from '__containers/Absences';
import Absence from '__containers/Absence';
import AbsencePartial from '../containers/AbsencePartial';
import LoggedInWrapper from '__containers/LoggedInWrapper';
import Conversation from '__containers/Conversation';
import Debug from '__containers/Debug';
import Home from '__containers/Home';
import Leisure from '__containers/Leisure';
import LeisureDefaultWeek from '__containers/LeisureDefaultWeek';
import LeisureWeekday from '__containers/LeisureWeekday';
import Lesson from '__containers/Lesson';
import Messages from '__containers/Messages';
import NewMessage from '__containers/NewMessage';
import Presence from '__containers/Presence';
import Profile from '__containers/Profile';
import Schedule from '__containers/Schedule';
import SchoolDay from '__containers/SchoolDay';
import SchoolLeisure from '__containers/SchoolLeisure';
import SchoolLeisureLeave from '__containers/SchoolLeisureLeave';
import SchoolLeisurePickup from '__containers/SchoolLeisurePickup';
import Sickness from '__containers/Sickness';
import UserToken from '__containers/UserToken';

// The connected Switch is hooked up to location so it is aware of state update
// NOTE: this isn't used for this moment due to TransitionGroup, a normal Switch can be
// found in UI for now
export const ConnectedSwitch = connect(state => ({
	location: state.router.location,
}))(Switch);

export const routes = [
	{path: '/home', component: Home},
	{path: '/school-day', title: gettext(LOC_KEYS.TITLE_SCHOOL_DAY), component: SchoolDay},
	{path: '/profile', title: gettext(LOC_KEYS.TITLE_PROFILE), component: Profile},
	{path: '/schedule', title: gettext(LOC_KEYS.TITLE_SCHEDULE), component: Schedule},
	{path: '/lesson/:week/:weekday/:id', title: gettext(LOC_KEYS.TITLE_LESSON), component: Lesson},
	{path: '/messages', title: gettext(LOC_KEYS.TITLE_MESSAGES), component: Messages},
	{path: '/conversation/:id', title: gettext(LOC_KEYS.TITLE_CONVERSATION), component: Conversation},
	{path: '/new-message', title: gettext(LOC_KEYS.TITLE_MESSAGES), component: NewMessage},
	{path: '/sickness', title: gettext(LOC_KEYS.TITLE_REPORT_SICK), component: Sickness},
	{path: '/absence', title: gettext(LOC_KEYS.TITLE_ABSENCE), component: Presence},
	{path: '/absence/partial', title: gettext(LOC_KEYS.TITLE_ABSENCE), component: AbsencePartial},
	{path: '/absence/unconfirmed', title: gettext(LOC_KEYS.TITLE_ABSENCE), component: Absences},
	{path: '/absence/confirmed', title: gettext(LOC_KEYS.TITLE_ABSENCE), component: Absences},
	{path: '/absence/:id', title: gettext(LOC_KEYS.TITLE_ABSENCE), component: Absence},
	{path: '/about', title: gettext(LOC_KEYS.TITLE_ABOUT), component: About},
	{path: '/leisure', title: gettext(LOC_KEYS.TITLE_LEISURE), component: Leisure},
	{path: '/leisure/default-week', title: gettext(LOC_KEYS.TITLE_LEISURE), component: LeisureDefaultWeek},
	{path: '/leisure/weekday/:date', title: gettext(LOC_KEYS.TITLE_LEISURE), component: LeisureWeekday},
	{path: '/debug', title: 'Config', component: Debug},
	{path: '/school/leisure', title: gettext(LOC_KEYS.TITLE_LEISURE), component: SchoolLeisure},
	{path: '/school/leisure/leave', title: gettext(LOC_KEYS.TITLE_LEISURE), component: SchoolLeisureLeave},
	{path: '/school/leisure/pickup', title: gettext(LOC_KEYS.TITLE_LEISURE), component: SchoolLeisurePickup},
	{path: '/user_token', component: UserToken},
	{path: '', component: Home}
];

// const PublicRoutes = [
// 	{path: '/user_token', component: UserToken},
// ]

// export const routes = PrivateRoutes + PublicRoutes

export const ProtectedRouteArea = () =>
	<LoggedInWrapper>
		{ routes.map(({path, title, component: Component}, index) => (
			<Route path={path} title={title} component={Component} key={index} exact />
		))};
	</LoggedInWrapper>;