import React from 'react';
import renderer from 'react-test-renderer';

import BackButton from '__components/BackButton.js';

/*global it expect*/

it('renders a back button', () => {
	const tree = renderer
		.create(<BackButton onClick={()=>{}}/>)
		.toJSON();
	expect(tree).toMatchSnapshot();
});