import React from 'react';
import renderer from 'react-test-renderer';

import { Login } from '__containers/Login.js';
/* global describe it expect jest */

describe('Login page...', () => {
	const loginUser = jest.fn();

	const component = renderer.create(
		<Login loginUser={loginUser} loginErrorMessage={''}/>
	);

	it('should render form correctly', () => {
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('should render form with error message correctly', () => {
		component.update(<Login loginUser={loginUser} loginErrorMessage={'whoopsie'} />);
		expect(component.toJSON()).toMatchSnapshot();
	});
});
