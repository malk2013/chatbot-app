import { gettext, LOC_KEYS, STRINGS_EN, STRINGS_SV } from '../core/Texts';

/*global describe it expect */

describe('Localisation should...', () => {
	const en_keys = Object.keys(STRINGS_EN);
	const sv_keys = Object.keys(STRINGS_SV);
	const loc_keys = Object.keys(LOC_KEYS);

	const checkUndefinedKey = (key, index) => {
		if(LOC_KEYS[key] == undefined) {
			throw Error(`There's an undefined key in LOC_KEYS after ${loc_keys[index-1]}`);
		}
	};

	it('have the same string for key and value in LOC_KEYS', () => {
		const sameness = loc_keys.filter(key => key !== LOC_KEYS[key]);
		expect(sameness).toEqual([]);
	});
	it('not have any undefined keys for English or Swedish', () => {
		en_keys.filter((key, index) => checkUndefinedKey(key, index));
		sv_keys.filter((key, index) => checkUndefinedKey(key, index));
	});
	it('have the same set of keys for both English and Swedish', () => {
		const only_en = en_keys.filter(key => sv_keys.indexOf(key) == -1);
		const only_sv = sv_keys.filter(key => en_keys.indexOf(key) == -1);
		
		expect(only_en).toEqual([]);
		expect(only_sv).toEqual([]);
	});
	it('not have any unused keys in LOC_KEYS', () => {
		const only_loc = loc_keys.filter(key => sv_keys.indexOf(key) == -1);		
		expect(only_loc).toEqual([]);
	});
	it('retrieve Swedish as default', () => {
		const swe_no_title = gettext(LOC_KEYS.CONV_NO_TITLE);
		expect(swe_no_title).toBe(STRINGS_SV[LOC_KEYS.CONV_NO_TITLE]);
	});
	it('allow to switch to English and receive English', () => {
		localStorage.setItem('skolplatt_lang', 'en');

		const eng_no_title = gettext(LOC_KEYS.CONV_NO_TITLE);
		expect(eng_no_title).toBe(STRINGS_EN[LOC_KEYS.CONV_NO_TITLE]);
	});
});