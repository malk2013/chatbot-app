import React from 'react';
import renderer from 'react-test-renderer';

import AbsencePartial from '../components/AbsencePartialPage.js';
/* global describe it expect jest */

/**
 * TODO: need to mock Date globally as snapshot fails on today props
 */
describe('Absence partial...', () => {
	const props = {
		error: {},
		sicknessList: [],
		isFetching: false,
		isFetched: true,
		activeChildId: 1,
		reset: jest.fn(),
		fetch: jest.fn(),
		report: jest.fn(),
		remove: jest.fn(),
		resetErrors: jest.fn(),
	};

	const component = renderer.create(<AbsencePartial { ...props } />);

	it('matches snapshot', () => {
		expect(component.toJSON()).toMatchSnapshot();
	});

	it('renders the spinner when fetching', () => {
		const newProps = { ...props, isFetching: true, isFetched: false };
		component.update(<AbsencePartial { ...newProps } />);
		expect(component.toJSON()).toMatchSnapshot();
	});
});
