import { push } from 'react-router-redux';
import Utils from './core/Utils';

import TinyEmitter from 'tiny-emitter';
window.emitter = new TinyEmitter();

/* global store */

const notificationOpenedCallback = function (jsonData) {
	const conversationId = Utils.getDeepAttribute(jsonData, 'notification.payload.additionalData.conversation_id', false);
	if (conversationId) {
		store.dispatch(push('/conversation/' + conversationId));
	} else {
		const action = Utils.getDeepAttribute(jsonData, 'notification.payload.additionalData.action', false);

		if (action === 'unconfirmed-absence' || action === 'absence-confirmed') {
			const absenceId = Utils.getDeepAttribute(jsonData, 'notification.payload.additionalData.absence_id', false);
			if (absenceId) {
				store.dispatch(push('/absence/' + absenceId));
			}
		} else if (action === 'unconfirmed-absences') {
			store.dispatch(push('/absence'));
		}
	}
};

const notificationReceivedCallback = function (jsonData) {
	if (jsonData.notification) {
		jsonData = jsonData.notification;
	}

	window.emitter.emit('unreadCountUpdated');

	if (window.cordova && window.cordova.plugins && window.cordova.plugins.notification && window.cordova.plugins.notification.badge) {
		let badgeCount = Utils.getDeepAttribute(jsonData, 'payload.additionalData.badge_count', 0);
		window.cordova.plugins.notification.badge.set(badgeCount);
	}

	const conversationId = Utils.getDeepAttribute(jsonData, 'payload.additionalData.conversation_id', false);
	if (conversationId) {
		const bodyText = Utils.getDeepAttribute(jsonData, 'payload.body', false);
		window.emitter.emit('conversationUpdated', conversationId, bodyText);
	}
};

document.addEventListener('resume', function () {
	window.emitter.emit('unreadCountUpdated');
}, false);

if (window.plugins && window.plugins.OneSignal) {
	window.plugins.OneSignal
		.startInit('4c0e432d-abe0-40e9-b882-e0ec0387baab')
		.inFocusDisplaying(window.plugins.OneSignal.OSInFocusDisplayOption.None)
		.handleNotificationOpened(notificationOpenedCallback)
		.handleNotificationReceived(notificationReceivedCallback)
		.endInit();
}